<?php

namespace App\Services;

use App\Mail\OmniFixNotificationMail;
use App\Models\InventoryPart;
use App\Models\RmaJob;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class NotificationService
{
    protected string $adminEmail;

    protected string $techEmail;

    public function __construct()
    {
        $this->adminEmail = env('ADMIN_NOTIFICATION_EMAIL', 'watweera82@gmail.com');
        $this->techEmail = env('TECH_NOTIFICATION_EMAIL', 'watweera82@gmail.com');
    }

    /**
     * 1. ADMIN ROLE: เมื่อ user กดเริ่มการซ่อมใหม่
     */
    public function notifyAdminNewRepair(RmaJob $job): bool
    {
        return $this->sendSafe(
            to: $this->adminEmail,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Admin] มีรายการแจ้งซ่อมใหม่: RMA-#{$job->id} ({$job->model})",
                title: 'มีรายการแจ้งซ่อมใหม่เข้าระบบ',
                badge: 'Admin Alert',
                badgeColor: '#ea580c',
                recipientName: 'Service Manager (Admin)',
                introText: 'มีลูกค้าได้เปิดรายการแจ้งซ่อมเครื่องใหม่เข้ามาในระบบ OmniFix Care กรุณาตรวจสอบและดำเนินการจ่ายงานให้ช่างประจำโต๊ะซ่อม',
                details: [
                    'รหัสใบซ่อม (Ticket ID)' => "RMA-#{$job->id}",
                    'ลูกค้าผู้แจ้ง (Customer)' => $job->customer_name.($job->customer_email ? " ({$job->customer_email})" : ''),
                    'อุปกรณ์ / รุ่น (Device)' => "{$job->brand} {$job->model} ".($job->gen ?? ''),
                    'หมายเลขซีเรียล (Serial)' => $job->serial,
                    'อาการที่พบ (Reported Issue)' => $job->issue,
                    'สถานะประกัน (Warranty)' => $job->warranty_status,
                    'สถานะปัจจุบัน (Status)' => $job->status,
                ],
                actionUrl: url('/?role=manager&page=Technician%20dispatch'),
                actionText: 'เปิดดูหน้า Technician Dispatch →'
            )
        );
    }

    /**
     * 2. ADMIN ROLE: เมื่อ ช่าง ส่งขออะไหล่
     */
    public function notifyAdminPartRequested(InventoryPart $part, string $technicianName = 'Alex Morgan', ?string $ticketId = null): bool
    {
        return $this->sendSafe(
            to: $this->adminEmail,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Admin] ช่างขอเบิกอะไหล่: {$part->name} (SKU: {$part->sku})",
                title: 'คำขอสั่งซื้อ / เบิกอะไหล่จากช่างเทคนิค',
                badge: 'Parts Request',
                badgeColor: '#d97706',
                recipientName: 'Service Manager / Inventory Lead',
                introText: "ช่างเทคนิค {$technicianName} ได้ทำเรื่องขอเบิก/สั่งซื้ออะไหล่สำหรับเคสงานซ่อม กรุณาอนุมัติใบสั่งซื้อ (Purchase Order) ในระบบ",
                details: [
                    'รายการอะไหล่ (Part Name)' => $part->name,
                    'รหัส SKU' => $part->sku,
                    'รุ่นที่รองรับ (Compatible)' => $part->compatible_models,
                    'จำนวนคงเหลือในคลัง' => "{$part->stock} ชิ้น (เกณฑ์ขั้นต่ำ {$part->min_stock} ชิ้น)",
                    'ช่างผู้ขอ (Requested By)' => $technicianName,
                    'ตั๋วงานซ่อม (Ticket ID)' => $ticketId ? "RMA-#{$ticketId}" : 'Workbench Requisition',
                    'การดำเนินการที่ต้องทำ' => 'อนุมัติสั่งซื้อโรงงาน (Approve Reorder)',
                ],
                actionUrl: url('/?role=manager&page=Stock%20oversight'),
                actionText: 'เปิดดูหน้า Stock Oversight →'
            )
        );
    }

    /**
     * 3. USER ROLE: เมื่อ ช่าง รับงานซ่อม
     */
    public function notifyUserJobAccepted(RmaJob $job): bool
    {
        $recipient = $job->customer_email ?: $this->adminEmail;

        return $this->sendSafe(
            to: $recipient,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Care] ช่างได้รับงานซ่อมของคุณแล้ว: RMA-#{$job->id} ({$job->model})",
                title: 'อัปเดต: ช่างเทคนิคเริ่มดำเนินการตรวจเช็คอุปกรณ์ของคุณ',
                badge: 'Customer Update',
                badgeColor: '#3b82f6',
                recipientName: $job->customer_name,
                introText: 'ศูนย์บริการ OmniFix Care ขอแจ้งให้ทราบว่า อุปกรณ์ของคุณได้รับการจ่ายงานและช่างเทคนิคผู้เชี่ยวชาญได้รับเครื่องเข้าประจำโต๊ะซ่อมเรียบร้อยแล้ว',
                details: [
                    'รหัสใบซ่อม (Ticket ID)' => "RMA-#{$job->id}",
                    'อุปกรณ์ (Device)' => "{$job->brand} {$job->model}",
                    'หมายเลขซีเรียล (Serial)' => $job->serial,
                    'ช่างผู้ดูแล (Assigned Tech)' => "{$job->tech_name} ({$job->tech_initials})",
                    'สถานะปัจจุบัน' => 'กำลังตรวจวินิจฉัย (In Diagnosis / Bench Intake)',
                    'เวลาประมาณการ (SLA Target)' => $job->time_remaining ?: 'ภายใน 24 ชั่วโมง',
                ],
                actionUrl: url("/?role=customer&page=Track%20my%20repair&ticket={$job->id}"),
                actionText: 'ติดตามสถานะงานซ่อมแบบเรียลไทม์ →'
            )
        );
    }

    /**
     * 4. USER ROLE: เมื่อ ช่าง ซ่อมเสร็จ
     */
    public function notifyUserRepairCompleted(RmaJob $job): bool
    {
        $recipient = $job->customer_email ?: $this->adminEmail;

        return $this->sendSafe(
            to: $recipient,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Care] การซ่อมอุปกรณ์ของคุณเสร็จสิ้นแล้ว: RMA-#{$job->id}",
                title: 'การซ่อมอุปกรณ์เสร็จเรียบร้อยและผ่าน QC แล้ว',
                badge: 'Repair Complete',
                badgeColor: '#10b981',
                recipientName: $job->customer_name,
                introText: 'เรามีความยินดีที่จะแจ้งให้ทราบว่า อุปกรณ์ของคุณได้รับการซ่อมแซมและผ่านการทดสอบคุณภาพ (Quality Control) เรียบร้อยแล้ว พร้อมส่งมอบคืนให้คุณ',
                details: [
                    'รหัสใบซ่อม (Ticket ID)' => "RMA-#{$job->id}",
                    'อุปกรณ์ (Device)' => "{$job->brand} {$job->model}",
                    'หมายเลขซีเรียล (Serial)' => $job->serial,
                    'ช่างผู้ดำเนินการ (Technician)' => $job->tech_name,
                    'บันทึกช่าง (Tech Notes)' => $job->technician_notes ?: 'การทดสอบฮาร์ดแวร์และการประกอบผ่านเกณฑ์มาตรฐานทั้งหมด',
                    'สถานะปัจจุบัน' => 'ผ่านการตรวจ QC พร้อมส่งมอบ (Ready for Pickup / Delivery)',
                ],
                actionUrl: url("/?role=customer&page=Track%20my%20repair&ticket={$job->id}"),
                actionText: 'ตรวจสอบใบรับรองผลการซ่อม →'
            )
        );
    }

    /**
     * 5. TECH ROLE: เมื่อมีงานเข้าใหม่
     */
    public function notifyTechNewJobAssigned(RmaJob $job, ?string $techEmail = null): bool
    {
        $recipient = $techEmail ?: $this->techEmail;

        return $this->sendSafe(
            to: $recipient,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Workbench] มอบหมายงานซ่อมใหม่: RMA-#{$job->id} ({$job->model})",
                title: 'มีงานซ่อมใหม่ถูกมอบหมายเข้าประจำโต๊ะซ่อมของคุณ',
                badge: 'Tech Dispatch',
                badgeColor: '#8b5cf6',
                recipientName: $job->tech_name ?: 'Bench Technician',
                introText: 'หัวหน้าฝ่ายปฏิบัติการได้มอบหมายงานซ่อมอุปกรณ์ชิ้นใหม่ให้คุณ กรุณาเข้าสู่ระบบ Workbench เพื่อตรวจสอบและเริ่มการวินิจฉัย',
                details: [
                    'รหัสตั๋วงาน (Ticket ID)' => "RMA-#{$job->id}",
                    'อุปกรณ์ / รุ่น (Device)' => "{$job->brand} {$job->model} ".($job->gen ?? ''),
                    'ซีเรียลนัมเบอร์ (Serial)' => $job->serial,
                    'อาการเสียที่แจ้ง (Symptom)' => $job->issue,
                    'ระดับความสำคัญ (Priority)' => $job->priority,
                    'กำหนดเวลา SLA (Remaining)' => $job->time_remaining,
                    'ลูกค้า (Customer)' => $job->customer_name,
                ],
                actionUrl: url("/?role=technician&selected={$job->id}"),
                actionText: 'เปิดโต๊ะตรวจเช็คอุปกรณ์ (Bench Intake) →'
            )
        );
    }

    /**
     * 6. TECH ROLE: เมื่อได้รับอะไหล่
     */
    public function notifyTechPartReceived(InventoryPart $part, ?string $techEmail = null, ?string $ticketId = null): bool
    {
        $recipient = $techEmail ?: $this->techEmail;

        return $this->sendSafe(
            to: $recipient,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Workbench] อะไหล่พร้อมใช้งานแล้ว: {$part->name} (SKU: {$part->sku})",
                title: 'อะไหล่ที่ร้องขอได้รับการจัดส่งมาถึงศูนย์แล้ว',
                badge: 'Parts Ready',
                badgeColor: '#06b6d4',
                recipientName: 'Senior Technician',
                introText: 'อะไหล่ที่คุณร้องขอได้รับการจัดส่งและตรวจรับเข้าคลังอะไหล่เรียบร้อยแล้ว คุณสามารถนำชิ้นส่วนไปประกอบและดำเนินการซ่อมต่อได้ทันที',
                details: [
                    'รายการอะไหล่ (Part Name)' => $part->name,
                    'รหัส SKU' => $part->sku,
                    'รุ่นอุปกรณ์ที่รองรับ' => $part->compatible_models,
                    'จำนวนพร้อมใช้งานในสต็อก' => "{$part->stock} ชิ้น",
                    'ตั๋วงานที่เกี่ยวข้อง (Ticket ID)' => $ticketId ? "RMA-#{$ticketId}" : 'Bench Reserved',
                    'สถานะชิ้นส่วน' => 'พร้อมเบิกใช้งาน (Ready to Install)',
                ],
                actionUrl: url('/?role=technician&page=My%20workbench&tab=Awaiting%20parts'),
                actionText: 'เปิดคิวงานที่รออะไหล่ (Awaiting Parts Queue) →'
            )
        );
    }

    /**
     * Send test email to verify SMTP connection
     */
    public function sendTestConnectionEmail(string $targetEmail): bool
    {
        return $this->sendSafe(
            to: $targetEmail,
            mailable: new OmniFixNotificationMail(
                subjectTitle: '[OmniFix Care] ทดสอบการเชื่อมต่อระบบอีเมลสำเร็จ (SMTP Connected)',
                title: 'ระบบส่งอีเมลแจ้งเตือน OmniFix Care พร้อมใช้งานแล้ว',
                badge: 'System Verified',
                badgeColor: '#10b981',
                recipientName: 'ผู้ดูแลระบบ OmniFix',
                introText: 'การเชื่อมต่อส่งอีเมลผ่าน Gmail SMTP ได้รับการตรวจสอบและทำงานได้อย่างถูกต้องสมบูรณ์ สามารถส่งการแจ้งเตือนทั้ง 6 เงื่อนไขได้ตามปกติ',
                details: [
                    'ผู้ให้บริการ (Provider)' => 'Google Gmail SMTP',
                    'โฮสต์และพอร์ต (Host/Port)' => 'smtp.gmail.com:587 (TLS)',
                    'อีเมลผู้ส่ง (Sender)' => env('MAIL_FROM_ADDRESS', 'watweera82@gmail.com'),
                    'อีเมลผู้รับทดสอบ (Recipient)' => $targetEmail,
                    'เวลาทดสอบ (Verified Time)' => now()->timezone('Asia/Bangkok')->format('d/m/Y H:i:s'),
                ],
                actionUrl: url('/?role=manager&page=Operations%20overview'),
                actionText: 'เข้าสู่แดชบอร์ด OmniFix Care →'
            )
        );
    }

    /**
     * แจ้งเตือน Admin เมื่อมีผู้ใช้ลงทะเบียนบทบาทใหม่ที่ต้องรอการอนุมัติ (1-Click Approval Link)
     */
    public function notifyAdminNewStaffRegistration(User $user): bool
    {
        $roleLabel = match ($user->role) {
            'technician' => 'ช่างเทคนิคประจำโต๊ะ (Hardware Technician)',
            'corporate' => 'ผู้ดูแลไอทีองค์กร (Corporate IT)',
            'manager' => 'ผู้จัดการศูนย์บริการ (Service Manager)',
            default => ucfirst($user->role),
        };

        $approveUrl = route('user.approve', ['token' => $user->approval_token]);

        return $this->sendSafe(
            to: $this->adminEmail,
            mailable: new OmniFixNotificationMail(
                subjectTitle: "[OmniFix Admin] มีคำขอสมัครสมาชิกใหม่รอการอนุมัติ: {$user->name} ({$roleLabel})",
                title: 'คำขอสมัครสมาชิกใหม่รอการตรวจสอบและอนุมัติ',
                badge: 'Approval Required',
                badgeColor: '#ef4444',
                recipientName: 'Admin / Service Manager',
                introText: "มีผู้ใช้งานได้ลงทะเบียนในบทบาท {$roleLabel} เข้าสู่ระบบ OmniFix Care และกำลังรอการยืนยันสิทธิ์จากคุณเพื่อเปิดใช้งาน",
                details: [
                    'ชื่อผู้สมัคร (Full Name)' => $user->name,
                    'อีเมลผู้สมัคร (Email)' => $user->email,
                    'บทบาทที่ขอสิทธิ์ (Requested Role)' => $roleLabel,
                    'แผนกงาน (Department)' => $user->department ?? '-',
                    'เวลาที่สมัคร (Registered At)' => $user->created_at?->timezone('Asia/Bangkok')->format('d/m/Y H:i:s') ?? now()->format('d/m/Y H:i:s'),
                    'สถานะปัจจุบัน' => 'รอการยืนยัน (Pending Admin Approval)',
                ],
                actionUrl: $approveUrl,
                actionText: 'คลิกเพื่ออนุมัติบัญชีนี้ทันที (1-Click Approve) →'
            )
        );
    }

    /**
     * แจ้งเตือนผู้สมัครเมื่อ Admin ได้กดยืนยันการอนุมัติบัญชีแล้ว
     */
    public function notifyUserAccountApproved(User $user): bool
    {
        $roleLabel = match ($user->role) {
            'technician' => 'ช่างเทคนิคประจำโต๊ะ (Hardware Technician)',
            'corporate' => 'ผู้ดูแลไอทีองค์กร (Corporate IT)',
            'manager' => 'ผู้จัดการศูนย์บริการ (Service Manager)',
            default => ucfirst($user->role),
        };

        return $this->sendSafe(
            to: $user->email,
            mailable: new OmniFixNotificationMail(
                subjectTitle: '[OmniFix Care] บัญชีของคุณได้รับการอนุมัติเรียบร้อยแล้ว — เข้าสู่ระบบได้ทันที',
                title: 'ยินดีต้อนรับ! บัญชีของคุณได้รับการอนุมัติแล้ว',
                badge: 'Account Approved',
                badgeColor: '#10b981',
                recipientName: $user->name,
                introText: "ผู้ดูแลระบบ (Admin) ได้ตรวจสอบและอนุมัติบัญชีของคุณสำหรับบทบาท {$roleLabel} เรียบร้อยแล้ว คุณสามารถเข้าสู่ระบบและเริ่มใช้งาน OmniFix Care ได้ทันที",
                details: [
                    'ชื่อผู้ใช้งาน (Name)' => $user->name,
                    'อีเมลเข้าสู่ระบบ (Email)' => $user->email,
                    'บทบาทที่ได้รับสิทธิ์ (Approved Role)' => $roleLabel,
                    'สถานะบัญชี (Account Status)' => 'เปิดใช้งานแล้ว (Active)',
                    'เวลาที่อนุมัติ (Approved At)' => now()->timezone('Asia/Bangkok')->format('d/m/Y H:i:s'),
                ],
                actionUrl: route('login'),
                actionText: 'เข้าสู่ระบบ OmniFix Care (Sign In) →'
            )
        );
    }

    /**
     * Helper to send mail safely with background queue and sync fallback
     */
    protected function sendSafe(string $to, $mailable): bool
    {
        try {
            Mail::to($to)->queue($mailable);
            Log::info("Notification email queued successfully for {$to}");

            return true;
        } catch (\Throwable $e) {
            Log::warning("Failed to queue email to {$to}, attempting direct sync send: ".$e->getMessage());
            try {
                Mail::to($to)->send($mailable);
                Log::info("Notification email sent directly via sync fallback to {$to}");

                return true;
            } catch (\Throwable $ex) {
                Log::error("Failed to send notification email to {$to}: ".$ex->getMessage());

                return false;
            }
        }
    }
}
