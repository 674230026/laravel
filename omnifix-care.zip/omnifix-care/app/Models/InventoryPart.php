<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InventoryPart extends Model
{
    use HasFactory;

    protected $primaryKey = 'sku';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'sku',
        'name',
        'category',
        'compatible_models',
        'stock',
        'reserved',
        'min_stock',
        'on_order',
        'unit_cost',
    ];

    protected $casts = [
        'on_order' => 'boolean',
        'stock' => 'integer',
        'reserved' => 'integer',
        'min_stock' => 'integer',
        'unit_cost' => 'decimal:2',
    ];
}
