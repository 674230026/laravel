<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FleetAsset extends Model
{
    use HasFactory;

    protected $keyType = 'string';

    public $incrementing = false;

    protected $fillable = [
        'id',
        'asset_tag',
        'employee',
        'department',
        'model',
        'serial',
        'issue',
        'status',
        'time_remaining',
    ];
}
