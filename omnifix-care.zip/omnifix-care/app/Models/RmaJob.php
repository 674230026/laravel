<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RmaJob extends Model
{
    use HasFactory;

    protected $keyType = 'string';

    public $incrementing = false;

    protected $fillable = [
        'id',
        'brand',
        'model',
        'gen',
        'serial',
        'customer_name',
        'customer_email',
        'customer_phone',
        'warranty_status',
        'issue',
        'tech_name',
        'tech_initials',
        'time_remaining',
        'status',
        'priority',
        'tone',
        'processor',
        'memory',
        'checklist',
        'technician_notes',
        'quote_amount',
        'quote_approved',
        'evidence_photos',
    ];

    protected $casts = [
        'checklist' => 'array',
        'evidence_photos' => 'array',
        'quote_approved' => 'boolean',
        'quote_amount' => 'decimal:2',
    ];
}
