<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffMember extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'role',
        'bench',
        'two_fa',
        'active',
        'permissions',
    ];

    protected $casts = [
        'two_fa' => 'boolean',
        'active' => 'boolean',
        'permissions' => 'array',
    ];
}
