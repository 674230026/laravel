<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DispatchTicket extends Model
{
    use HasFactory;

    protected $keyType = 'string';

    public $incrementing = false;

    protected $fillable = [
        'id',
        'model',
        'issue',
        'bench',
        'time_remaining',
    ];

    protected $casts = [
        'bench' => 'integer',
    ];
}
