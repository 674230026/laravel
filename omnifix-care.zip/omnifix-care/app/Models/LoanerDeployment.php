<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoanerDeployment extends Model
{
    use HasFactory;

    protected $fillable = [
        'ticket_id',
        'employee',
        'profile',
        'urgency',
        'address',
        'status',
    ];
}
