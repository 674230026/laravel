<?php

namespace App\Http\Controllers;

use App\Models\RmaJob;
use App\Models\InventoryPart;
use App\Models\FleetAsset;
use App\Models\DispatchTicket;
use App\Models\LoanerDeployment;
use App\Models\StaffMember;
use App\Models\User;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class OmniFixController extends Controller
{
    public function index(Request $request)
    {
        // Check if user is signed in or requesting a role
        if (!$request->session()->has('signed_in') && !$request->has('role')) {
            return redirect()->route('login');
        }

        $role = $request->query('role', $request->session()->get('role', 'manager'));
        $request->session()->put('role', $role);
        $request->session()->put('signed_in', true);

        $currentUser = $this->getUserForRole($role);
        $request->session()->put('user', $currentUser);

        $defaultPage = match ($role) {
            'manager' => 'Operations overview',
            'corporate' => 'Fleet overview',
            'customer' => 'Warranty & repair',
            default => 'My workbench',
        };
        $page = $request->query('page', $defaultPage);
        $selectedId = $request->query('selected');
        $tab = $request->query('tab', 'All jobs');
        $search = $request->query('query', '');
        $brand = $request->query('brand', 'All brands');
        $sla = $request->query('sla', 'All SLA statuses');
        $bench = $request->query('bench', 'All technicians');
        $stockFilter = $request->query('stockFilter', 'All parts');
        $range = $request->query('range', 'Last 30 days');
        $branch = $request->query('branch', 'Bangkok Central');
        $company = $request->query('company', 'Acme Corp');

        // Selected Job for Bench Inspection
        $selectedJob = $selectedId ? RmaJob::find($selectedId) : null;

        // Technician Workbench Jobs query
        $jobsQuery = RmaJob::query();
        if ($search) {
            $jobsQuery->where(function ($q) use ($search) {
                $q->where('id', 'like', "%{$search}%")
                  ->orWhere('model', 'like', "%{$search}%")
                  ->orWhere('serial', 'like', "%{$search}%")
                  ->orWhere('issue', 'like', "%{$search}%")
                  ->orWhere('tech_name', 'like', "%{$search}%");
            });
        }
        if ($brand !== 'All brands') {
            $jobsQuery->where('brand', $brand);
        }
        if ($sla === 'Approaching SLA') {
            $jobsQuery->where('priority', 'High');
        } elseif ($sla === 'On track') {
            $jobsQuery->where('priority', '!=', 'High');
        }
        if ($bench !== 'All technicians') {
            $jobsQuery->where('tech_name', $bench);
        }
        if ($tab === 'My jobs') {
            $jobsQuery->where('tech_initials', 'AM');
        } elseif ($tab === 'Awaiting parts') {
            $jobsQuery->where('status', 'Awaiting parts');
        } elseif ($tab === 'Quality check') {
            $jobsQuery->where('status', 'Quality check');
        }
        $filteredJobs = $jobsQuery->orderBy('created_at', 'desc')->get();
        $allJobs = RmaJob::all();

        // Inventory Parts query
        $partsQuery = InventoryPart::query();
        if ($search && ($page === 'Stock oversight' || $page === 'Parts inventory')) {
            $partsQuery->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%")
                  ->orWhere('compatible_models', 'like', "%{$search}%");
            });
        }
        if ($stockFilter === 'On order') {
            $partsQuery->where('on_order', true);
        } elseif ($stockFilter === 'Out of stock') {
            $partsQuery->where('stock', 0);
        } elseif ($stockFilter === 'Low stock') {
            $partsQuery->whereColumn('stock', '<', 'min_stock');
        }
        $parts = $partsQuery->get();

        // Corporate Fleet Assets
        $fleetQuery = FleetAsset::query();
        if ($search && ($role === 'corporate')) {
            $fleetQuery->where(function ($q) use ($search) {
                $q->where('employee', 'like', "%{$search}%")
                  ->orWhere('asset_tag', 'like', "%{$search}%")
                  ->orWhere('model', 'like', "%{$search}%")
                  ->orWhere('serial', 'like', "%{$search}%");
            });
        }
        $fleetAssets = $fleetQuery->get();

        // Dispatch Tickets
        $dispatchTickets = DispatchTicket::all();
        $benches = ['David K.', 'Nisa P.', 'Somchai T.', 'Unassigned'];

        // Loaners
        $loaners = LoanerDeployment::all();

        // Customer Tracking RMA (default 84920)
        $trackJob = RmaJob::find('84920') ?? $allJobs->first();

        // User
        $user = User::first() ?? new User(['name' => $currentUser['name'], 'email' => $currentUser['email']]);
        $staffMembers = StaffMember::orderBy('id', 'asc')->get();

        return view('pages.index', compact(
            'role',
            'page',
            'selectedJob',
            'tab',
            'search',
            'brand',
            'sla',
            'bench',
            'stockFilter',
            'range',
            'branch',
            'company',
            'filteredJobs',
            'allJobs',
            'parts',
            'fleetAssets',
            'dispatchTickets',
            'benches',
            'loaners',
            'trackJob',
            'user',
            'currentUser',
            'staffMembers'
        ));
    }

    public function reassignDispatch(Request $request)
    {
        $validated = $request->validate([
            'id' => 'required|string',
            'bench' => 'required|integer|min:0|max:3',
        ]);

        $benches = ['David K.', 'Nisa P.', 'Somchai T.', 'Unassigned'];

        if ($validated['bench'] !== 3) {
            $count = DispatchTicket::where('bench', $validated['bench'])->where('id', '!=', $validated['id'])->count();
            if ($count >= 5) {
                return back()->with('error', 'This bench is at capacity. Choose an available technician.');
            }
        }

        $ticket = DispatchTicket::find($validated['id']);
        if ($ticket) {
            $ticket->bench = $validated['bench'];
            $ticket->save();
        }

        $benchName = $benches[$validated['bench']];
        return back()->with('success', "RMA-{$validated['id']} assigned to {$benchName}.");
    }

    public function markRepaired(Request $request, $id)
    {
        $job = RmaJob::findOrFail($id);
        $job->status = 'Quality check';
        $job->tone = 'green';
        if ($request->has('notes')) {
            $job->technician_notes = $request->input('notes');
        }
        if ($request->has('checklist')) {
            $job->checklist = $request->input('checklist');
        }
        $job->save();

        return redirect()->route('home', [
            'role' => 'technician',
            'page' => 'My workbench',
        ])->with('success', 'Repair completed. Ticket transferred to quality control.');
    }

    public function requestLoaner(Request $request)
    {
        $validated = $request->validate([
            'ticket_id' => 'required|string',
            'profile' => 'required|string',
            'urgency' => 'nullable|string',
            'address' => 'nullable|string',
        ]);

        $count = LoanerDeployment::count();
        if ($count >= 5) {
            return back()->with('error', 'Maximum entitled loaner units (5) already deployed.');
        }

        $asset = FleetAsset::find($validated['ticket_id']);
        $employee = $asset ? $asset->employee : 'Corporate Staff';

        LoanerDeployment::create([
            'ticket_id' => $validated['ticket_id'],
            'employee' => $employee,
            'profile' => $validated['profile'],
            'urgency' => $validated['urgency'] ?? 'Standard · 24h',
            'address' => $validated['address'] ?? 'Headquarters reception',
            'status' => 'Deployed',
        ]);

        return back()->with('success', "Loaner dispatch confirmed for {$employee}. Delivery to " . ($validated['address'] ?? 'Headquarters') . ".");
    }

    public function returnLoaner($ticket_id)
    {
        LoanerDeployment::where('ticket_id', $ticket_id)->delete();
        return back()->with('success', 'Loaner return recorded. Entitlement is available again.');
    }

    public function orderPart($sku)
    {
        $part = InventoryPart::findOrFail($sku);
        $part->on_order = true;
        $part->save();

        return back()->with('success', "Factory replenishment PO approved for {$sku}.");
    }

    public function reservePart($sku)
    {
        $part = InventoryPart::findOrFail($sku);
        $part->reserved += 1;
        $part->save();

        return back()->with('success', "{$part->name} reserved for your bench.");
    }

    public function batchOrderParts()
    {
        InventoryPart::whereColumn('stock', '<', 'min_stock')->update(['on_order' => true]);
        return back()->with('success', 'Replenishment purchase orders approved for all low-stock components.');
    }

    public function checkWarranty(Request $request)
    {
        $serial = strtoupper(trim($request->input('serial', '')));
        if (strlen($serial) < 8) {
            return response()->json(['success' => false, 'message' => 'Please enter a serial number with at least 8 characters.']);
        }

        $existing = RmaJob::where('serial', $serial)->first();
        if ($existing) {
            return response()->json([
                'success' => true,
                'model' => $existing->model,
                'gen' => $existing->gen,
                'serial' => $existing->serial,
                'warranty' => $existing->warranty_status,
                'active' => true,
            ]);
        }

        return response()->json([
            'success' => true,
            'model' => 'ThinkPad X1 Carbon Gen 11',
            'gen' => 'Intel Core i7-1365U · 16GB',
            'serial' => $serial,
            'warranty' => 'Active · Premier Onsite NBD · 184 days left',
            'active' => true,
        ]);
    }

    public function submitCustomerTicket(Request $request)
    {
        $validated = $request->validate([
            'serial' => 'required|string',
            'symptoms' => 'nullable|array',
            'description' => 'required|string',
            'method' => 'nullable|string',
        ]);

        $symptomsText = !empty($validated['symptoms']) ? implode(', ', $validated['symptoms']) : 'Reported malfunction';
        $newId = (string) rand(84930, 84999);

        $job = RmaJob::create([
            'id' => $newId,
            'brand' => 'Lenovo',
            'model' => 'ThinkPad X1 Carbon',
            'gen' => 'Gen 11',
            'serial' => strtoupper($validated['serial']),
            'customer_name' => 'Jamie Anderson',
            'warranty_status' => 'Premier Onsite · Active',
            'issue' => $symptomsText . ' — ' . $validated['description'],
            'tech_name' => 'Alex Morgan',
            'tech_initials' => 'AM',
            'time_remaining' => '24h 00m',
            'status' => 'Awaiting parts',
            'priority' => 'Normal',
            'tone' => 'orange',
            'quote_amount' => 60.00,
            'quote_approved' => false,
        ]);

        return redirect()->route('home', [
            'role' => 'customer',
            'page' => 'Track my repair',
            'ticket' => $newId,
        ])->with('success', "Repair ticket #RMA-{$newId} submitted successfully.");
    }

    public function approveQuote($id)
    {
        $job = RmaJob::findOrFail($id);
        $job->quote_approved = true;
        $job->status = 'In repair';
        $job->tone = 'purple';
        $job->save();

        return back()->with('success', 'Quotation approved! Your technician has been notified.');
    }

    public function exportReport(Request $request)
    {
        $role = $request->query('role', 'manager');
        $filename = 'omnifix-report.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function () use ($role) {
            $handle = fopen('php://output', 'w');
            if ($role === 'corporate') {
                fputcsv($handle, ['Asset Tag', 'Employee', 'Department', 'Model', 'Serial', 'Reported Issue', 'Status', 'SLA Remaining']);
                foreach (FleetAsset::all() as $row) {
                    fputcsv($handle, [$row->asset_tag, $row->employee, $row->department, $row->model, $row->serial, $row->issue, $row->status, $row->time_remaining]);
                }
            } else {
                fputcsv($handle, ['Branch', 'Period', 'Total Completed Repairs', 'SLA Compliance Rate', 'First-Time Fix Rate']);
                fputcsv($handle, ['Bangkok Central', 'Last 30 days', '1248', '98.2%', '94.1%']);
                fputcsv($handle, []);
                fputcsv($handle, ['RMA ID', 'Brand', 'Model', 'Serial', 'Customer', 'Issue', 'Technician', 'Status', 'Priority']);
                foreach (RmaJob::all() as $job) {
                    fputcsv($handle, [$job->id, $job->brand, $job->model, $job->serial, $job->customer_name, $job->issue, $job->tech_name, $job->status, $job->priority]);
                }
            }
            fclose($handle);
        };

        return new StreamedResponse($callback, 200, $headers);
    }

    public function login(Request $request)
    {
        if ($request->session()->has('signed_in') && !$request->has('force')) {
            return redirect()->route('home', ['role' => $request->session()->get('role', 'manager')]);
        }

        $demoRoles = [
            [
                'key' => 'manager',
                'title' => 'Center Manager',
                'badge' => 'HQ Operations & Admin',
                'description' => 'Operations overview, technician dispatch matrix, parts inventory oversight & team permissions.',
                'icon' => 'grid',
                'user' => 'Sarah Morgan',
                'roleTitle' => 'Service Manager',
                'avatar' => 'SM',
                'email' => 'sarah.m@omnifix.com',
            ],
            [
                'key' => 'corporate',
                'title' => 'Corporate IT Manager',
                'badge' => 'B2B Enterprise Portal',
                'description' => 'Enterprise fleet health, active asset repairs, standby loaner allocations & corporate SLA metrics.',
                'icon' => 'laptop',
                'user' => 'Nisa Patel',
                'roleTitle' => 'Corporate IT Coordinator',
                'avatar' => 'NP',
                'email' => 'nisa.p@omnifix.com',
            ],
            [
                'key' => 'technician',
                'title' => 'Bench Technician',
                'badge' => 'Service Workbench',
                'description' => 'Diagnostic bench intake, live RMA queue, spare parts requisition & quality control sign-off.',
                'icon' => 'tool',
                'user' => 'Alex Morgan',
                'roleTitle' => 'Senior Technician',
                'avatar' => 'AM',
                'email' => 'alex@omnifix.com',
            ],
            [
                'key' => 'customer',
                'title' => 'General Customer',
                'badge' => 'Consumer Care',
                'description' => 'Direct serial warranty lookup, online intake ticket creation & real-time repair progress tracking.',
                'icon' => 'shield',
                'user' => 'Jamie Anderson',
                'roleTitle' => 'Device Owner',
                'avatar' => 'JA',
                'email' => 'jamie.a@example.com',
            ],
        ];

        return view('pages.login', compact('demoRoles'));
    }

    public function handleLogin(Request $request)
    {
        // 1. One-click Demo Role Login
        $role = $request->input('demo_role') ?? $request->input('role');
        if ($role) {
            $user = $this->getUserForRole($role);
            $request->session()->put('role', $role);
            $request->session()->put('signed_in', true);
            $request->session()->put('user', $user);

            return redirect()->route('home', ['role' => $role])
                ->with('success', "Signed in as {$user['name']} ({$user['title']}).");
        }

        // 2. Standard Form Login / 2FA verification
        $email = $request->input('email', '');
        $digits = $request->input('digits', '');
        $backupCode = $request->input('backup_code', '');

        // If OTP provided, check demo code
        if ($digits && $digits !== '123456' && $backupCode !== 'OMNIFIX-DEMO') {
            return back()->with('error', 'Use demo verification code 123456 or backup code OMNIFIX-DEMO.');
        }

        // Map email to role
        $role = 'technician';
        if (str_contains(strtolower($email), 'sarah') || str_contains(strtolower($email), 'manager')) {
            $role = 'manager';
        } elseif (str_contains(strtolower($email), 'nisa') || str_contains(strtolower($email), 'corp')) {
            $role = 'corporate';
        } elseif (str_contains(strtolower($email), 'jamie') || str_contains(strtolower($email), 'cust')) {
            $role = 'customer';
        }

        $user = $this->getUserForRole($role);
        $request->session()->put('role', $role);
        $request->session()->put('signed_in', true);
        $request->session()->put('user', $user);

        return redirect()->route('home', ['role' => $role])
            ->with('success', "Welcome back, {$user['name']}!");
    }

    public function logout(Request $request)
    {
        $request->session()->forget(['signed_in', 'role', 'user']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('info', 'Signed out successfully.');
    }

    public function saveStaff(Request $request)
    {
        $id = $request->input('id');
        $staff = $id ? StaffMember::find($id) : new StaffMember();
        if (!$staff) {
            $staff = new StaffMember();
        }

        $staff->name = $request->input('name');
        $staff->email = $request->input('email');
        $staff->role = $request->input('role', 'Bench Tech');
        $staff->bench = $request->input('bench', 'HQ Operations');
        $staff->two_fa = $request->boolean('two_fa', true);
        $staff->active = $request->boolean('active', true);

        // Permissions array of 5 booleans: [Ticket dispatch, Warranty claim approval, Parts requisition, Customer quoting, Financial reports]
        $permissions = [];
        for ($i = 0; $i < 5; $i++) {
            $permissions[] = $request->has("permissions.{$i}") || $request->input("perm_{$i}") === '1';
        }
        $staff->permissions = $permissions;
        $staff->save();

        return back()->with('success', $id ? 'Staff role and permissions updated.' : 'Staff invitation added to the team directory.');
    }

    public function toggleStaff($id)
    {
        $staff = StaffMember::findOrFail($id);
        $staff->active = !$staff->active;
        $staff->save();

        return back()->with('success', "Staff account {$staff->name} " . ($staff->active ? 'activated.' : 'deactivated.'));
    }

    public function resetStaffPassword($id)
    {
        $staff = StaffMember::findOrFail($id);
        return back()->with('info', "Password reset requested for {$staff->email}. (Demo notice: no email sent)");
    }

    private function getUserForRole(string $role): array
    {
        return match ($role) {
            'manager' => [
                'name' => 'Sarah Morgan',
                'title' => 'Service Manager',
                'avatar' => 'SM',
                'email' => 'sarah.m@omnifix.com',
                'bench' => 'Bangkok Central',
                'staffId' => 'MGR-1042',
                'department' => 'Service Operations',
            ],
            'corporate' => [
                'name' => 'Nisa Patel',
                'title' => 'Corporate IT Coordinator',
                'avatar' => 'NP',
                'email' => 'nisa.p@omnifix.com',
                'bench' => 'Corporate Service Desk',
                'staffId' => 'CORP-2210',
                'department' => 'Fleet Management',
            ],
            'customer' => [
                'name' => 'Jamie Anderson',
                'title' => 'General Customer',
                'avatar' => 'JA',
                'email' => 'jamie.a@example.com',
                'bench' => 'Consumer Care',
                'staffId' => 'CUST-9901',
                'department' => 'Personal Devices',
            ],
            default => [
                'name' => 'Alex Morgan',
                'title' => 'Senior Technician',
                'avatar' => 'AM',
                'email' => 'alex@omnifix.com',
                'bench' => 'Bench 01 · SMD / Logic board',
                'staffId' => 'TECH-8402',
                'department' => 'Hardware Diagnostics',
            ],
        };
    }
}
