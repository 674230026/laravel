<?php

namespace App\Http\Controllers;

use App\Models\DispatchTicket;
use App\Models\FleetAsset;
use App\Models\InventoryPart;
use App\Models\LoanerDeployment;
use App\Models\RmaJob;
use App\Models\StaffMember;
use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

class OmniFixController extends Controller
{
    public function __construct(
        public NotificationService $notifications
    ) {}

    public function index(Request $request)
    {
        // Auto-authenticate if demo role or test requested and not logged in
        if (! Auth::check()) {
            if ($request->has('role')) {
                $seedUser = User::where('role', $request->query('role'))->first();
                if ($seedUser) {
                    Auth::login($seedUser);
                }
            }
        }

        // Require sign in
        if (! Auth::check() && ! $request->session()->has('signed_in')) {
            return redirect()->route('login');
        }

        $authUser = Auth::user();
        $role = $request->query('role', $authUser?->role ?? $request->session()->get('role', 'manager'));
        $request->session()->put('role', $role);
        $request->session()->put('signed_in', true);

        $previousRole = $request->session()->get('active_role');
        if ($previousRole !== $role || ! $request->session()->has('user')) {
            if ($authUser && $authUser->role === $role) {
                $isAvatarUrl = isset($authUser->avatar) && (str_starts_with($authUser->avatar, 'http') || str_starts_with($authUser->avatar, '/'));
                $currentUser = [
                    'name' => $authUser->name,
                    'title' => $authUser->title ?? 'Authorized Staff',
                    'avatar' => $authUser->avatar ?? 'OM',
                    'avatar_url' => $isAvatarUrl ? $authUser->avatar : null,
                    'email' => $authUser->email,
                    'bench' => $authUser->bench ?? 'Bangkok Central',
                    'staffId' => $authUser->staff_id ?? 'STAFF-1001',
                    'department' => $authUser->department ?? 'Service Operations',
                    'phone' => $authUser->phone ?? '',
                ];
            } else {
                $currentUser = $this->getUserForRole($role);
            }
            $request->session()->put('user', $currentUser);
            $request->session()->put('active_role', $role);
        } else {
            $currentUser = $request->session()->get('user');
            if ($authUser && $authUser->role === $role && ! empty($authUser->avatar)) {
                $isAvatarUrl = str_starts_with($authUser->avatar, 'http') || str_starts_with($authUser->avatar, '/');
                $currentUser['avatar'] = $authUser->avatar;
                if ($isAvatarUrl) {
                    $currentUser['avatar_url'] = $authUser->avatar;
                }
                $request->session()->put('user', $currentUser);
            }
        }

        $defaultPage = match ($role) {
            'manager' => 'Operations overview',
            'corporate' => 'Fleet overview',
            'customer' => 'Warranty & repair',
            default => 'My workbench',
        };
        $page = $request->query('page', $defaultPage);
        $selectedId = $request->query('selected');
        $tab = $request->query('tab', 'All jobs');
        $search = $request->query('query', '');
        $brand = $request->query('brand', 'All brands');
        $sla = $request->query('sla', 'All SLA statuses');
        $bench = $request->query('bench', 'All technicians');
        $stockFilter = $request->query('stockFilter', 'All parts');
        $range = $request->query('range', 'Last 30 days');
        $branch = $request->query('branch', 'Bangkok Central');
        $company = $request->query('company', 'Acme Corp');

        // Selected Job for Bench Inspection
        $selectedJob = $selectedId ? RmaJob::find($selectedId) : null;

        // Technician Workbench Jobs query
        $jobsQuery = RmaJob::query();
        if ($search) {
            $jobsQuery->where(function ($q) use ($search) {
                $q->where('id', 'like', "%{$search}%")
                    ->orWhere('model', 'like', "%{$search}%")
                    ->orWhere('serial', 'like', "%{$search}%")
                    ->orWhere('issue', 'like', "%{$search}%")
                    ->orWhere('tech_name', 'like', "%{$search}%");
            });
        }
        if ($brand !== 'All brands') {
            $jobsQuery->where('brand', $brand);
        }
        if ($sla === 'Approaching SLA') {
            $jobsQuery->where('priority', 'High');
        } elseif ($sla === 'On track') {
            $jobsQuery->where('priority', '!=', 'High');
        }
        if ($bench !== 'All technicians') {
            $jobsQuery->where('tech_name', $bench);
        }
        if ($tab === 'My jobs') {
            $jobsQuery->where('tech_initials', 'AM');
        } elseif ($tab === 'Awaiting parts') {
            $jobsQuery->where('status', 'Awaiting parts');
        } elseif ($tab === 'Quality check') {
            $jobsQuery->where('status', 'Quality check');
        }
        $filteredJobs = $jobsQuery->orderBy('created_at', 'desc')->get();
        $allJobs = RmaJob::all();

        // Inventory Parts query
        $partsQuery = InventoryPart::query();
        if ($search && ($page === 'Stock oversight' || $page === 'Parts inventory')) {
            $partsQuery->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%")
                    ->orWhere('compatible_models', 'like', "%{$search}%");
            });
        }
        if ($stockFilter === 'On order') {
            $partsQuery->where('on_order', true);
        } elseif ($stockFilter === 'Out of stock') {
            $partsQuery->where('stock', 0);
        } elseif ($stockFilter === 'Low stock') {
            $partsQuery->whereColumn('stock', '<', 'min_stock');
        }
        $parts = $partsQuery->get();

        // Corporate Fleet Assets
        $fleetQuery = FleetAsset::query();
        if ($search && ($role === 'corporate')) {
            $fleetQuery->where(function ($q) use ($search) {
                $q->where('employee', 'like', "%{$search}%")
                    ->orWhere('asset_tag', 'like', "%{$search}%")
                    ->orWhere('model', 'like', "%{$search}%")
                    ->orWhere('serial', 'like', "%{$search}%");
            });
        }
        $fleetAssets = $fleetQuery->get();

        // Dispatch Tickets
        $dispatchTickets = DispatchTicket::all();
        $benches = ['David K.', 'Nisa P.', 'Somchai T.', 'Unassigned'];

        // Loaners
        $loaners = LoanerDeployment::all();

        // Customer Tracking RMA (default 84920)
        $trackJob = RmaJob::find('84920') ?? $allJobs->first();

        // User
        $user = User::first() ?? new User(['name' => $currentUser['name'], 'email' => $currentUser['email']]);
        $staffMembers = StaffMember::orderBy('id', 'asc')->get();
        $pendingUsers = ($role === 'manager') ? User::where('is_approved', false)->orderBy('created_at', 'desc')->get() : collect();

        return view('pages.index', compact(
            'role',
            'page',
            'selectedJob',
            'tab',
            'search',
            'brand',
            'sla',
            'bench',
            'stockFilter',
            'range',
            'branch',
            'company',
            'filteredJobs',
            'allJobs',
            'parts',
            'fleetAssets',
            'dispatchTickets',
            'benches',
            'loaners',
            'trackJob',
            'user',
            'currentUser',
            'staffMembers',
            'pendingUsers'
        ));
    }

    public function reassignDispatch(Request $request)
    {
        $validated = $request->validate([
            'id' => 'required|string',
            'bench' => 'required|integer|min:0|max:3',
        ]);

        $benches = ['David K.', 'Nisa P.', 'Somchai T.', 'Unassigned'];

        if ($validated['bench'] !== 3) {
            $count = DispatchTicket::where('bench', $validated['bench'])->where('id', '!=', $validated['id'])->count();
            if ($count >= 5) {
                return back()->with('error', 'This bench is at capacity. Choose an available technician.');
            }
        }

        $ticket = DispatchTicket::find($validated['id']);
        if ($ticket) {
            $ticket->bench = $validated['bench'];
            $ticket->save();
        }

        $benchName = $benches[$validated['bench']];

        $job = RmaJob::find($validated['id']);
        if ($job) {
            $job->tech_name = $benchName;
            $job->status = 'In repair';
            $job->tone = 'purple';
            $job->save();

            if ($validated['bench'] !== 3) {
                // Trigger 3 (User): เมื่อ ช่าง รับงานซ่อม
                $this->notifications->notifyUserJobAccepted($job);

                // Trigger 5 (Tech): เมื่อมีงานเข้าใหม่
                $this->notifications->notifyTechNewJobAssigned($job);
            }
        }

        return back()->with('success', "RMA-{$validated['id']} assigned to {$benchName}. Email notifications dispatched.");
    }

    public function markRepaired(Request $request, $id)
    {
        $job = RmaJob::findOrFail($id);
        $job->status = 'Quality check';
        $job->tone = 'green';
        if ($request->has('notes')) {
            $job->technician_notes = $request->input('notes');
        }
        if ($request->has('checklist')) {
            $job->checklist = $request->input('checklist');
        }

        // Save condition evidence photos uploaded by technician
        if ($request->hasFile('evidence_files')) {
            $evidence = is_array($job->evidence_photos) ? $job->evidence_photos : [];
            foreach ($request->file('evidence_files') as $label => $file) {
                if ($file && $file->isValid()) {
                    $path = $file->store('evidence', 'public');
                    $evidence[] = [
                        'type' => is_string($label) ? $label : 'technician_evidence',
                        'label' => is_string($label) ? ucwords(str_replace('_', ' ', $label)) : 'Technician Evidence',
                        'url' => asset('storage/'.$path),
                        'name' => $file->getClientOriginalName(),
                        'uploaded_at' => now()->timezone('Asia/Bangkok')->format('d/m/Y H:i'),
                    ];
                }
            }
            $job->evidence_photos = $evidence;
        }

        $job->save();

        // Trigger 4 (User): เมื่อ ช่าง ซ่อมเสร็จ
        $this->notifications->notifyUserRepairCompleted($job);

        return redirect()->route('home', [
            'role' => 'technician',
            'page' => 'My workbench',
        ])->with('success', 'Repair completed. Condition evidence saved, ticket transferred to QC and completion email dispatched to customer.');
    }

    public function requestLoaner(Request $request)
    {
        $validated = $request->validate([
            'ticket_id' => 'required|string',
            'profile' => 'required|string',
            'urgency' => 'nullable|string',
            'address' => 'nullable|string',
        ]);

        $count = LoanerDeployment::count();
        if ($count >= 5) {
            return back()->with('error', 'Maximum entitled loaner units (5) already deployed.');
        }

        $asset = FleetAsset::find($validated['ticket_id']);
        $employee = $asset ? $asset->employee : 'Corporate Staff';

        LoanerDeployment::create([
            'ticket_id' => $validated['ticket_id'],
            'employee' => $employee,
            'profile' => $validated['profile'],
            'urgency' => $validated['urgency'] ?? 'Standard · 24h',
            'address' => $validated['address'] ?? 'Headquarters reception',
            'status' => 'Deployed',
        ]);

        return back()->with('success', "Loaner dispatch confirmed for {$employee}. Delivery to ".($validated['address'] ?? 'Headquarters').'.');
    }

    public function returnLoaner($ticket_id)
    {
        LoanerDeployment::where('ticket_id', $ticket_id)->delete();

        return back()->with('success', 'Loaner return recorded. Entitlement is available again.');
    }

    public function orderPart($sku)
    {
        $part = InventoryPart::findOrFail($sku);
        $part->on_order = true;
        $part->save();

        // Trigger 2 (Admin): เมื่อ ช่าง ส่งขออะไหล่
        $this->notifications->notifyAdminPartRequested($part, 'Alex Morgan');

        return back()->with('success', "Factory replenishment PO approved for {$sku}. Notification email sent to Admin.");
    }

    public function receivePart($sku)
    {
        $part = InventoryPart::findOrFail($sku);
        $part->on_order = false;
        $part->stock += 5;
        $part->save();

        // Trigger 6 (Tech): เมื่อได้รับอะไหล่
        $this->notifications->notifyTechPartReceived($part);

        return back()->with('success', "Part {$sku} received into inventory (+5 units). Notification email dispatched to technician.");
    }

    public function reservePart($sku)
    {
        $part = InventoryPart::findOrFail($sku);
        $part->reserved += 1;
        $part->save();

        return back()->with('success', "{$part->name} reserved for your bench.");
    }

    public function batchOrderParts()
    {
        InventoryPart::whereColumn('stock', '<', 'min_stock')->update(['on_order' => true]);

        return back()->with('success', 'Replenishment purchase orders approved for all low-stock components.');
    }

    public function checkWarranty(Request $request)
    {
        $serial = strtoupper(trim($request->input('serial', '')));
        if (strlen($serial) < 8) {
            return response()->json(['success' => false, 'message' => 'Please enter a serial number with at least 8 characters.']);
        }

        $existing = RmaJob::where('serial', $serial)->first();
        if ($existing) {
            return response()->json([
                'success' => true,
                'model' => $existing->model,
                'gen' => $existing->gen,
                'serial' => $existing->serial,
                'warranty' => $existing->warranty_status,
                'active' => true,
            ]);
        }

        return response()->json([
            'success' => true,
            'model' => 'ThinkPad X1 Carbon Gen 11',
            'gen' => 'Intel Core i7-1365U · 16GB',
            'serial' => $serial,
            'warranty' => 'Active · Premier Onsite NBD · 184 days left',
            'active' => true,
        ]);
    }

    public function submitCustomerTicket(Request $request)
    {
        $validated = $request->validate([
            'serial' => 'required|string',
            'customer_name' => 'nullable|string',
            'customer_email' => 'nullable|email',
            'customer_phone' => 'nullable|string',
            'symptoms' => 'nullable|array',
            'description' => 'required|string',
            'method' => 'nullable|string',
        ]);

        $symptomsText = ! empty($validated['symptoms']) ? implode(', ', $validated['symptoms']) : 'Reported malfunction';
        $newId = (string) rand(84930, 84999);
        $customerName = ! empty($validated['customer_name']) ? trim($validated['customer_name']) : 'Jamie Anderson';
        $customerEmail = ! empty($validated['customer_email']) ? trim($validated['customer_email']) : 'watweera82@gmail.com';
        $customerPhone = ! empty($validated['customer_phone']) ? trim($validated['customer_phone']) : '+66 81 234 5678';

        $serial = strtoupper($validated['serial']);
        if (RmaJob::where('serial', $serial)->exists()) {
            $serial = $serial.'-R'.rand(10, 99);
        }

        $photos = [];
        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $file) {
                if ($file && $file->isValid()) {
                    $path = $file->store('evidence', 'public');
                    $photos[] = [
                        'type' => 'customer_intake',
                        'label' => 'Customer Diagnostic Photo',
                        'url' => asset('storage/'.$path),
                        'name' => $file->getClientOriginalName(),
                        'uploaded_at' => now()->timezone('Asia/Bangkok')->format('d/m/Y H:i'),
                    ];
                }
            }
        }

        $job = RmaJob::create([
            'id' => $newId,
            'brand' => 'Lenovo',
            'model' => 'ThinkPad X1 Carbon',
            'gen' => 'Gen 11',
            'serial' => $serial,
            'customer_name' => $customerName,
            'customer_email' => $customerEmail,
            'customer_phone' => $customerPhone,
            'warranty_status' => 'Premier Onsite · Active',
            'issue' => $symptomsText.' — '.$validated['description'],
            'tech_name' => 'Alex Morgan',
            'tech_initials' => 'AM',
            'time_remaining' => '24h 00m',
            'status' => 'Awaiting parts',
            'priority' => 'Normal',
            'tone' => 'orange',
            'quote_amount' => 60.00,
            'quote_approved' => false,
            'evidence_photos' => $photos,
        ]);

        // Trigger 1 (Admin): เมื่อ user กดเริ่มการซ่อมใหม่
        $this->notifications->notifyAdminNewRepair($job);

        // Trigger 5 (Tech): เมื่อมีงานเข้าใหม่
        $this->notifications->notifyTechNewJobAssigned($job);

        return redirect()->route('home', [
            'role' => 'customer',
            'page' => 'Track my repair',
            'ticket' => $newId,
        ])->with('success', "Repair ticket #RMA-{$newId} submitted successfully. Notification emails dispatched.");
    }

    public function approveQuote($id)
    {
        $job = RmaJob::findOrFail($id);
        $job->quote_approved = true;
        $job->status = 'In repair';
        $job->tone = 'purple';
        $job->save();

        return back()->with('success', 'Quotation approved! Your technician has been notified.');
    }

    public function exportReport(Request $request)
    {
        $role = $request->query('role', 'manager');
        $filename = 'omnifix-report.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function () use ($role) {
            $handle = fopen('php://output', 'w');
            if ($role === 'corporate') {
                fputcsv($handle, ['Asset Tag', 'Employee', 'Department', 'Model', 'Serial', 'Reported Issue', 'Status', 'SLA Remaining']);
                foreach (FleetAsset::all() as $row) {
                    fputcsv($handle, [$row->asset_tag, $row->employee, $row->department, $row->model, $row->serial, $row->issue, $row->status, $row->time_remaining]);
                }
            } else {
                fputcsv($handle, ['Branch', 'Period', 'Total Completed Repairs', 'SLA Compliance Rate', 'First-Time Fix Rate']);
                fputcsv($handle, ['Bangkok Central', 'Last 30 days', '1248', '98.2%', '94.1%']);
                fputcsv($handle, []);
                fputcsv($handle, ['RMA ID', 'Brand', 'Model', 'Serial', 'Customer', 'Issue', 'Technician', 'Status', 'Priority']);
                foreach (RmaJob::all() as $job) {
                    fputcsv($handle, [$job->id, $job->brand, $job->model, $job->serial, $job->customer_name, $job->issue, $job->tech_name, $job->status, $job->priority]);
                }
            }
            fclose($handle);
        };

        return new StreamedResponse($callback, 200, $headers);
    }

    public function login(Request $request)
    {
        if ($request->session()->has('signed_in') && ! $request->has('force')) {
            return redirect()->route('home', ['role' => $request->session()->get('role', 'manager')]);
        }

        return view('pages.login');
    }

    public function handleLogin(Request $request)
    {
        $email = trim($request->input('email', ''));
        $password = $request->input('password', '');
        $digits = $request->input('digits', '');
        $backupCode = $request->input('backup_code', '');

        // If OTP provided, check demo code
        if ($digits && $digits !== '123456' && $backupCode !== 'OMNIFIX-DEMO') {
            return back()->with('error', 'Use verification code 123456 or backup code OMNIFIX-DEMO.');
        }

        if ($email && $password) {
            $existingUser = User::where('email', $email)->first();
            if ($existingUser && ! $existingUser->is_approved) {
                return back()->withInput($request->only('email'))
                    ->with('error', 'บัญชีนี้ยังอยู่ระหว่างรอการยืนยันจาก Admin กรุณารออีเมลยืนยัน หรือติดต่อ Admin: watweera82@gmail.com');
            }

            if (Auth::attempt(['email' => $email, 'password' => $password], $request->boolean('remember', true))) {
                $request->session()->regenerate();
                $user = Auth::user();

                if (! $user->is_approved) {
                    Auth::logout();
                    $request->session()->invalidate();
                    $request->session()->regenerateToken();

                    return back()->withInput($request->only('email'))
                        ->with('error', 'บัญชีนี้ยังอยู่ระหว่างรอการยืนยันจาก Admin กรุณารออีเมลยืนยัน หรือติดต่อ Admin: watweera82@gmail.com');
                }

                $role = $user->role ?? 'customer';
                $isAvatarUrl = isset($user->avatar) && (str_starts_with($user->avatar, 'http') || str_starts_with($user->avatar, '/'));
                $userData = [
                    'name' => $user->name,
                    'title' => $user->title ?? 'Authorized Staff',
                    'avatar' => $user->avatar ?? 'OM',
                    'avatar_url' => $isAvatarUrl ? $user->avatar : null,
                    'email' => $user->email,
                    'bench' => $user->bench ?? 'Bangkok Central',
                    'staffId' => $user->staff_id ?? 'STAFF-1001',
                    'department' => $user->department ?? 'Service Operations',
                    'phone' => $user->phone ?? '',
                ];
                $request->session()->put('role', $role);
                $request->session()->put('signed_in', true);
                $request->session()->put('user', $userData);

                return redirect()->intended(route('home', ['role' => $role]))
                    ->with('success', "Welcome back, {$user->name}!");
            }
        }

        return back()->withInput($request->only('email'))
            ->with('error', 'Invalid email or password.');
    }

    public function handleRegister(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email',
            'role' => 'required|string|in:customer,technician,corporate,manager',
            'password' => 'required|string|min:8',
        ], [
            'email.unique' => 'This email address is already registered in the system.',
            'password.min' => 'The password must be at least 8 characters.',
        ]);

        $role = $validated['role'];
        $defaultTitle = match ($role) {
            'manager' => 'Service Manager',
            'corporate' => 'Corporate IT Coordinator',
            'technician' => 'Hardware Technician',
            default => 'Device Owner',
        };
        $defaultDept = match ($role) {
            'manager' => 'Service Operations',
            'corporate' => 'Fleet Management',
            'technician' => 'Hardware Diagnostics',
            default => 'Personal Devices',
        };

        $nameParts = explode(' ', trim($validated['name']));
        $avatar = strtoupper(substr($nameParts[0] ?? 'U', 0, 1).substr($nameParts[1] ?? '', 0, 1)) ?: 'OM';

        $isCustomer = ($role === 'customer');
        $approvalToken = $isCustomer ? null : Str::random(40);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'role' => $role,
            'title' => $defaultTitle,
            'department' => $defaultDept,
            'avatar' => $avatar,
            'password' => Hash::make($validated['password']),
            'is_approved' => $isCustomer,
            'approval_token' => $approvalToken,
        ]);

        if ($isCustomer) {
            Auth::login($user, true);
            $userData = [
                'name' => $user->name,
                'title' => $user->title,
                'avatar' => $user->avatar,
                'avatar_url' => null,
                'email' => $user->email,
                'bench' => 'Bangkok Central',
                'staffId' => 'CUST-'.rand(1000, 9999),
                'department' => $user->department,
                'phone' => '',
            ];
            $request->session()->put('role', $role);
            $request->session()->put('signed_in', true);
            $request->session()->put('user', $userData);

            return redirect()->route('home', ['role' => $role])
                ->with('success', "Registration successful! Welcome to OmniFix Care, {$user->name}.");
        }

        // Non-customer roles: Pending Admin approval & notify Admin
        $this->notifications->notifyAdminNewStaffRegistration($user);

        return redirect()->route('login')->with('pending_registration', [
            'name' => $user->name,
            'email' => $user->email,
            'role' => match ($role) {
                'technician' => 'ช่างเทคนิคประจำโต๊ะ (Hardware Technician)',
                'corporate' => 'ผู้ดูแลไอทีองค์กร (Corporate IT)',
                'manager' => 'ผู้จัดการศูนย์บริการ (Service Manager)',
                default => $role,
            },
            'admin_email' => 'watweera82@gmail.com',
        ]);
    }

    public function approveUserByToken(string $token)
    {
        $user = User::where('approval_token', $token)->first();
        if (! $user) {
            return redirect()->route('login')->with('info', 'ลิงก์อนุมัตินี้ถูกใช้งานแล้วหรือหมดอายุ');
        }

        $user->is_approved = true;
        $user->approval_token = null;
        $user->save();

        $this->notifications->notifyUserAccountApproved($user);

        return redirect()->route('login')->with('success', "อนุมัติบัญชี {$user->name} ({$user->email}) สำเร็จแล้ว! ระบบได้ส่งอีเมลแจ้งเตือนไปยังผู้ใช้แล้ว");
    }

    public function approveUserById(int $id)
    {
        $user = User::findOrFail($id);
        $user->is_approved = true;
        $user->approval_token = null;
        $user->save();

        $this->notifications->notifyUserAccountApproved($user);

        return back()->with('success', "อนุมัติบัญชี {$user->name} ({$user->email}) เรียบร้อยแล้ว! ระบบได้ส่งอีเมลแจ้งเตือนไปยังผู้สมัครแล้ว");
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->forget(['signed_in', 'role', 'user', 'active_role']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('info', 'Signed out successfully.');
    }

    public function saveStaff(Request $request)
    {
        $id = $request->input('id');
        $staff = $id ? StaffMember::find($id) : new StaffMember;
        if (! $staff) {
            $staff = new StaffMember;
        }

        $staff->name = $request->input('name');
        $staff->email = $request->input('email');
        $staff->role = $request->input('role', 'Bench Tech');
        $staff->bench = $request->input('bench', 'HQ Operations');
        $staff->two_fa = $request->boolean('two_fa', true);
        $staff->active = $request->boolean('active', true);

        // Permissions array of 5 booleans: [Ticket dispatch, Warranty claim approval, Parts requisition, Customer quoting, Financial reports]
        $permissions = [];
        for ($i = 0; $i < 5; $i++) {
            $permissions[] = $request->has("permissions.{$i}") || $request->input("perm_{$i}") === '1';
        }
        $staff->permissions = $permissions;
        $staff->save();

        return back()->with('success', $id ? 'Staff role and permissions updated.' : 'Staff invitation added to the team directory.');
    }

    public function toggleStaff($id)
    {
        $staff = StaffMember::findOrFail($id);
        $staff->active = ! $staff->active;
        $staff->save();

        return back()->with('success', "Staff account {$staff->name} ".($staff->active ? 'activated.' : 'deactivated.'));
    }

    public function resetStaffPassword($id)
    {
        $staff = StaffMember::findOrFail($id);

        return back()->with('info', "Password reset requested for {$staff->email}. (Demo notice: no email sent)");
    }

    public function saveSettings(Request $request)
    {
        $role = $request->session()->get('role', 'manager');
        $userSession = $request->session()->get('user', $this->getUserForRole($role));

        // 1. Password change form submission
        if ($request->filled('new_password')) {
            $request->validate([
                'current_password' => 'nullable|string',
                'new_password' => 'required|string|min:8',
                'confirm_password' => 'required|same:new_password',
            ], [
                'new_password.min' => 'The new password must be at least 8 characters.',
                'confirm_password.same' => 'The password confirmation does not match.',
            ]);

            return back()->with('success', 'Password updated successfully. Account security has been enhanced.')
                ->with('active_profile_tab', 'security');
        }

        // 2. Profile details submission
        $firstName = trim($request->input('first_name', ''));
        $lastName = trim($request->input('last_name', ''));
        $name = trim("{$firstName} {$lastName}");

        if ($name) {
            $userSession['name'] = $name;
            $parts = explode(' ', $name);
            $initials = strtoupper(substr($parts[0] ?? '', 0, 1).substr($parts[1] ?? '', 0, 1));
            $userSession['avatar'] = $initials ?: ($userSession['avatar'] ?? 'SM');
        }

        if ($request->filled('department')) {
            $userSession['department'] = $request->input('department');
        }
        if ($request->filled('title')) {
            $userSession['title'] = $request->input('title');
        }
        if ($request->filled('phone')) {
            $userSession['phone'] = $request->input('phone');
        }

        // Handle avatar file upload
        if ($request->hasFile('avatar_file')) {
            $avatarFile = $request->file('avatar_file');
            if ($avatarFile && $avatarFile->isValid()) {
                $path = $avatarFile->store('avatars', 'public');
                $userSession['avatar_url'] = asset('storage/'.$path);
                $userSession['avatar'] = asset('storage/'.$path);
            }
        }

        $request->session()->put('user', $userSession);

        $dbUser = Auth::user() ?? User::where('email', $userSession['email'] ?? '')->first() ?? User::first();
        if ($dbUser) {
            if ($name) {
                $dbUser->name = $name;
            }
            if ($request->filled('department')) {
                $dbUser->department = $request->input('department');
            }
            if ($request->filled('title')) {
                $dbUser->title = $request->input('title');
            }
            if ($request->filled('phone')) {
                $dbUser->phone = $request->input('phone');
            }
            if (! empty($userSession['avatar_url'])) {
                $dbUser->avatar = $userSession['avatar_url'];
            }
            $dbUser->save();
        }

        return back()->with('success', 'Profile information updated successfully.')
            ->with('active_profile_tab', 'profile');
    }

    public function sendTestEmail(Request $request)
    {
        $target = $request->input('test_email', env('MAIL_FROM_ADDRESS', 'watweera82@gmail.com'));
        $sent = $this->notifications->sendTestConnectionEmail($target);

        return back()->with(
            $sent ? 'success' : 'error',
            $sent ? "Test email dispatched successfully to {$target} via Gmail SMTP!" : 'Failed to dispatch email. Please check your SMTP settings.'
        )->with('active_profile_tab', 'security');
    }

    private function getUserForRole(string $role): array
    {
        return match ($role) {
            'manager' => [
                'name' => 'Sarah Morgan',
                'title' => 'Service Manager',
                'avatar' => 'SM',
                'email' => 'sarah.m@omnifix.com',
                'bench' => 'Bangkok Central',
                'staffId' => 'MGR-1042',
                'department' => 'Service Operations',
            ],
            'corporate' => [
                'name' => 'Nisa Patel',
                'title' => 'Corporate IT Coordinator',
                'avatar' => 'NP',
                'email' => 'nisa.p@omnifix.com',
                'bench' => 'Corporate Service Desk',
                'staffId' => 'CORP-2210',
                'department' => 'Fleet Management',
            ],
            'customer' => [
                'name' => 'Jamie Anderson',
                'title' => 'General Customer',
                'avatar' => 'JA',
                'email' => 'jamie.a@example.com',
                'bench' => 'Consumer Care',
                'staffId' => 'CUST-9901',
                'department' => 'Personal Devices',
            ],
            default => [
                'name' => 'Alex Morgan',
                'title' => 'Senior Technician',
                'avatar' => 'AM',
                'email' => 'alex@omnifix.com',
                'bench' => 'Bench 01 · SMD / Logic board',
                'staffId' => 'TECH-8402',
                'department' => 'Hardware Diagnostics',
            ],
        };
    }
}
