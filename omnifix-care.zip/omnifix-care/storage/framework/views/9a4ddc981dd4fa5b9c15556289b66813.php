<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'OmniFix Care'); ?> — Authorized Service Center</title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;450;500;550;600;650;700;750;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/advanced.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
    <style>
        /* Smooth transitions & additional ergonomics */
        .toast-enter { transform: translate(-50%, 20px); opacity: 0; }
        /* Modern Segmented Pill Tabs for Tables & Workbenches */
        .queue-tabs {
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            padding: 12px 20px !important;
            border-bottom: 1px solid #edf0f4 !important;
            background: #fafbfc !important;
            flex-wrap: wrap !important;
        }

        .queue-tabs .tab-btn,
        .queue-tabs a.tab-btn,
        .queue-tabs a,
        .queue-tabs button {
            display: inline-flex !important;
            align-items: center !important;
            gap: 7px !important;
            padding: 7px 15px !important;
            border-radius: 9999px !important;
            font-size: 11.5px !important;
            font-weight: 550 !important;
            color: #64748b !important;
            text-decoration: none !important;
            background: transparent !important;
            border: 1px solid transparent !important;
            transition: all 0.18s ease-in-out !important;
            cursor: pointer !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            outline: none !important;
        }

        .queue-tabs .tab-btn:hover,
        .queue-tabs a.tab-btn:hover,
        .queue-tabs a:hover,
        .queue-tabs button:hover {
            color: #0f172a !important;
            background: #f1f5f9 !important;
            text-decoration: none !important;
        }

        .queue-tabs .tab-btn.selected,
        .queue-tabs .tab-btn.active,
        .queue-tabs a.tab-btn.selected,
        .queue-tabs a.tab-btn.active,
        .queue-tabs a.selected,
        .queue-tabs button.selected,
        .queue-tabs button.active {
            color: #ea580c !important;
            background: #fff0e5 !important;
            border-color: #ffd8bf !important;
            font-weight: 700 !important;
            box-shadow: 0 1px 3px rgba(234, 88, 12, 0.08) !important;
            text-decoration: none !important;
        }

        .queue-tabs .tab-btn span,
        .queue-tabs a.tab-btn span,
        .queue-tabs a span,
        .queue-tabs button span {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            padding: 2px 7px !important;
            border-radius: 9999px !important;
            font-size: 10px !important;
            font-weight: 650 !important;
            background: #e2e8f0 !important;
            color: #475569 !important;
            min-width: 18px !important;
            height: 18px !important;
            box-sizing: border-box !important;
            transition: all 0.18s ease-in-out !important;
        }

        .queue-tabs .tab-btn.selected span,
        .queue-tabs a.tab-btn.selected span,
        .queue-tabs a.selected span,
        .queue-tabs button.selected span {
            background: #ea580c !important;
            color: #ffffff !important;
        }

        /* Profile Subnav Tabs */
        .profile-subnav {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .profile-subnav button {
            display: flex !important;
            align-items: center !important;
            width: 100% !important;
            padding: 11px 16px !important;
            border-radius: 9px !important;
            font-size: 12.5px !important;
            font-weight: 550 !important;
            color: #64748b !important;
            background: transparent !important;
            border: 1px solid transparent !important;
            text-align: left !important;
            cursor: pointer !important;
            transition: all 0.15s ease !important;
            outline: none !important;
        }

        .profile-subnav button:hover {
            background: #f8fafc !important;
            color: #0f172a !important;
        }

        .profile-subnav button.active {
            background: #fff0e5 !important;
            border-color: #ffd8bf !important;
            color: #ea580c !important;
            font-weight: 700 !important;
        }

        /* Action buttons in inventory table */
        .action-link-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 11px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 650;
            text-decoration: none !important;
            transition: all 0.15s ease;
        }
        .action-link-reorder {
            color: #d97706;
            background: #fffbeb;
            border: 1px solid #fde68a;
        }
        .action-link-reorder:hover {
            background: #f59e0b;
            color: #ffffff;
        }
        .action-link-check {
            color: #475569;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
        }
        .action-link-check:hover {
            background: #f1f5f9;
            color: #0f172a;
        }

        /* Navigation Workspace arrangement matching screenshot */
        .sidebar {
            width: 242px !important;
            background: #ffffff !important;
            border-right: 1px solid #e9ecf1 !important;
            box-sizing: border-box !important;
            padding: 0 16px 20px !important;
            position: fixed !important;
            inset: 0 auto 0 0 !important;
            display: flex !important;
            flex-direction: column !important;
            z-index: 20 !important;
        }

        .sidebar-header {
            height: 77px !important;
            min-height: 77px !important;
            display: flex !important;
            align-items: center !important;
            border-bottom: 1px solid #e9ecf1 !important;
            margin: 0 -16px 0 !important;
            padding: 0 16px !important;
            box-sizing: border-box !important;
        }

        .main-shell {
            margin-left: 242px !important;
            width: calc(100% - 242px) !important;
        }

        .topbar {
            height: 77px !important;
            min-height: 77px !important;
            background: #ffffff !important;
            border-bottom: 1px solid #e9ecf1 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 0 34px !important;
            box-sizing: border-box !important;
        }

        .nav-label {
            font-size: 11px !important;
            letter-spacing: 1.3px !important;
            color: #929ba8 !important;
            padding: 0 14px !important;
            margin: 22px 0 12px !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            display: block !important;
            line-height: 1 !important;
        }

        .sidebar nav, .sidebar-nav {
            display: flex !important;
            flex-direction: column !important;
            gap: 4px !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        a.nav-item, button.nav-item, .nav-item {
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            width: 100% !important;
            padding: 11px 14px !important;
            gap: 13px !important;
            color: #697484 !important;
            font-size: 13.5px !important;
            font-weight: 500 !important;
            border-radius: 9px !important;
            margin-bottom: 0 !important;
            min-height: 42px !important;
            text-decoration: none !important;
            box-sizing: border-box !important;
            background: transparent !important;
            border: none !important;
            cursor: pointer !important;
            transition: background 0.18s ease, color 0.18s ease !important;
            font-family: inherit !important;
            outline: none !important;
        }

        a.nav-item svg, button.nav-item svg, .nav-item svg {
            flex-shrink: 0 !important;
            width: 20px !important;
            height: 20px !important;
            color: #7b8595 !important;
            transition: color 0.18s ease !important;
            display: block !important;
        }

        a.nav-item span, button.nav-item span, .nav-item span {
            color: inherit !important;
            font-size: 13.5px !important;
            font-weight: inherit !important;
            text-decoration: none !important;
            line-height: 1.2 !important;
            white-space: nowrap !important;
        }

        /* Active State */
        a.nav-item.active, button.nav-item.active, .nav-item.active {
            color: #f26500 !important;
            background: #fff1e7 !important;
            font-weight: 650 !important;
        }

        a.nav-item.active svg, button.nav-item.active svg, .nav-item.active svg {
            color: #f26500 !important;
        }

        a.nav-item.active span, button.nav-item.active span, .nav-item.active span {
            color: #f26500 !important;
            font-weight: 650 !important;
        }

        /* Hover State */
        a.nav-item:hover, button.nav-item:hover, .nav-item:hover {
            background: #fff5ed !important;
            color: #f26500 !important;
        }

        a.nav-item:hover svg, button.nav-item:hover svg, .nav-item:hover svg {
            color: #f26500 !important;
        }

        a.nav-item:hover span, button.nav-item:hover span, .nav-item:hover span {
            color: #f26500 !important;
        }

        .sidebar-bottom {
            margin-top: auto !important;
            padding-top: 14px !important;
            border-top: 1px solid #edf0f4 !important;
        }

        .sidebar-profile {
            display: flex !important;
            align-items: center !important;
            padding: 8px 6px !important;
            gap: 10px !important;
            border: none !important;
            border-radius: 9px !important;
            transition: background 0.15s ease !important;
        }
        .sidebar-profile:hover {
            background: #f8fafc !important;
        }

        .signout-nav {
            color: #8f98a6 !important;
        }
        .signout-nav:hover {
            color: #d9534f !important;
            background: #fff0f0 !important;
        }
        .signout-nav:hover svg {
            color: #d9534f !important;
        }

        /* Language Switcher Styling */
        .lang-switcher {
            display: inline-flex !important;
            align-items: center !important;
            background: #f1f5f9 !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 9999px !important;
            padding: 2.5px !important;
            gap: 2px !important;
            box-shadow: inset 0 1px 2px rgba(15, 23, 42, 0.04) !important;
        }

        .lang-btn {
            display: inline-flex !important;
            align-items: center !important;
            gap: 4px !important;
            padding: 4px 10px !important;
            border-radius: 9999px !important;
            font-size: 11px !important;
            font-weight: 650 !important;
            color: #64748b !important;
            border: none !important;
            background: transparent !important;
            cursor: pointer !important;
            transition: all 0.18s ease-in-out !important;
            line-height: 1 !important;
            outline: none !important;
            user-select: none !important;
        }

        .lang-btn .lang-flag {
            font-size: 13px !important;
            line-height: 1 !important;
        }

        .lang-btn:hover {
            color: #1e293b !important;
        }

        .lang-btn.active {
            background: #ffffff !important;
            color: #ea580c !important;
            font-weight: 750 !important;
            box-shadow: 0 1px 4px rgba(15, 23, 42, 0.12) !important;
        }
    </style>
</head>
<body>
    <div class="app-shell">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-mark"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'tool','size' => 23]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'tool','size' => 23]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
                    <span>OmniFix<span class="logo-care"> Care</span><small>AUTHORIZED SERVICE CENTER</small></span>
                </div>
            </div>

            <div class="nav-label"><?php echo e($role === 'customer' ? 'CUSTOMER PORTAL' : 'WORKSPACE'); ?></div>
            <nav class="sidebar-nav">
                <?php
                    $navItems = match($role) {
                        'manager' => [
                            ['Operations overview', 'grid'],
                            ['Technician dispatch', 'tool'],
                            ['Stock oversight', 'box'],
                        ],
                        'corporate' => [
                            ['Fleet overview', 'grid'],
                            ['Active repairs', 'tool'],
                            ['Loaner units', 'laptop'],
                            ['SLA reports', 'clock'],
                        ],
                        'customer' => [
                            ['Warranty & repair', 'shield'],
                            ['Track my repair', 'clock'],
                        ],
                        default => [
                            ['My workbench', 'grid'],
                            ['RMA queue', 'laptop'],
                            ['Parts inventory', 'box'],
                            ['SLA monitor', 'clock'],
                        ],
                    };
                ?>

                <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$navName, $navIcon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('home', ['role' => $role, 'page' => $navName])); ?>"
                       class="nav-item <?php echo e($page === $navName && empty($selectedJob) ? 'active' : ''); ?>">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $navIcon,'size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navIcon),'size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <span><?php echo e($navName); ?></span>
                        <?php if($navName === 'RMA queue'): ?>
                            <em>24</em>
                        <?php elseif($navName === 'SLA monitor'): ?>
                            <i title="Requires attention"></i>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($role === 'manager'): ?>
                    <a href="<?php echo e(route('home', ['role' => $role, 'page' => 'Staff & permissions'])); ?>"
                       class="nav-item <?php echo e($page === 'Staff & permissions' ? 'active' : ''); ?>">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shield','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <span>Staff & permissions</span>
                    </a>
                <?php endif; ?>

                <a href="<?php echo e(route('home', ['role' => $role, 'page' => 'Settings'])); ?>"
                   class="nav-item <?php echo e($page === 'Settings' ? 'active' : ''); ?>">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'settings','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'settings','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <span>Profile & security</span>
                </a>

                <a href="<?php echo e(route('logout')); ?>" class="nav-item signout-nav" title="Sign out">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','size' => 18]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','size' => 18]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <span>Sign out</span>
                </a>
            </nav>

            <div class="sidebar-bottom">
                <a href="<?php echo e(route('home', ['role' => $role, 'page' => 'Settings'])); ?>" class="sidebar-profile" style="text-decoration: none; color: inherit;">
                    <?php if(!empty($currentUser['avatar_url']) || (isset($currentUser['avatar']) && (str_starts_with($currentUser['avatar'], 'http') || str_starts_with($currentUser['avatar'], '/')))): ?>
                        <img src="<?php echo e($currentUser['avatar_url'] ?? $currentUser['avatar']); ?>" alt="Avatar" class="avatar profile-avatar" style="width: 34px; height: 34px; object-fit: cover; border-radius: 50%;">
                    <?php else: ?>
                        <span class="avatar profile-avatar"><?php echo e($currentUser['avatar'] ?? 'OM'); ?></span>
                    <?php endif; ?>
                    <div style="flex: 1; min-width: 0;">
                        <strong style="display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo e($currentUser['name'] ?? 'Alex Morgan'); ?></strong>
                        <small style="display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo e($currentUser['title'] ?? 'Senior technician'); ?></small>
                    </div>
                    <span style="color: #94a3b8; display: inline-flex;"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                </a>
            </div>
        </aside>

        <!-- Main Shell -->
        <div class="main-shell">
            <header class="topbar">
                <div class="breadcrumbs">
                    <?php echo e($role === 'customer' ? 'Customer portal' : 'Workspace'); ?>

                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <strong><?php echo e(!empty($selectedJob) ? 'Bench inspection' : $page); ?></strong>
                </div>

                <div class="header-actions">
                    <!-- Language Switcher: Thai & English -->
                    <div class="lang-switcher" id="langSwitcher" role="group" aria-label="Language Selector">
                        <button type="button" class="lang-btn" id="langBtnTH" onclick="setLanguage('th')" title="เปลี่ยนเป็นภาษาไทย (TH)">
                            <span class="lang-flag">🇹🇭</span>
                            <span>TH</span>
                        </button>
                        <button type="button" class="lang-btn" id="langBtnEN" onclick="setLanguage('en')" title="Switch to English (EN)">
                            <span class="lang-flag">🇬🇧</span>
                            <span>EN</span>
                        </button>
                    </div>

                    <span class="header-divider"></span>
                    <span class="today"><?php echo e(now()->format('l, F j, Y')); ?></span>
                    <span class="header-divider"></span>
                    <button type="button" id="benchStatusToggle" class="bench-toggle" onclick="toggleBenchStatus()">
                        <i></i>
                        <span id="benchStatusText">On bench</span>
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'down','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'down','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </button>
                    <button type="button" class="notification" aria-label="Notifications" onclick="showToast(currentLang === 'th' ? 'มี 3 งานใกล้ครบกำหนด SLA กรุณาตรวจสอบคิว' : '3 tickets are approaching SLA. Review the priority queue.')">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'bell']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bell']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <i></i>
                    </button>
                    <a href="<?php echo e(route('home', ['role' => $role, 'page' => 'Settings'])); ?>" class="topbar-avatar-btn" title="View Profile & Settings" style="display: inline-flex; align-items: center; text-decoration: none; border-radius: 50%; outline: none; cursor: pointer;">
                        <?php if(!empty($currentUser['avatar_url']) || (isset($currentUser['avatar']) && (str_starts_with($currentUser['avatar'], 'http') || str_starts_with($currentUser['avatar'], '/')))): ?>
                            <img src="<?php echo e($currentUser['avatar_url'] ?? $currentUser['avatar']); ?>" alt="Profile Avatar" class="avatar small-avatar" id="topbarAvatarImg" style="width: 32px; height: 32px; object-fit: cover; border-radius: 50%;">
                        <?php else: ?>
                            <span class="avatar small-avatar" id="topbarAvatarSpan"><?php echo e($currentUser['avatar'] ?? 'OM'); ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </header>

            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>

        <!-- Global Toast Notification -->
        <div id="toastContainer" class="toast" role="status" style="display: none;">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check','size' => 19]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','size' => 19]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <span id="toastMessage"></span>
            <button type="button" aria-label="Dismiss notification" onclick="hideToast()">×</button>
        </div>
    </div>

    <script>
        function showToast(message) {
            const container = document.getElementById('toastContainer');
            const msgSpan = document.getElementById('toastMessage');
            if (!container || !msgSpan) return;
            msgSpan.innerText = message;
            container.style.display = 'flex';
            container.classList.add('toast-visible');

            if (window.toastTimer) clearTimeout(window.toastTimer);
            window.toastTimer = setTimeout(() => {
                hideToast();
            }, 4500);
        }

        function hideToast() {
            const container = document.getElementById('toastContainer');
            if (container) {
                container.style.display = 'none';
                container.classList.remove('toast-visible');
            }
        }

        function switchRole(role) {
            const defaultPages = {
                'manager': 'Operations overview',
                'corporate': 'Fleet overview',
                'customer': 'Warranty & repair',
                'technician': 'My workbench'
            };
            const page = defaultPages[role] || 'My workbench';
            window.location.href = `<?php echo e(route('home')); ?>?role=${role}&page=${encodeURIComponent(page)}`;
        }

        function toggleBenchStatus() {
            const btn = document.getElementById('benchStatusToggle');
            const txt = document.getElementById('benchStatusText');
            if (btn.classList.contains('off')) {
                btn.classList.remove('off');
                txt.innerText = 'On bench';
                showToast('Status updated: Technician is On Bench');
            } else {
                btn.classList.add('off');
                txt.innerText = 'Away';
                showToast('Status updated: Technician is Away');
            }
        }

        // Language Translation System (Thai & English)
        const I18N_DICT = {
            th: {
                'Workspace': 'พื้นที่ปฏิบัติงาน',
                'Customer portal': 'พอร์ทัลลูกค้า',
                'CUSTOMER PORTAL': 'พอร์ทัลลูกค้า',
                'WORKSPACE': 'พื้นที่ปฏิบัติงาน',
                'Bench inspection': 'ตรวจสภาพที่โต๊ะช่าง',
                'Operations overview': 'ภาพรวมศูนย์บริการ',
                'Technician dispatch': 'จ่ายงานช่างเทคนิค',
                'Stock oversight': 'ตรวจสต็อกอะไหล่',
                'Fleet overview': 'ภาพรวมอุปกรณ์องค์กร',
                'Active repairs': 'รายการซ่อมที่กำลังดำเนินอยู่',
                'Loaner units': 'เครื่องสำรองระหว่างซ่อม',
                'SLA reports': 'รายงาน SLA',
                'Warranty & repair': 'ตรวจประกันและส่งซ่อม',
                'Track my repair': 'ติดตามสถานะงานซ่อม',
                'My workbench': 'โต๊ะซ่อมของฉัน',
                'RMA queue': 'คิวงานซ่อม RMA',
                'Parts inventory': 'คลังอะไหล่และสต็อก',
                'Loaner devices': 'เครื่องสำรองระหว่างซ่อม',
                'SLA monitor': 'ระบบตรวจวัด SLA',
                'Staff & permissions': 'ทีมงานและสิทธิ์',
                'Profile & security': 'โปรไฟล์และความปลอดภัย',
                'Sign out': 'ออกจากระบบ',
                'Switch demo role': 'สลับบทบาท Demo',
                'Visit help center': 'ติดต่อศูนย์ช่วยเหลือ',
                'On bench': 'กำลังประจำโต๊ะ',
                'Away': 'ไม่อยู่ที่โต๊ะ',
                'Search part number or component': 'ค้นหาหมายเลขอะไหล่หรืออุปกรณ์',
                'Search serial, ticket, device…': 'ค้นหาซีเรียล, เลขงานซ่อม, อุปกรณ์…',
                'All brands': 'ทุกยี่ห้อ',
                'All SLA statuses': 'ทุกสถานะ SLA',
                'All technicians': 'ช่างทุกคน',
                'All jobs': 'งานทั้งหมด',
                'My queue': 'งานของฉัน',
                'Awaiting parts': 'รออะไหล่',
                'In repair': 'กำลังซ่อม',
                'Quality check': 'รอตรวจ QC',
                'Completed': 'ซ่อมเสร็จแล้ว',
                'All parts': 'อะไหล่ทั้งหมด',
                'Critical stock': 'สต็อกวิกฤต',
                'On order': 'สั่งซื้อแล้ว',
                'Repair volume': 'ปริมาณเครื่องรับซ่อม',
                'First-time fix': 'อัตราซ่อมผ่านครั้งแรก',
                'Parts wait time': 'เวลารออะไหล่เฉลี่ย',
                'Customer CSAT': 'ความพึงพอใจลูกค้า',
                'Turnaround': 'ระยะเวลาซ่อมเสร็จ',
                'Total active units': 'อุปกรณ์ในระบบทั้งหมด',
                'Gold SLA protected': 'คุ้มครองระดับ Gold SLA',
                'Standby loaners': 'เครื่องสำรองพร้อมใช้',
                'Annual fleet health': 'ความพร้อมอุปกรณ์ประจำปี',
                'Request part': 'ขอเบิกอะไหล่',
                'Mark repaired & transfer to QC': 'ซ่อมเสร็จ & ส่งตรวจ QC',
                'Approve quotation': 'อนุมัติใบเสนอราคา',
                'Decline / Speak to tech': 'ติดต่อปรึกษาช่าง',
                'Order parts': 'สั่งซื้ออะไหล่',
                'Receive stock': 'รับเข้าสต็อก',
                'Reserve part': 'จองอะไหล่',
                'Batch order replenishment': 'สั่งซื้อเติมสต็อกทั้งหมด',
                'Tell us what’s wrong.': 'แจ้งรายละเอียดอาการเสีย',
                'We’re here to help.': 'เราพร้อมดูแลอุปกรณ์ของคุณ',
                'Full name': 'ชื่อ-นามสกุล',
                'Email for repair updates': 'อีเมลรับการแจ้งเตือน',
                'Phone number': 'เบอร์โทรศัพท์',
                'Select the symptoms': 'เลือกอาการที่พบ',
                'A little more detail': 'รายละเอียดเพิ่มเติม',
                'Drop-off at service center': 'นำส่งที่ศูนย์บริการด้วยตนเอง',
                'Secure courier pickup': 'เรียกบริการรับเครื่องด่วน',
                'Start with your serial number.': 'เริ่มต้นด้วยหมายเลขซีเรียลของคุณ',
                'Check warranty': 'ตรวจสอบประกัน',
                'Diagnostic & Condition Photos': 'ภาพถ่ายตรวจสภาพและหลักฐานการซ่อม',
                'Total estimate': 'ยอดประเมินค่าซ่อม',
                'Profile information': 'ข้อมูลโปรไฟล์',
                'Security & 2FA': 'ความปลอดภัย & 2FA',
                'Active sessions & audit log': 'เซสชันที่ใช้งาน & บันทึกประวัติ',
                'Save changes': 'บันทึกการเปลี่ยนแปลง',
                'Update password': 'เปลี่ยนรหัสผ่าน',
                'Send test email': 'ส่งอีเมลทดสอบ'
            },
            en: {
                'พื้นที่ปฏิบัติงาน': 'Workspace',
                'พอร์ทัลลูกค้า': 'Customer portal',
                'ตรวจสภาพที่โต๊ะช่าง': 'Bench inspection',
                'ภาพรวมศูนย์บริการ': 'Operations overview',
                'จ่ายงานช่างเทคนิค': 'Technician dispatch',
                'ตรวจสต็อกอะไหล่': 'Stock oversight',
                'ภาพรวมอุปกรณ์องค์กร': 'Fleet overview',
                'รายการซ่อมที่กำลังดำเนินอยู่': 'Active repairs',
                'เครื่องสำรองระหว่างซ่อม': 'Loaner units',
                'รายงาน SLA': 'SLA reports',
                'ตรวจประกันและส่งซ่อม': 'Warranty & repair',
                'ติดตามสถานะงานซ่อม': 'Track my repair',
                'โต๊ะซ่อมของฉัน': 'My workbench',
                'คิวงานซ่อม RMA': 'RMA queue',
                'คลังอะไหล่และสต็อก': 'Parts inventory',
                'ระบบตรวจวัด SLA': 'SLA monitor',
                'ทีมงานและสิทธิ์': 'Staff & permissions',
                'โปรไฟล์และความปลอดภัย': 'Profile & security',
                'ออกจากระบบ': 'Sign out',
                'สลับบทบาท Demo': 'Switch demo role',
                'ติดต่อศูนย์ช่วยเหลือ': 'Visit help center',
                'กำลังประจำโต๊ะ': 'On bench',
                'ไม่อยู่ที่โต๊ะ': 'Away',
                'งานทั้งหมด': 'All jobs',
                'งานของฉัน': 'My queue',
                'รออะไหล่': 'Awaiting parts',
                'กำลังซ่อม': 'In repair',
                'รอตรวจ QC': 'Quality check',
                'ซ่อมเสร็จแล้ว': 'Completed',
                'ปริมาณเครื่องรับซ่อม': 'Repair volume',
                'อัตราซ่อมผ่านครั้งแรก': 'First-time fix',
                'เวลารออะไหล่เฉลี่ย': 'Parts wait time',
                'ความพึงพอใจลูกค้า': 'Customer CSAT',
                'ระยะเวลาซ่อมเสร็จ': 'Turnaround',
                'อุปกรณ์ในระบบทั้งหมด': 'Total active units',
                'คุ้มครองระดับ Gold SLA': 'Gold SLA protected',
                'เครื่องสำรองพร้อมใช้': 'Standby loaners',
                'ความพร้อมอุปกรณ์ประจำปี': 'Annual fleet health',
                'ขอเบิกอะไหล่': 'Request part',
                'ซ่อมเสร็จ & ส่งตรวจ QC': 'Mark repaired & transfer to QC',
                'อนุมัติใบเสนอราคา': 'Approve quotation',
                'ติดต่อปรึกษาช่าง': 'Decline / Speak to tech',
                'แจ้งรายละเอียดอาการเสีย': 'Tell us what’s wrong.',
                'เราพร้อมดูแลอุปกรณ์ของคุณ': 'We’re here to help.',
                'ชื่อ-นามสกุล': 'Full name',
                'อีเมลรับการแจ้งเตือน': 'Email for repair updates',
                'เบอร์โทรศัพท์': 'Phone number',
                'เลือกอาการที่พบ': 'Select the symptoms',
                'รายละเอียดเพิ่มเติม': 'A little more detail',
                'นำส่งที่ศูนย์บริการด้วยตนเอง': 'Drop-off at service center',
                'เรียกบริการรับเครื่องด่วน': 'Secure courier pickup',
                'เริ่มต้นด้วยหมายเลขซีเรียลของคุณ': 'Start with your serial number.',
                'ตรวจสอบประกัน': 'Check warranty',
                'ภาพถ่ายตรวจสภาพและหลักฐานการซ่อม': 'Diagnostic & Condition Photos',
                'ยอดประเมินค่าซ่อม': 'Total estimate',
                'ข้อมูลโปรไฟล์': 'Profile information',
                'ความปลอดภัย & 2FA': 'Security & 2FA',
                'เซสชันที่ใช้งาน & บันทึกประวัติ': 'Active sessions & audit log'
            }
        };

        let currentLang = localStorage.getItem('omni_app_lang') || 'th';

        function setLanguage(lang, silent = false) {
            currentLang = lang;
            localStorage.setItem('omni_app_lang', lang);
            document.cookie = `omni_lang=${lang};path=/;max-age=31536000`;

            const btnTH = document.getElementById('langBtnTH');
            const btnEN = document.getElementById('langBtnEN');
            if (btnTH && btnEN) {
                if (lang === 'th') {
                    btnTH.classList.add('active');
                    btnEN.classList.remove('active');
                } else {
                    btnEN.classList.add('active');
                    btnTH.classList.remove('active');
                }
            }

            const dict = I18N_DICT[lang] || {};

            function translateNode(node) {
                if (node.nodeType === Node.TEXT_NODE) {
                    const text = node.nodeValue.trim();
                    if (text && dict[text]) {
                        node.nodeValue = node.nodeValue.replace(text, dict[text]);
                    }
                } else if (node.nodeType === Node.ELEMENT_NODE && !['SCRIPT', 'STYLE'].includes(node.tagName)) {
                    if (node.placeholder && dict[node.placeholder]) {
                        node.placeholder = dict[node.placeholder];
                    }
                    node.childNodes.forEach(child => translateNode(child));
                }
            }

            translateNode(document.body);

            if (!silent) {
                showToast(lang === 'th' ? 'สลับภาษาเป็น: ภาษาไทย (TH) เรียบร้อย' : 'Switched language to: English (EN)');
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            setLanguage(currentLang, true);
        });

        <?php if(session('success')): ?>
            document.addEventListener('DOMContentLoaded', () => {
                showToast(<?php echo json_encode(session('success'), 15, 512) ?>);
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            document.addEventListener('DOMContentLoaded', () => {
                showToast(<?php echo json_encode(session('error'), 15, 512) ?>);
            });
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\User\Downloads\laravel-main\laravel-main\omnifix-care\omnifix-care\resources\views/layouts/app.blade.php ENDPATH**/ ?>