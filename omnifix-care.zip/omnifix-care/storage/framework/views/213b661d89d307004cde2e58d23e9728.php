<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($subjectTitle); ?></title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; line-height: 1.6;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #f8fafc; padding: 40px 15px;">
        <tr>
            <td align="center">
                <table role="presentation" width="100%" max-width="600" cellspacing="0" cellpadding="0" border="0" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
                    
                    <!-- Header -->
                    <tr>
                        <td style="padding: 30px 36px 20px; background: #ffffff; border-bottom: 1px solid #f1f5f9;">
                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tr>
                                    <td>
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0">
                                            <tr>
                                                <td style="background-color: #ff6b00; width: 36px; height: 36px; border-radius: 9px; text-align: center; vertical-align: middle; color: #ffffff; font-weight: bold; font-size: 18px;">
                                                    ⚙
                                                </td>
                                                <td style="padding-left: 12px;">
                                                    <span style="font-size: 20px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px;">OmniFix <span style="color: #ff6b00; font-weight: 600;">Care</span></span>
                                                    <span style="display: block; font-size: 8.5px; text-transform: uppercase; letter-spacing: 1.5px; color: #94a3b8; font-weight: 700; margin-top: 2px;">Authorized Service Center</span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td align="right">
                                        <span style="display: inline-block; padding: 5px 12px; border-radius: 9999px; font-size: 11px; font-weight: 700; background-color: <?php echo e($badgeColor ?? '#ffedd5'); ?>; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px;">
                                            <?php echo e($badge); ?>

                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- Body Content -->
                    <tr>
                        <td style="padding: 32px 36px;">
                            <h1 style="font-size: 21px; font-weight: 750; color: #0f172a; margin: 0 0 12px; letter-spacing: -0.5px; line-height: 1.3;">
                                <?php echo e($title); ?>

                            </h1>
                            <p style="font-size: 14px; color: #475569; margin: 0 0 24px; line-height: 1.6;">
                                เรียนคุณ <strong><?php echo e($recipientName); ?></strong>,<br>
                                <?php echo e($introText); ?>

                            </p>

                            <?php if(!empty($details)): ?>
                                <!-- Details Box -->
                                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #fafbfc; border: 1px solid #e9edf2; border-radius: 10px; margin-bottom: 28px; overflow: hidden;">
                                    <tr>
                                        <td style="padding: 16px 20px; border-bottom: 1px solid #eef2f6; background-color: #f1f5f9;">
                                            <strong style="font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: #475569;">รายละเอียดรายการ (Ticket Details)</strong>
                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="padding: 11px 20px; border-bottom: 1px solid #f1f5f9;">
                                                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                    <tr>
                                                        <td width="38%" style="font-size: 12.5px; color: #64748b; font-weight: 550;">
                                                            <?php echo e($label); ?>

                                                        </td>
                                                        <td width="62%" style="font-size: 13px; color: #0f172a; font-weight: 600; text-align: right;">
                                                            <?php echo e($value); ?>

                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            <?php endif; ?>

                            <?php if($actionUrl): ?>
                                <!-- Call to Action Button -->
                                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin: 28px 0 16px;">
                                    <tr>
                                        <td align="center">
                                            <a href="<?php echo e($actionUrl); ?>" target="_blank" style="display: inline-block; background-color: #ff6b00; color: #ffffff; text-decoration: none; font-size: 13.5px; font-weight: 700; padding: 13px 28px; border-radius: 8px; box-shadow: 0 4px 10px rgba(255, 107, 0, 0.25);">
                                                <?php echo e($actionText ?? 'เข้าสู่ระบบ OmniFix Care →'); ?>

                                            </a>
                                        </td>
                                    </tr>
                                </table>
                            <?php endif; ?>

                            <p style="font-size: 12px; color: #94a3b8; margin: 28px 0 0; text-align: center; line-height: 1.5;">
                                หากคุณมีข้อสงสัยหรือต้องการความช่วยเหลือเพิ่มเติม สามารถติดต่อศูนย์บริการ OmniFix Care ได้ตลอด 24 ชั่วโมง
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8fafc; padding: 22px 36px; border-top: 1px solid #eef2f6; text-align: center;">
                            <p style="font-size: 11px; color: #94a3b8; margin: 0 0 6px;">
                                © <?php echo e(date('Y')); ?> OmniFix Care · Authorized Service Center Bangkok Central.
                            </p>
                            <p style="font-size: 10px; color: #cbd5e1; margin: 0;">
                                อีเมลฉบับนี้ส่งโดยอัตโนมัติจากระบบ OmniFix Care Notification Service (<?php echo e(now()->timezone('Asia/Bangkok')->format('d/m/Y H:i:s')); ?>)
                            </p>
                        </td>
                    </tr>

                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH C:\Users\User\Downloads\laravel-main\laravel-main\omnifix-care\omnifix-care\resources\views/emails/notification.blade.php ENDPATH**/ ?>