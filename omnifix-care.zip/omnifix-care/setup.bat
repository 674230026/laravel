@echo off
title OmniFix Care - First Time Setup
color 0B

echo.
echo  =============================================
echo   OmniFix Care - First Time Setup
echo  =============================================
echo.

cd /d "%~dp0"
if exist "%USERPROFILE%\.config\herd-lite\bin\php.exe" (
    set "PATH=%USERPROFILE%\.config\herd-lite\bin;%PATH%"
)

echo [1/3] Installing Composer dependencies...
composer install --no-interaction
if %errorlevel% neq 0 (
    echo  ERROR: Composer install failed. Make sure Composer is installed.
    pause
    exit /b 1
)

echo.
echo [2/5] Setting up .env file...
if not exist ".env" (
    copy .env.example .env
)

echo.
echo [3/5] Generating application key...
php artisan key:generate

echo.
echo [4/5] Running database migrations and seeding...
php artisan migrate:fresh --seed --force

echo.
echo [5/5] Setup complete!
echo.
echo  =============================================
echo   Run start-server.bat to launch the app
echo  =============================================
echo.
pause
