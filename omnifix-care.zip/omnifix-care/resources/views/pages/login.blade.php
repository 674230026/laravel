<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Sign in — OmniFix Care Authorized Service Portal</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;450;500;550;600;650;700;750;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/advanced.css') }}">
    <link rel="stylesheet" href="{{ asset('css/account.css') }}">
    <link rel="stylesheet" href="{{ asset('css/index.css') }}">
    <style>
        .demo-roles-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin: 20px 0 26px;
        }
        .demo-role-card {
            border: 1px solid #e2e7ef;
            border-radius: 10px;
            padding: 14px 14px 12px;
            background: #ffffff;
            display: flex;
            flex-direction: column;
            text-align: left;
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
        }
        .demo-role-card:hover {
            border-color: #ff882f;
            box-shadow: 0 4px 14px rgba(255, 107, 0, 0.12);
            transform: translateY(-2px);
            background: #fffdfb;
        }
        .demo-role-card-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .demo-role-icon {
            width: 30px;
            height: 30px;
            border-radius: 7px;
            background: #fff2e7;
            color: #f26500;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .demo-role-badge {
            font-size: 8px;
            font-weight: 700;
            letter-spacing: 0.4px;
            text-transform: uppercase;
            padding: 3px 6px;
            border-radius: 4px;
            background: #f1f4f9;
            color: #637287;
        }
        .demo-role-name {
            font-size: 13px;
            font-weight: 750;
            color: #1a2536;
            margin-bottom: 2px;
        }
        .demo-role-user {
            font-size: 10.5px;
            color: #8c97a8;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .demo-role-user strong {
            color: #4b586d;
            font-weight: 600;
        }
        .demo-role-desc {
            font-size: 9.5px;
            color: #7b889b;
            line-height: 1.5;
            margin-bottom: 12px;
            flex: 1;
        }
        .demo-role-btn {
            width: 100%;
            padding: 8px 10px;
            background: #f8fafc;
            border: 1px solid #e1e7f0;
            border-radius: 6px;
            color: #f26500;
            font-size: 10.5px;
            font-weight: 650;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: all 0.15s ease;
            cursor: pointer;
        }
        .demo-role-card:hover .demo-role-btn {
            background: #ff6b00;
            border-color: #ff6b00;
            color: #ffffff;
        }
        .auth-tabs {
            display: flex;
            border-bottom: 1px solid #e9edf2;
            margin-bottom: 22px;
            gap: 20px;
        }
        .auth-tab-btn {
            background: none;
            border: none;
            padding: 0 0 11px;
            font-size: 12px;
            font-weight: 600;
            color: #8994a4;
            border-bottom: 2px solid transparent;
            margin-bottom: -1px;
            cursor: pointer;
        }
        .auth-tab-btn.active {
            color: #f26500;
            border-bottom-color: #ff6b00;
        }
        .section-header-eyebrow {
            font-size: 9px;
            font-weight: 750;
            letter-spacing: 1.4px;
            color: #e8823b;
            text-transform: uppercase;
            margin-bottom: 4px;
            display: block;
        }
        @media(max-width: 900px) {
            .demo-roles-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="auth-page">
        <!-- Brand Illustration Column -->
        <section class="auth-brand">
            <div class="auth-logo">
                <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                        <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                        <path d="m8 12 3 3 5-6"/>
                    </svg>
                </span>
                OmniFix <b>Care</b>
            </div>

            <div class="auth-story">
                <span class="auth-eyebrow">EXPERT HANDS. CONNECTED CARE.</span>
                <h1>One portal.<br>Every device.<br><em>Complete care.</em></h1>
                <p>Precision care for every machine.<br>Enterprise & consumer warranty portal.</p>

                <svg class="laptop-art" viewBox="0 0 500 240" fill="none" aria-hidden="true">
                    <g stroke="currentColor" stroke-width="1.3">
                        <path d="m90 150 10-105 272-13 23 117-305 1Z"/>
                        <path d="m90 150-47 48 382 2-30-51M43 198v10l382 2v-10"/>
                        <rect x="118" y="60" width="232" height="72" rx="5"/>
                        <rect x="193" y="78" width="50" height="38" rx="3"/>
                        <path d="M193 88h-30V70m30 28h-40v22m90-32h47V67m-47 39h66v18M208 78V60m21 18V60M207 116v16m24-16v16"/>
                        <circle cx="163" cy="70" r="3"/>
                        <circle cx="153" cy="120" r="3"/>
                        <circle cx="290" cy="67" r="3"/>
                        <circle cx="309" cy="124" r="3"/>
                        <path d="m118 162-13 16h261l-8-16H118Zm65 23h87"/>
                    </g>
                    <circle cx="410" cy="58" r="26" fill="#ffffff18" stroke="currentColor"/>
                    <path d="m398 58 8 8 15-18" stroke="currentColor" stroke-width="2"/>
                </svg>

                <div class="auth-benefits">
                    <span><i>✓</i>Instant warranty claims</span>
                    <span><i>✓</i>Live repair visibility</span>
                    <span><i>✓</i>SLA guard technology</span>
                </div>
            </div>

            <div class="auth-brand-footer">
                <span>Authorized care. Genuine confidence.</span>
                <span>© 2026 OmniFix Care</span>
            </div>
        </section>

        <!-- Right Side Form & Demo Role Login -->
        <section class="auth-form-side">
            <div class="auth-top-note">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                    <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                    <path d="m8 12 3 3 5-6"/>
                </svg>
                Your trust. Our responsibility.
            </div>

            <div class="auth-form-container">
                <span class="auth-access"><i></i>AUTHORIZED PORTAL ACCESS</span>

                <!-- VIEW 1: MAIN LOGIN & DEMO ROLES -->
                <div id="view-login" class="auth-view-panel">
                    <h2>Welcome to OmniFix Care</h2>
                    <p>Select a demo role below to explore the customized workspace, or sign in with your account credentials.</p>

                    <!-- Prominent Demo Role Login Selection -->
                    <span class="section-header-eyebrow">Demo Quick Access — Select Role to Enter</span>
                    <div class="demo-roles-grid">
                        @foreach($demoRoles as $r)
                            <form action="{{ route('login.post') }}" method="POST" class="demo-role-form">
                                @csrf
                                <input type="hidden" name="demo_role" value="{{ $r['key'] }}">
                                <button type="submit" class="demo-role-card" title="Enter as {{ $r['title'] }}">
                                    <div class="demo-role-card-top">
                                        <div class="demo-role-icon">
                                            <x-icon :name="$r['icon']" :size="17" />
                                        </div>
                                        <span class="demo-role-badge">{{ $r['badge'] }}</span>
                                    </div>
                                    <div class="demo-role-name">{{ $r['title'] }}</div>
                                    <div class="demo-role-user">
                                        <span>User:</span> <strong>{{ $r['user'] }}</strong>
                                    </div>
                                    <div class="demo-role-desc">{{ $r['description'] }}</div>
                                    <div class="demo-role-btn">
                                        <span>Enter workspace</span>
                                        <x-icon name="arrow" :size="13" />
                                    </div>
                                </button>
                            </form>
                        @endforeach
                    </div>

                    <div class="auth-divider"><span>OR SIGN IN WITH CREDENTIALS</span></div>

                    <div class="auth-tabs" style="margin-top: 20px;">
                        <button type="button" id="tabBtnSignIn" class="auth-tab-btn active" onclick="switchAuthTab('signin')">Sign in</button>
                        <button type="button" id="tabBtnRegister" class="auth-tab-btn" onclick="switchAuthTab('register')">Create demo account</button>
                    </div>

                    <!-- Sign In / Register Form -->
                    <form id="authMainForm" onsubmit="event.preventDefault(); submitCredentialsForm();">
                        <div id="registerNameGroup" style="display: none;">
                            <label class="account-field">
                                Full name
                                <input type="text" id="regNameInput" placeholder="Alex Morgan" autocomplete="name">
                            </label>
                        </div>

                        <label class="account-field">
                            Work email / username
                            <input type="email" id="emailInput" required value="alex@omnifix.com" placeholder="you@company.com" autocomplete="username">
                        </label>

                        <label class="account-field">
                            Password
                            <div class="password-input">
                                <input type="password" id="passwordInput" required value="OmniFix@2026" placeholder="Enter your password" autocomplete="current-password" onkeyup="checkPasswordRules(this.value)">
                                <button type="button" aria-label="Toggle password visibility" onclick="togglePasswordVisibility('passwordInput', this)">
                                    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                        <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7Z"/>
                                        <circle cx="12" cy="12" r="3"/>
                                    </svg>
                                </button>
                            </div>
                        </label>

                        <div id="passwordRulesBox" class="password-rules" style="margin-top: 10px; display: none;">
                            <span id="rule-len">○ At least 8 characters</span>
                            <span id="rule-upper">○ One uppercase letter</span>
                            <span id="rule-num">○ One number</span>
                            <span id="rule-spec">○ One special character</span>
                        </div>

                        <div class="auth-helper">
                            <label><input type="checkbox" checked> Remember me for 30 days</label>
                            <button type="button" onclick="showView('forgot')">Forgot password?</button>
                        </div>

                        <button type="submit" class="primary auth-submit" id="authSubmitBtn">
                            <span id="authSubmitText">Sign in to console</span>
                            <span>→</span>
                        </button>
                    </form>

                    <div class="auth-roles" style="margin-top: 24px;">
                        <span>Customers</span><i></i><span>Corporate IT</span><i></i><span>Service teams</span>
                    </div>

                    <div class="demo-notice">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                            <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                            <path d="m8 12 3 3 5-6"/>
                        </svg>
                        <span>Interactive demo · Enter any credentials or use one-click role buttons above.</span>
                    </div>
                </div>

                <!-- VIEW 2: 2FA / OTP VERIFICATION -->
                <div id="view-otp" class="auth-view-panel" style="display: none;">
                    <div class="auth-security-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                            <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                            <path d="m8 12 3 3 5-6"/>
                        </svg>
                    </div>
                    <h2>Two-step verification</h2>
                    <p>
                        One extra step to keep your account safe.<br>
                        Enter the code sent to <span id="otpTargetEmail">a***@omnifix.com</span>.
                    </p>

                    <form action="{{ route('login.post') }}" method="POST" id="otpForm">
                        @csrf
                        <input type="hidden" name="email" id="otpHiddenEmail">
                        <input type="hidden" name="digits" id="otpHiddenDigits">
                        <input type="hidden" name="backup_code" id="otpHiddenBackup">

                        <div id="otpBoxSection">
                            <div class="otp-boxes">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" autofocus oninput="onOtpInput(this, 0)" onkeydown="onOtpKeyDown(event, 0)">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" oninput="onOtpInput(this, 1)" onkeydown="onOtpKeyDown(event, 1)">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" oninput="onOtpInput(this, 2)" onkeydown="onOtpKeyDown(event, 2)">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" oninput="onOtpInput(this, 3)" onkeydown="onOtpKeyDown(event, 3)">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" oninput="onOtpInput(this, 4)" onkeydown="onOtpKeyDown(event, 4)">
                                <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" oninput="onOtpInput(this, 5)" onkeydown="onOtpKeyDown(event, 5)">
                            </div>
                        </div>

                        <div id="otpBackupSection" style="display: none;">
                            <label class="account-field">
                                Recovery backup code
                                <input type="text" id="backupCodeInput" placeholder="Enter recovery code (e.g. OMNIFIX-DEMO)">
                            </label>
                        </div>

                        <div class="otp-resend">
                            <span id="countdownText">Resend code in <strong id="timerSecs">45</strong>s</span>
                            <button type="button" id="resendBtn" class="text-button" style="display: none;" onclick="resendOtp()">Resend code</button>
                        </div>

                        <button type="button" class="primary auth-submit" onclick="submitOtpVerification()">
                            Verify & proceed →
                        </button>
                    </form>

                    <button type="button" class="auth-link" onclick="toggleOtpBackup()">
                        <span id="backupToggleText">Use backup recovery code</span>
                    </button>
                    <button type="button" class="auth-link muted" onclick="showView('login')">
                        ← Back to sign in
                    </button>

                    <div class="demo-notice">
                        Demo verification code: <strong>123456</strong>
                    </div>
                </div>

                <!-- VIEW 3: FORGOT PASSWORD -->
                <div id="view-forgot" class="auth-view-panel" style="display: none;">
                    <div class="auth-security-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                            <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                            <path d="m8 12 3 3 5-6"/>
                        </svg>
                    </div>
                    <h2>Forgot your password?</h2>
                    <p>It happens. Enter your registered email and we’ll help you get back on track.</p>

                    <form onsubmit="event.preventDefault(); showView('sent');">
                        <label class="account-field">
                            Email address
                            <input type="email" required placeholder="you@company.com">
                        </label>
                        <button type="submit" class="primary auth-submit">Send reset link →</button>
                    </form>

                    <button type="button" class="auth-link" onclick="showView('login')">← Back to sign in</button>
                </div>

                <!-- VIEW 4: RESET LINK SENT -->
                <div id="view-sent" class="auth-view-panel" style="display: none;">
                    <div class="auth-security-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                            <path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/>
                            <path d="m8 12 3 3 5-6"/>
                        </svg>
                    </div>
                    <h2>Check your inbox.</h2>
                    <p>In a live system, an eligible account receives a secure reset link. This demo does not send real email.</p>

                    <button type="button" class="primary auth-submit" onclick="showView('reset')">Preview password reset →</button>
                    <button type="button" class="auth-link" onclick="showView('login')">← Back to sign in</button>
                </div>

                <!-- VIEW 5: RESET PASSWORD FORM -->
                <div id="view-reset" class="auth-view-panel" style="display: none;">
                    <h2>A fresh start.</h2>
                    <p>Choose a strong password to keep your account protected.</p>

                    <form onsubmit="event.preventDefault(); handlePasswordResetDone();">
                        <label class="account-field">
                            New password
                            <div class="password-input">
                                <input type="password" id="resetNewPass" required placeholder="Enter new password" onkeyup="checkPasswordRules(this.value)">
                            </div>
                        </label>

                        <div class="password-rules" style="margin-top: 10px;">
                            <span id="reset-rule-len">○ At least 8 characters</span>
                            <span id="reset-rule-upper">○ One uppercase letter</span>
                            <span id="reset-rule-num">○ One number</span>
                            <span id="reset-rule-spec">○ One special character</span>
                        </div>

                        <label class="account-field">
                            Confirm new password
                            <div class="password-input">
                                <input type="password" id="resetConfirmPass" required placeholder="Confirm new password">
                            </div>
                        </label>

                        <button type="submit" class="primary auth-submit">Save password & sign in →</button>
                    </form>
                    <button type="button" class="auth-link" onclick="showView('login')">← Back to sign in</button>
                </div>

                <!-- Global In-Form Error Banner -->
                <div id="authErrorMsg" class="auth-error" style="display: none;"></div>
            </div>

            <div class="auth-footer">
                <span>Protected by care. Designed for confidence.</span>
                <button type="button" onclick="showAuthError('For assistance, contact care@omnifix.com or +1 (800) 555-0142.')">Need help? ↗</button>
            </div>
        </section>
    </div>

    <script>
        let currentAuthMode = 'signin';
        let countdown = 45;
        let timerInterval = null;
        let isBackupMode = false;

        function showView(viewName) {
            document.querySelectorAll('.auth-view-panel').forEach(p => p.style.display = 'none');
            const target = document.getElementById('view-' + viewName);
            if (target) target.style.display = 'block';
            hideAuthError();

            if (viewName === 'otp') {
                startOtpTimer();
                const boxes = document.querySelectorAll('.otp-digit');
                if (boxes.length) {
                    boxes[0].focus();
                }
            }
        }

        function switchAuthTab(mode) {
            currentAuthMode = mode;
            hideAuthError();
            const btnIn = document.getElementById('tabBtnSignIn');
            const btnReg = document.getElementById('tabBtnRegister');
            const nameGrp = document.getElementById('registerNameGroup');
            const subTxt = document.getElementById('authSubmitText');
            const rulesBox = document.getElementById('passwordRulesBox');

            if (mode === 'signin') {
                btnIn.classList.add('active');
                btnReg.classList.remove('active');
                nameGrp.style.display = 'none';
                subTxt.innerText = 'Sign in to console';
                rulesBox.style.display = 'none';
            } else {
                btnReg.classList.add('active');
                btnIn.classList.remove('active');
                nameGrp.style.display = 'block';
                subTxt.innerText = 'Create demo account';
                rulesBox.style.display = 'grid';
            }
        }

        function togglePasswordVisibility(inputId, btn) {
            const input = document.getElementById(inputId);
            if (!input) return;
            if (input.type === 'password') {
                input.type = 'text';
                btn.style.color = '#ff6b00';
            } else {
                input.type = 'password';
                btn.style.color = '#97a2b1';
            }
        }

        function checkPasswordRules(pwd) {
            const hasLen = pwd.length >= 8;
            const hasUpper = /[A-Z]/.test(pwd);
            const hasNum = /[0-9]/.test(pwd);
            const hasSpec = /[^A-Za-z0-9]/.test(pwd);

            updateRuleElem('rule-len', hasLen, 'At least 8 characters');
            updateRuleElem('rule-upper', hasUpper, 'One uppercase letter');
            updateRuleElem('rule-num', hasNum, 'One number');
            updateRuleElem('rule-spec', hasSpec, 'One special character');

            updateRuleElem('reset-rule-len', hasLen, 'At least 8 characters');
            updateRuleElem('reset-rule-upper', hasUpper, 'One uppercase letter');
            updateRuleElem('reset-rule-num', hasNum, 'One number');
            updateRuleElem('reset-rule-spec', hasSpec, 'One special character');
        }

        function updateRuleElem(elemId, met, text) {
            const el = document.getElementById(elemId);
            if (!el) return;
            if (met) {
                el.className = 'rule-met';
                el.innerText = '✓ ' + text;
            } else {
                el.className = '';
                el.innerText = '○ ' + text;
            }
        }

        function submitCredentialsForm() {
            const email = document.getElementById('emailInput').value.trim();
            const pwd = document.getElementById('passwordInput').value;

            if (currentAuthMode === 'register') {
                if (pwd.length < 8 || !/[A-Z]/.test(pwd) || !/[0-9]/.test(pwd) || !/[^A-Za-z0-9]/.test(pwd)) {
                    showAuthError('Please choose a password that meets all 4 requirements.');
                    return;
                }
            }

            // Move to OTP view
            document.getElementById('otpHiddenEmail').value = email;
            const parts = email.split('@');
            const masked = (email[0] || 'a') + '***@' + (parts[1] || 'omnifix.com');
            document.getElementById('otpTargetEmail').innerText = masked;
            showView('otp');
        }

        function onOtpInput(input, index) {
            const val = input.value.replace(/\D/g, '').slice(-1);
            input.value = val;
            const digits = document.querySelectorAll('.otp-digit');
            if (val && index < 5) {
                digits[index + 1].focus();
            }
        }

        function onOtpKeyDown(event, index) {
            const digits = document.querySelectorAll('.otp-digit');
            if (event.key === 'Backspace' && !digits[index].value && index > 0) {
                digits[index - 1].focus();
            } else if (event.key === 'ArrowLeft' && index > 0) {
                digits[index - 1].focus();
            } else if (event.key === 'ArrowRight' && index < 5) {
                digits[index + 1].focus();
            }
        }

        // Paste 6-digit code support
        document.addEventListener('paste', (e) => {
            const otpSection = document.getElementById('view-otp');
            if (otpSection && otpSection.style.display !== 'none') {
                const text = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
                if (text.length > 0) {
                    const inputs = document.querySelectorAll('.otp-digit');
                    text.split('').forEach((ch, idx) => {
                        if (inputs[idx]) inputs[idx].value = ch;
                    });
                    const targetIdx = Math.min(text.length, 5);
                    if (inputs[targetIdx]) inputs[targetIdx].focus();
                    e.preventDefault();
                }
            }
        });

        function submitOtpVerification() {
            const inputs = document.querySelectorAll('.otp-digit');
            let code = '';
            inputs.forEach(inp => code += inp.value);

            const backupVal = document.getElementById('backupCodeInput').value.trim();

            if (isBackupMode) {
                if (backupVal === 'OMNIFIX-DEMO') {
                    document.getElementById('otpHiddenBackup').value = 'OMNIFIX-DEMO';
                    document.getElementById('otpForm').submit();
                } else {
                    showAuthError('Invalid recovery code. Use demo backup code OMNIFIX-DEMO.');
                }
            } else {
                if (code === '123456') {
                    document.getElementById('otpHiddenDigits').value = '123456';
                    document.getElementById('otpForm').submit();
                } else {
                    showAuthError('Use the demo verification code 123456, or backup code OMNIFIX-DEMO.');
                }
            }
        }

        function toggleOtpBackup() {
            isBackupMode = !isBackupMode;
            hideAuthError();
            const boxSec = document.getElementById('otpBoxSection');
            const bkSec = document.getElementById('otpBackupSection');
            const txt = document.getElementById('backupToggleText');

            if (isBackupMode) {
                boxSec.style.display = 'none';
                bkSec.style.display = 'block';
                txt.innerText = 'Use 6-digit verification code';
            } else {
                boxSec.style.display = 'block';
                bkSec.style.display = 'none';
                txt.innerText = 'Use backup recovery code';
            }
        }

        function startOtpTimer() {
            countdown = 45;
            document.getElementById('timerSecs').innerText = countdown;
            document.getElementById('countdownText').style.display = 'inline';
            document.getElementById('resendBtn').style.display = 'none';

            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(() => {
                countdown--;
                if (countdown <= 0) {
                    clearInterval(timerInterval);
                    document.getElementById('countdownText').style.display = 'none';
                    document.getElementById('resendBtn').style.display = 'inline';
                } else {
                    document.getElementById('timerSecs').innerText = countdown;
                }
            }, 1000);
        }

        function resendOtp() {
            startOtpTimer();
            showAuthError('Demo verification code: 123456. (No real email is sent)');
        }

        function handlePasswordResetDone() {
            const p1 = document.getElementById('resetNewPass').value;
            const p2 = document.getElementById('resetConfirmPass').value;
            if (p1.length < 8) {
                showAuthError('Password must be at least 8 characters.');
                return;
            }
            if (p1 !== p2) {
                showAuthError('Passwords do not match.');
                return;
            }
            showView('login');
            showAuthError('Demo password reset complete. Please sign in.');
        }

        function showAuthError(msg) {
            const el = document.getElementById('authErrorMsg');
            el.innerText = msg;
            el.style.display = 'block';
        }

        function hideAuthError() {
            const el = document.getElementById('authErrorMsg');
            el.innerText = '';
            el.style.display = 'none';
        }

        @if(session('info'))
            document.addEventListener('DOMContentLoaded', () => {
                showAuthError(@json(session('info')));
            });
        @endif

        @if(session('error'))
            document.addEventListener('DOMContentLoaded', () => {
                showAuthError(@json(session('error')));
            });
        @endif
    </script>
</body>
</html>
