@extends('layouts.app')

@section('content')
@if(!empty($selectedJob))
    {{-- BENCH INSPECTION VIEW --}}
    <a href="{{ route('home', ['role' => $role, 'page' => $page]) }}" class="back-link">
        ← Back to workbench
    </a>

    <div class="page-heading">
        <div>
            <div class="eyebrow">BENCH INSPECTION</div>
            <h1>
                RMA-{{ $selectedJob->id }}
                <span class="badge {{ $selectedJob->tone }}">{{ $selectedJob->status }}</span>
            </h1>
            <p>Everything you need to bring this device back to its best.</p>
        </div>
        <a href="{{ route('home', ['role' => 'customer', 'page' => 'Track my repair', 'ticket' => $selectedJob->id]) }}" class="primary">
            Generate quotation <x-icon name="arrow" :size="17" />
        </a>
    </div>

    <div class="inspection-layout">
        <!-- Device details panel -->
        <section class="panel device-panel">
            <h3>Device & customer details</h3>
            <div class="device-illustration">
                <x-icon name="laptop" :size="88" />
            </div>
            <h2>{{ $selectedJob->model }}</h2>
            <p>{{ $selectedJob->gen ?? 'Intel Core i7-1365U' }}</p>

            <dl>
                <dt>Serial number</dt>
                <dd>{{ $selectedJob->serial }}</dd>
                <dt>Processor</dt>
                <dd>{{ $selectedJob->processor ?? 'Intel Core i7-1365U' }}</dd>
                <dt>Memory</dt>
                <dd>{{ $selectedJob->memory ?? '16 GB LPDDR5' }}</dd>
                <dt>Customer</dt>
                <dd>{{ $selectedJob->customer_name }}</dd>
                <dt>Warranty</dt>
                <dd class="green-text">{{ $selectedJob->warranty_status }}</dd>
            </dl>

            <div class="customer-note">
                <strong>Customer reported</strong>
                <p>“{{ $selectedJob->issue }}. The issue started last week, especially when using multiple applications.”</p>
            </div>
        </section>

        <!-- Inspection Main Checklist & Actions -->
        <section class="panel inspection-main">
            <h3>Intake condition checklist</h3>
            <form action="{{ route('jobs.qc', $selectedJob->id) }}" method="POST">
                @csrf
                <div class="checklist">
                    @foreach(['Power-on test completed', 'Screen and dead pixel check', 'Chassis condition documented'] as $checkItem)
                        <label>
                            <input type="checkbox" name="checklist[]" value="{{ $checkItem }}"
                                {{ is_array($selectedJob->checklist) && in_array($checkItem, $selectedJob->checklist) ? 'checked' : '' }}>
                            {{ $checkItem }}
                        </label>
                    @endforeach
                </div>

                <div class="section-line">
                    <h3>Photo evidence</h3>
                    <span>Document the difference.</span>
                </div>

                <div class="evidence-grid">
                    @foreach(['Pre-repair · Front', 'Pre-repair · Internal', 'Post-repair · Display', 'Post-repair · Thermal QC'] as $label)
                        <label class="evidence">
                            <x-icon name="upload" :size="25" />
                            <strong>{{ $label }}</strong>
                            <span>Upload condition photo</span>
                            <input type="file" accept="image/*" onchange="if(this.files[0]) showToast(this.files[0].name + ' attached to {{ $label }}.')">
                        </label>
                    @endforeach
                </div>

                <h3>Spare parts allocation</h3>
                <div class="parts-entry">
                    <input type="text" id="partSearchInput" placeholder="Search part number or component">
                    <button type="button" class="secondary" onclick="showToast('Cooling fan assembly FRU-5F10: 12 units available. Part request sent.')">
                        Request part <x-icon name="plus" :size="16" />
                    </button>
                </div>

                <label class="field-label">
                    Technician notes
                    <textarea name="notes" placeholder="Record diagnostics, repair steps, and quality checks…">{{ $selectedJob->technician_notes }}</textarea>
                </label>

                <button type="submit" class="primary">
                    Mark repaired & transfer to QC <x-icon name="check" :size="18" />
                </button>
            </form>
        </section>
    </div>

@elseif($role === 'customer')
    {{-- CUSTOMER PORTAL --}}
    <div class="page-heading">
        <div>
            <div class="eyebrow">CARE THAT GOES FURTHER</div>
            <h1>{{ $page === 'Track my repair' ? 'Your repair, in real time.' : 'Let’s get you back up and running.' }}</h1>
            <p>{{ $page === 'Track my repair' ? 'A little transparency. A lot of peace of mind.' : 'Check your warranty and tell us what’s happening. We’ll take it from here.' }}</p>
        </div>
        <span class="trust-label">
            <x-icon name="shield" :size="18" />
            Authorized care. Genuine parts.
        </span>
    </div>

    @if($page === 'Track my repair')
        @php
            $currentJob = $trackJob;
            if (request('ticket')) {
                $found = $allJobs->firstWhere('id', request('ticket'));
                if ($found) $currentJob = $found;
            }
        @endphp
        <div class="portal-content">
            <section class="panel">
                <div class="section-line">
                    <div>
                        <span class="eyebrow">YOUR REPAIR TICKET</span>
                        <h2>#RMA-{{ $currentJob->id }}</h2>
                        <p>{{ $currentJob->model }} {{ $currentJob->gen }} · {{ $currentJob->serial }}</p>
                    </div>
                    <span class="badge {{ $currentJob->quote_approved ? 'purple' : 'orange' }}">
                        {{ $currentJob->quote_approved ? 'Repair in progress' : $currentJob->status }}
                    </span>
                </div>

                <div class="sla-progress">
                    <span>Estimated completion <strong>Tomorrow, 4:00 PM</strong></span>
                    <div><i style="width: {{ $currentJob->quote_approved ? '68%' : '45%' }};"></i></div>
                </div>

                <div class="repair-timeline">
                    @php
                        $steps = ['Ticket received', 'Bench inspection', 'Awaiting parts', 'Repair & testing', 'Ready for pickup'];
                        $activeIdx = $currentJob->quote_approved ? 3 : 2;
                    @endphp
                    @foreach($steps as $idx => $step)
                        <div class="{{ $idx < $activeIdx ? 'complete' : ($idx === $activeIdx ? 'current' : '') }}">
                            <span>
                                @if($idx < $activeIdx)
                                    <x-icon name="check" :size="17" />
                                @else
                                    {{ $idx + 1 }}
                                @endif
                            </span>
                            <strong>{{ $step }}</strong>
                            <small>
                                {{ $idx === 0 ? 'Oct 23 · 9:30 AM' : ($idx === 1 ? 'Oct 23 · 2:15 PM' : ($idx === $activeIdx ? 'We’re on it' : 'Coming up')) }}
                            </small>
                        </div>
                    @endforeach
                </div>
            </section>

            <section class="panel quote-panel">
                <span class="quote-icon"><x-icon name="tool" :size="24" /></span>
                <h2>{{ $currentJob->quote_approved ? 'Quotation approved. Thank you!' : 'A small fix. A big difference.' }}</h2>
                <p>{{ $currentJob->quote_approved ? 'Your technician has been notified and your repair will continue.' : 'Your technician has prepared a quotation for the parts outside your warranty.' }}</p>

                <div class="quote-note">
                    “The cooling fan needs replacing to restore normal temperatures. All other components passed our inspection.”
                    <strong>Alex Morgan · Your technician</strong>
                </div>

                <div class="quote-row">
                    <span>Replacement cooling fan</span>
                    <strong>$45.00</strong>
                </div>
                <div class="quote-row">
                    <span>Labor</span>
                    <strong>Covered under warranty</strong>
                </div>
                <div class="quote-row">
                    <span>Express calibration</span>
                    <strong>$15.00</strong>
                </div>

                <div class="quote-total">
                    <span>Total estimate</span>
                    <strong>${{ number_format($currentJob->quote_amount, 2) }}</strong>
                </div>

                <div class="quote-actions">
                    @if(!$currentJob->quote_approved)
                        <form action="{{ route('quotes.approve', $currentJob->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="primary">
                                <x-icon name="check" :size="18" /> Approve quotation
                            </button>
                        </form>
                    @else
                        <button class="primary" disabled>
                            <x-icon name="check" :size="18" /> Approved
                        </button>
                    @endif
                    <button type="button" class="secondary" onclick="showToast('Your technician has received your callback request and will contact you shortly.')">
                        Decline / Speak to tech
                    </button>
                </div>
            </section>
        </div>
    @else
        {{-- Warranty & Repair Form --}}
        <div class="portal-content">
            <section class="panel warranty-panel">
                <h2>Start with your serial number.</h2>
                <p>You’ll find it on the underside of your laptop or in your device settings.</p>

                <form class="serial-search" id="warrantyCheckForm" onsubmit="event.preventDefault(); verifySerial();">
                    <x-icon name="search" />
                    <input type="text" id="serialInput" placeholder="Enter 8–12 character serial number" value="PF4X9K2L" maxlength="12" required>
                    <button type="submit" class="primary">
                        Check warranty <x-icon name="arrow" :size="17" />
                    </button>
                </form>

                <div id="warrantyResultCard" class="warranty-result">
                    <x-icon name="laptop" :size="52" />
                    <div>
                        <h3 id="resModel">ThinkPad X1 Carbon Gen 11</h3>
                        <p id="resSerial">Serial: PF4X9K2L</p>
                        <span class="badge green" id="resBadge">
                            <x-icon name="shield" :size="14" /> Active · Premier Onsite NBD · 184 days left
                        </span>
                    </div>
                    <x-icon name="check" :size="22" />
                </div>
            </section>

            <form class="panel repair-form" action="{{ route('customer.submit-ticket') }}" method="POST">
                @csrf
                <input type="hidden" name="serial" id="formSerial" value="PF4X9K2L">

                <div class="section-line">
                    <h2>Tell us what’s wrong.</h2>
                    <span>We’re here to help.</span>
                </div>

                <label class="field-label">Select the symptoms</label>
                <div class="symptom-options" id="symptomContainer">
                    @foreach(['Motherboard / Power', 'Display', 'Keyboard / Trackpad', 'Thermal / Overheating'] as $sym)
                        <button type="button" class="symptom {{ $sym === 'Thermal / Overheating' ? 'chosen' : '' }}" onclick="toggleSymptom(this, '{{ $sym }}')">
                            <x-icon :name="$sym === 'Thermal / Overheating' ? 'check' : 'plus'" :size="16" />
                            {{ $sym }}
                        </button>
                    @endforeach
                </div>
                <div id="symptomInputs">
                    <input type="hidden" name="symptoms[]" value="Thermal / Overheating" id="sym_Thermal_Overheating">
                </div>

                <label class="field-label">
                    A little more detail
                    <textarea name="description" required placeholder="When did it start? What happens when you use your laptop?">Fan makes excessive buzzing noise and thermal throttling occurs under moderate multitasking.</textarea>
                </label>

                <label class="upload-zone">
                    <x-icon name="upload" :size="25" />
                    <strong>Drop your diagnostic photos here, or <span>browse files</span></strong>
                    <small>PNG, JPG or WEBP · Photos help us diagnose faster</small>
                    <input type="file" accept="image/*" multiple onchange="showToast('Diagnostic files attached.')">
                </label>

                <label class="field-label">How would you like to get your device to us?</label>
                <div class="service-options">
                    <button type="button" class="selected" id="optDropOff" onclick="selectDelivery(this, 'Drop-off at service center')">
                        <x-icon name="box" />
                        Drop-off at service center
                        <span class="radio-dot"></span>
                    </button>
                    <button type="button" id="optCourier" onclick="selectDelivery(this, 'Secure courier pickup')">
                        <x-icon name="shield" />
                        Secure courier pickup
                        <span class="radio-dot"></span>
                    </button>
                    <input type="hidden" name="method" id="deliveryMethod" value="Drop-off at service center">
                </div>

                <div class="form-footer">
                    <span>
                        <x-icon name="shield" :size="16" /> Your device is in safe hands.
                    </span>
                    <button type="submit" class="primary">
                        Submit repair ticket <x-icon name="arrow" :size="17" />
                    </button>
                </div>
            </form>
        </div>
    @endif

@elseif($page === 'Staff & permissions' && $role === 'manager')
    {{-- STAFF & PERMISSIONS DIRECTORY --}}
    <div class="account-settings">
        <div class="page-heading">
            <div>
                <div class="eyebrow">SETTINGS / STAFF & PERMISSIONS</div>
                <h1>Great service starts with your people.</h1>
                <p>Manage your team, assign service benches, and give everyone the right access.</p>
            </div>
            <button type="button" class="primary" onclick="openStaffModal()">
                + Invite new staff
            </button>
        </div>

        <div class="metrics-grid advanced-metrics">
            <section class="metric-card">
                <div class="metric-top">Total staff</div>
                <div class="metric-number">{{ $staffMembers->count() }}</div>
                <div class="metric-foot">Current demo directory</div>
            </section>
            <section class="metric-card">
                <div class="metric-top">Active technicians</div>
                <div class="metric-number">{{ $staffMembers->where('active', true)->where('role', 'Bench Tech')->count() }}</div>
                <div class="metric-foot">Current demo directory</div>
            </section>
            <section class="metric-card">
                <div class="metric-top">Service managers</div>
                <div class="metric-number">{{ $staffMembers->where('active', true)->where('role', 'Service Manager')->count() }}</div>
                <div class="metric-foot">Current demo directory</div>
            </section>
            <section class="metric-card">
                <div class="metric-top">Super admins</div>
                <div class="metric-number">{{ $staffMembers->where('active', true)->where('role', 'Super Admin')->count() }}</div>
                <div class="metric-foot">Current demo directory</div>
            </section>
        </div>

        <section class="queue-panel">
            <div class="queue-heading">
                <div>
                    <h2>Team directory <span>{{ $staffMembers->count() }}</span></h2>
                    <p>The right people. The right permissions.</p>
                </div>
                <span class="badge green">Role-based access</span>
            </div>

            <div class="queue-tabs">
                @foreach(['All', 'Super Admin', 'Service Manager', 'Bench Tech', 'Service Desk', 'B2B Coordinator'] as $rFilter)
                    <button type="button" class="{{ $loop->first ? 'selected' : '' }}" onclick="filterStaffRole(this, '{{ $rFilter }}')">
                        {{ $rFilter }}
                    </button>
                @endforeach
            </div>

            <div class="filter-bar">
                <div class="search-field">
                    <x-icon name="search" :size="18" />
                    <input type="text" id="staffSearchInput" aria-label="Search staff" placeholder="Search name, email or bench…" onkeyup="filterStaffTable()">
                </div>
                <select class="reassign-select" id="staffStatusSelect" aria-label="Account status filter" onchange="filterStaffTable()">
                    <option value="All">All statuses</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>

            <div class="table-scroll">
                <table id="staffTable">
                    <thead>
                        <tr>
                            <th>STAFF MEMBER</th>
                            <th>ASSIGNED ROLE</th>
                            <th>STATION / BENCH</th>
                            <th>2FA STATUS</th>
                            <th>ACCOUNT</th>
                            <th>LAST ACTIVE</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($staffMembers as $s)
                            @php
                                $initials = collect(explode(' ', $s->name))->map(fn($w) => $w[0] ?? '')->take(2)->join('');
                                $roleBadgeColor = match($s->role) {
                                    'Super Admin' => 'orange',
                                    'Bench Tech' => 'blue',
                                    'Service Desk' => 'green',
                                    default => 'purple',
                                };
                            @endphp
                            <tr data-role="{{ $s->role }}" data-status="{{ $s->active ? 'Active' : 'Inactive' }}" data-search="{{ strtolower($s->name . ' ' . $s->email . ' ' . $s->bench) }}">
                                <td>
                                    <div class="staff-person">
                                        <span class="avatar">{{ $initials }}</span>
                                        <div>
                                            <strong>{{ $s->name }}</strong>
                                            <small>{{ $s->email }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge {{ $roleBadgeColor }}">{{ $s->role }}</span>
                                </td>
                                <td>{{ $s->bench }}</td>
                                <td>
                                    <span class="badge {{ $s->two_fa ? 'green' : 'orange' }}">
                                        {{ $s->two_fa ? '✓ Enabled' : 'Pending setup' }}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge {{ $s->active ? 'green' : 'blue' }}">
                                        {{ $s->active ? 'Active' : 'Inactive' }}
                                    </span>
                                </td>
                                <td>{{ $s->active ? 'Today · 09:42' : 'Oct 20 · 16:30' }}</td>
                                <td>
                                    <div class="staff-actions">
                                        <button type="button" class="text-button" onclick='openStaffModal(@json($s))'>Manage</button>
                                        <div style="position: relative; display: inline-block;">
                                            <button type="button" aria-label="Actions for {{ $s->name }}" onclick="toggleStaffMenu({{ $s->id }})">•••</button>
                                            <div id="staffMenu_{{ $s->id }}" class="staff-menu" style="display: none; position: absolute; right: 0; top: 100%; z-index: 25; width: 140px;">
                                                <button type="button" onclick='openStaffModal(@json($s)); toggleStaffMenu({{ $s->id }});'>Edit permissions</button>
                                                <form action="{{ route('staff.reset', $s->id) }}" method="POST">
                                                    @csrf
                                                    <button type="submit">Reset password</button>
                                                </form>
                                                <form action="{{ route('staff.toggle', $s->id) }}" method="POST">
                                                    @csrf
                                                    <button type="submit">{{ $s->active ? 'Deactivate' : 'Activate' }}</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="table-footer">
                <span>{{ $staffMembers->count() }} staff members · Saved to database</span>
            </div>
        </section>
    </div>

    <!-- Staff Invite/Edit Drawer Overlay -->
    <div id="staffModalOverlay" class="drawer-overlay" style="display:none;" onclick="closeStaffModal()">
        <aside class="loaner-drawer" role="dialog" aria-modal="true" onclick="event.stopPropagation()">
            <form action="{{ route('staff.save') }}" method="POST">
                @csrf
                <input type="hidden" name="id" id="staffEditId">
                <div class="drawer-heading">
                    <span class="eyebrow">THE RIGHT ACCESS, BY DESIGN</span>
                    <button type="button" aria-label="Close" onclick="closeStaffModal()">×</button>
                </div>
                <h2 id="staffModalTitle">Invite your next expert.</h2>
                <p>Give your team the tools they need. Nothing more.</p>

                <label class="account-field">
                    Full name
                    <input type="text" name="name" id="staffEditName" required placeholder="Full Name">
                </label>

                <label class="account-field">
                    Staff email
                    <input type="email" name="email" id="staffEditEmail" required placeholder="user@omnifix.com">
                </label>

                <label class="account-field">
                    Assigned role
                    <select name="role" id="staffEditRole">
                        <option value="Super Admin">Super Admin</option>
                        <option value="Service Manager">Service Manager</option>
                        <option value="Bench Tech">Bench Tech</option>
                        <option value="Service Desk">Service Desk</option>
                        <option value="B2B Coordinator">B2B Coordinator</option>
                    </select>
                </label>

                <label class="account-field">
                    Service bench / Station
                    <input type="text" name="bench" id="staffEditBench" required placeholder="HQ Operations or Bench name">
                </label>

                <div class="permission-title">
                    <h3>Permission matrix</h3>
                    <p>Fine-tune individual responsibilities.</p>
                </div>

                @php
                    $permLabels = ['Ticket dispatch', 'Warranty claim approval', 'Parts requisition', 'Customer quoting', 'Financial reports'];
                @endphp
                @foreach($permLabels as $pIdx => $pLabel)
                    <div class="permission-row">
                        <span>{{ $pLabel }}</span>
                        <input type="hidden" name="permissions[{{ $pIdx }}]" id="perm_inp_{{ $pIdx }}" value="0">
                        <button type="button" role="switch" id="perm_btn_{{ $pIdx }}" class="permission-toggle" onclick="togglePermissionSwitch({{ $pIdx }})">
                            <span></span>
                        </button>
                    </div>
                @endforeach

                <div class="drawer-footer">
                    <button type="submit" class="primary">Save changes →</button>
                    <button type="button" class="secondary" onclick="closeStaffModal()">Cancel</button>
                </div>
            </form>
        </aside>
    </div>

@elseif($page === 'Settings')
    {{-- PROFILE & SECURITY (ACCOUNT SETTINGS) --}}
    <div class="account-settings">
        <div class="page-heading">
            <div>
                <div class="eyebrow">SETTINGS / YOUR ACCOUNT</div>
                <h1>Your profile. Your peace of mind.</h1>
                <p>Keep your details up to date and your account protected.</p>
            </div>
            <a href="{{ route('logout') }}" class="secondary">
                Sign out →
            </a>
        </div>

        <div class="profile-layout">
            <nav class="profile-subnav">
                <button type="button" id="profTabBtn_profile" class="active" onclick="switchProfileTab('profile')">My profile</button>
                <button type="button" id="profTabBtn_security" onclick="switchProfileTab('security')">Security & 2FA</button>
                <button type="button" id="profTabBtn_sessions" onclick="switchProfileTab('sessions')">Active sessions & audit log</button>

                <div class="profile-safe">
                    <x-icon name="shield" :size="24" />
                    <strong>A little security goes a long way.</strong>
                    <p>Review your profile and access regularly.</p>
                </div>
            </nav>

            <div>
                <!-- SECTION 1: MY PROFILE -->
                <div id="profSection_profile">
                    <form class="panel" action="{{ route('settings.save') }}" method="POST">
                        @csrf
                        <div class="section-line">
                            <div>
                                <h2>Profile information</h2>
                                <p>Your details help your team stay connected.</p>
                            </div>
                            <span class="badge orange">Staff account</span>
                        </div>

                        <div class="profile-upload">
                            <span class="avatar" id="avatarPreviewBox">{{ $currentUser['avatar'] ?? 'SM' }}</span>
                            <div>
                                <label class="secondary">
                                    Upload new photo
                                    <input type="file" accept="image/*" onchange="previewAvatar(this)">
                                </label>
                                <p>JPG, PNG or WEBP · Max. 5 MB</p>
                            </div>
                        </div>

                        <div class="profile-fields">
                            <label class="account-field">
                                First name
                                <input type="text" name="first_name" value="{{ explode(' ', $currentUser['name'] ?? 'Alex Morgan')[0] }}" required>
                            </label>
                            <label class="account-field">
                                Last name
                                <input type="text" name="last_name" value="{{ explode(' ', $currentUser['name'] ?? 'Alex Morgan')[1] ?? '' }}" required>
                            </label>
                            <label class="account-field">
                                Staff ID
                                <input type="text" readonly value="{{ $currentUser['staffId'] ?? 'TECH-8402' }}">
                            </label>
                            <label class="account-field">
                                Department
                                <input type="text" name="department" value="{{ $currentUser['department'] ?? 'Hardware Diagnostics' }}">
                            </label>
                            <label class="account-field">
                                Official title
                                <input type="text" name="title" value="{{ $currentUser['title'] ?? 'Senior Hardware Diagnostic Specialist' }}">
                            </label>
                            <label class="account-field">
                                Phone number
                                <input type="tel" value="+66 81 234 5678">
                            </label>
                        </div>

                        <div class="form-footer">
                            <span>Demo profile · Synced to current workspace session</span>
                            <button type="submit" class="primary">Save changes →</button>
                        </div>
                    </form>
                </div>

                <!-- SECTION 2: SECURITY & 2FA -->
                <div id="profSection_security" style="display: none;">
                    <form class="panel" onsubmit="event.preventDefault(); showToast('Demo password change complete. No real credentials were modified.');">
                        <h2>Change your password</h2>
                        <p>Use a unique password you haven’t used elsewhere.</p>

                        <label class="account-field">
                            Current password
                            <div class="password-input">
                                <input type="password" required placeholder="Enter current password">
                            </div>
                        </label>

                        <label class="account-field">
                            New password
                            <div class="password-input">
                                <input type="password" id="secNewPass" required placeholder="Enter new password" onkeyup="checkSettingsPasswordRules(this.value)">
                            </div>
                        </label>

                        <div class="password-rules" style="margin-top: 10px;">
                            <span id="sec-rule-len">○ At least 8 characters</span>
                            <span id="sec-rule-upper">○ One uppercase letter</span>
                            <span id="sec-rule-num">○ One number</span>
                            <span id="sec-rule-spec">○ One special character</span>
                        </div>

                        <label class="account-field">
                            Confirm new password
                            <div class="password-input">
                                <input type="password" required placeholder="Confirm new password">
                            </div>
                        </label>

                        <button type="submit" class="primary">Update password</button>
                    </form>

                    <section class="panel">
                        <div class="section-line">
                            <div>
                                <h2>Two-factor authentication</h2>
                                <p>Add a second layer of account protection.</p>
                            </div>
                            <x-icon name="shield" :size="24" />
                        </div>

                        <div class="security-status">
                            <span class="badge green" id="twoFaBadge">✓ Enabled</span>
                            <div>
                                <strong>Authenticator app (TOTP)</strong>
                                <p id="twoFaStatusText">Demo account protected by Google Authenticator.</p>
                            </div>
                            <button type="button" role="switch" id="twoFaToggleBtn" class="permission-toggle enabled" onclick="toggleTwoFaStatus()">
                                <span></span>
                            </button>
                        </div>

                        <button type="button" class="secondary" onclick="openTotpModal()">
                            Reconfigure 2FA
                        </button>
                    </section>
                </div>

                <!-- SECTION 3: ACTIVE SESSIONS -->
                <div id="profSection_sessions" style="display: none;">
                    <section class="panel">
                        <div class="section-line">
                            <div>
                                <h2>Active sessions & audit log</h2>
                                <p>Know where your account is signed in.</p>
                            </div>
                            <button type="button" class="danger-link" onclick="revokeOtherSessions()">
                                Sign out other sessions
                            </button>
                        </div>

                        <div class="table-scroll">
                            <table id="sessionsTable">
                                <thead>
                                    <tr>
                                        <th>DEVICE / BROWSER</th>
                                        <th>IP ADDRESS</th>
                                        <th>LOCATION</th>
                                        <th>LAST ACTIVE</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr id="session_1">
                                        <td>
                                            <strong>Chrome on macOS</strong>
                                            <small>Current session</small>
                                        </td>
                                        <td>192.0.2.12</td>
                                        <td>Bangkok, TH</td>
                                        <td>Just now</td>
                                        <td><span class="badge green">Current</span></td>
                                    </tr>
                                    <tr id="session_2">
                                        <td>
                                            <strong>Edge on Windows 11</strong>
                                            <small>Trusted device</small>
                                        </td>
                                        <td>192.0.2.24</td>
                                        <td>Bangkok, TH</td>
                                        <td>2 hours ago</td>
                                        <td><button type="button" class="danger-link" onclick="revokeSingleSession('session_2')">Revoke session</button></td>
                                    </tr>
                                    <tr id="session_3">
                                        <td>
                                            <strong>Safari on iPhone</strong>
                                            <small>Trusted device</small>
                                        </td>
                                        <td>192.0.2.36</td>
                                        <td>Bangkok, TH</td>
                                        <td>Yesterday</td>
                                        <td><button type="button" class="danger-link" onclick="revokeSingleSession('session_3')">Revoke session</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="quote-note">
                            Illustrative session activity only. Live session revocation requires a connected identity provider.
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>

    <!-- Reconfigure 2FA TOTP Modal -->
    <div id="totpModalOverlay" class="drawer-overlay" style="display:none;" onclick="closeTotpModal()">
        <section class="bulk-modal" role="dialog" aria-modal="true" onclick="event.stopPropagation()">
            <form onsubmit="event.preventDefault(); handleTotpVerify();">
                <div class="auth-security-icon">
                    <x-icon name="shield" :size="24" />
                </div>
                <h2>Connect your authenticator.</h2>
                <p>This is a setup preview, not a scannable enrollment QR. Production setup requires a secure server-generated secret.</p>

                <div class="totp-preview">
                    <x-icon name="shield" :size="32" />
                    <strong>TOTP setup preview</strong>
                    <span>Demo verification code: <strong>123456</strong></span>
                </div>

                <label class="account-field">
                    Verification code
                    <input type="text" id="totpCodeInput" required inputmode="numeric" maxlength="6" placeholder="123456">
                </label>

                <div class="quote-actions">
                    <button type="submit" class="primary">Verify & enable</button>
                    <button type="button" class="secondary" onclick="closeTotpModal()">Cancel</button>
                </div>
            </form>
        </section>
    </div>

@elseif($page === 'Parts inventory')
    {{-- PARTS INVENTORY FOR BENCH TECH --}}
    <div class="page-heading">
        <div>
            <h1>Parts inventory</h1>
            <p>Genuine parts. Ready when you need them.</p>
        </div>
    </div>

    <section class="panel">
        <div class="section-line">
            <h2>Available components</h2>
            <span>Central service stock</span>
        </div>
        @foreach($parts as $part)
            <div class="inventory-row">
                <span class="part-icon"><x-icon name="box" /></span>
                <div>
                    <strong>{{ $part->name }}</strong>
                    <small>{{ $part->sku }} · Compatible: {{ $part->compatible_models }}</small>
                </div>
                <span class="badge {{ $part->stock > 0 ? 'green' : 'orange' }}">
                    {{ $part->stock }} units available
                </span>
                <form action="{{ route('inventory.reserve', $part->sku) }}" method="POST">
                    @csrf
                    <button type="submit" class="secondary">Reserve part</button>
                </form>
            </div>
        @endforeach
    </section>

@elseif($role === 'manager' || $role === 'corporate')
    {{-- ADVANCED WORKSPACE (MANAGER / CORPORATE) --}}
    <div class="advanced-workspace">
        <div class="advanced-context">
            <span>
                <i></i>
                {{ $role === 'corporate' ? 'CORPORATE GOLD SLA' : 'OMNIFIX OPERATIONS HUB' }}
            </span>
            <div>
                @if($role === 'corporate')
                    <select aria-label="Company" onchange="window.location.search = '?role=corporate&company=' + encodeURIComponent(this.value)">
                        <option value="Acme Corp" {{ $company === 'Acme Corp' ? 'selected' : '' }}>Acme Corp</option>
                        <option value="FinTech Global Ltd." {{ $company === 'FinTech Global Ltd.' ? 'selected' : '' }}>FinTech Global Ltd.</option>
                    </select>
                @else
                    <select aria-label="Service branch" onchange="window.location.search = '?role=manager&branch=' + encodeURIComponent(this.value)">
                        <option value="Bangkok Central" {{ $branch === 'Bangkok Central' ? 'selected' : '' }}>Bangkok Central</option>
                        <option value="Bangkok North" {{ $branch === 'Bangkok North' ? 'selected' : '' }}>Bangkok North</option>
                    </select>
                    <select aria-label="Report period" onchange="window.location.search = '?role=manager&range=' + encodeURIComponent(this.value)">
                        <option value="Last 30 days" {{ $range === 'Last 30 days' ? 'selected' : '' }}>Last 30 days</option>
                        <option value="Last 7 days" {{ $range === 'Last 7 days' ? 'selected' : '' }}>Last 7 days</option>
                    </select>
                @endif
            </div>
        </div>

        <div class="page-heading">
            <div>
                <div class="eyebrow">
                    {{ $role === 'corporate' ? 'LESS DOWNTIME. MORE POSSIBILITY.' : 'A CLEARER PICTURE. BETTER SERVICE.' }}
                </div>
                <h1>
                    @if($role === 'corporate')
                        {{ $page === 'Fleet overview' ? 'Your fleet, in good hands.' : $page }}
                    @else
                        {{ $page === 'Operations overview' ? 'Service excellence, at a glance.' : $page }}
                    @endif
                </h1>
                <p>
                    @if($role === 'corporate')
                        {{ $company }} · 240 managed laptops · Every device. Every employee. Taken care of.
                    @else
                        {{ $branch }} Service Branch · Keep your people, parts, and promises in sync.
                    @endif
                </p>
            </div>

            @if($role === 'corporate')
                <button type="button" class="primary" onclick="openBulkModal()">
                    + Bulk claim & service
                </button>
            @else
                <a href="{{ route('reports.export', ['role' => 'manager']) }}" class="secondary">
                    ↓ Export report
                </a>
            @endif
        </div>

        @if($role === 'corporate')
            {{-- Corporate Metrics --}}
            <div class="metrics-grid advanced-metrics">
                <section class="metric-card">
                    <div class="metric-top">Total active units<span class="metric-icon icon-0"><x-icon name="laptop" :size="18" /></span></div>
                    <div class="metric-number">240</div>
                    <div class="metric-foot success">Across 6 departments</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">Currently in repair<span class="metric-icon icon-1"><x-icon name="tool" :size="18" /></span></div>
                    <div class="metric-number">8</div>
                    <div class="metric-foot success">2 inspecting · 4 awaiting parts</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">Loaner units deployed<span class="metric-icon icon-2"><x-icon name="box" :size="18" /></span></div>
                    <div class="metric-number">{{ $loaners->count() }} / 5</div>
                    <div class="metric-foot success">{{ 5 - $loaners->count() }} units available in your agreement</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">Warranty expiring soon<span class="metric-icon icon-3"><x-icon name="clock" :size="18" /></span></div>
                    <div class="metric-number">12</div>
                    <div class="metric-foot success">Within the next 30 days</div>
                </section>
            </div>

            @if($page === 'Loaner units')
                <section class="panel advanced-section">
                    <div class="section-line">
                        <div>
                            <h2>Keep work moving.</h2>
                            <p>Your standby devices, deployed under Gold SLA.</p>
                        </div>
                        <button type="button" class="primary" onclick="openLoanerDrawer('9041')" {{ $loaners->count() >= 5 ? 'disabled' : '' }}>
                            Request loaner
                        </button>
                    </div>

                    @foreach($loaners as $loaner)
                        <div class="inventory-row">
                            <span class="part-icon">PC</span>
                            <div>
                                <strong>{{ $loaner->employee }}</strong>
                                <small>RMA-{{ $loaner->ticket_id }} · {{ $loaner->profile }}</small>
                            </div>
                            <span class="badge green">Deployed</span>
                            <form action="{{ route('loaners.return', $loaner->ticket_id) }}" method="POST">
                                @csrf
                                <button type="submit" class="secondary">Record return</button>
                            </form>
                        </div>
                    @endforeach
                </section>

            @elseif($page === 'SLA reports')
                <section class="panel advanced-section">
                    <div class="section-line">
                        <div>
                            <h2>Corporate service performance</h2>
                            <p>Gold tier · 1 business day loaner · 48h repair target</p>
                        </div>
                        <a href="{{ route('reports.export', ['role' => 'corporate']) }}" class="secondary">
                            Download fleet report
                        </a>
                    </div>

                    <div class="metrics-grid">
                        <section class="metric-card">
                            <div class="metric-top">SLA compliance</div>
                            <div class="metric-number">98.2%</div>
                            <div class="metric-foot success">Above your 95% guarantee</div>
                        </section>
                        <section class="metric-card">
                            <div class="metric-top">Average turnaround</div>
                            <div class="metric-number">28.5h</div>
                            <div class="metric-foot success">19.5h under your SLA target</div>
                        </section>
                        <section class="metric-card">
                            <div class="metric-top">Repairs completed</div>
                            <div class="metric-number">42</div>
                            <div class="metric-foot success">This month</div>
                        </section>
                        <section class="metric-card">
                            <div class="metric-top">Loaner coverage</div>
                            <div class="metric-number">100%</div>
                            <div class="metric-foot success">All eligible requests fulfilled</div>
                        </section>
                    </div>
                </section>

            @else
                {{-- Fleet Overview / Active Repairs Table --}}
                <section class="queue-panel advanced-section">
                    <div class="queue-heading">
                        <div>
                            <h2>{{ $page === 'Active repairs' ? 'Active repair monitor' : 'Laptops currently under service' }} <span>{{ $fleetAssets->count() }}</span></h2>
                            <p>Stay close to every repair without chasing an update.</p>
                        </div>
                        <span class="badge green">Gold SLA protected</span>
                    </div>

                    <div class="filter-bar">
                        <div class="search-field">
                            <x-icon name="search" :size="18" />
                            <input type="text" placeholder="Search employee, asset or device…" value="{{ $search }}" onkeyup="filterTable(this.value, 'fleetTable')">
                        </div>
                        <a href="{{ route('home', ['role' => 'corporate', 'page' => 'Loaner units']) }}" class="text-button">
                            Manage loaner devices →
                        </a>
                    </div>

                    <div class="table-scroll">
                        <table id="fleetTable">
                            <thead>
                                <tr>
                                    <th>ASSET / TICKET</th>
                                    <th>EMPLOYEE</th>
                                    <th>LAPTOP / SERIAL</th>
                                    <th>REPORTED ISSUE</th>
                                    <th>REPAIR STATUS</th>
                                    <th>SLA TARGET</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($fleetAssets as $row)
                                    @php $hasLoaner = $loaners->contains('ticket_id', $row->id); @endphp
                                    <tr>
                                        <td>
                                            <strong class="ticket-number">{{ $row->asset_tag }}</strong>
                                            <small>RMA-{{ $row->id }}</small>
                                        </td>
                                        <td>
                                            <strong>{{ $row->employee }}</strong>
                                            <small>{{ $row->department }}</small>
                                        </td>
                                        <td>
                                            <strong>{{ $row->model }}</strong>
                                            <small>{{ $row->serial }}</small>
                                        </td>
                                        <td>{{ $row->issue }}</td>
                                        <td>
                                            <span class="badge {{ $row->status === 'Awaiting parts' ? 'orange' : ($row->status === 'Quality check' ? 'green' : 'blue') }}">
                                                {{ $row->status }}
                                            </span>
                                        </td>
                                        <td><span class="sla-badge warning">{{ $row->time_remaining }} left</span></td>
                                        <td>
                                            <button type="button" class="loaner-action"
                                                    {{ $hasLoaner || $loaners->count() >= 5 ? 'disabled' : '' }}
                                                    onclick="openLoanerDrawer('{{ $row->id }}')">
                                                {{ $hasLoaner ? 'Loaner dispatched' : 'Request loaner →' }}
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="table-footer">
                        Showing {{ $fleetAssets->count() }} active service records · All times in ICT
                    </div>
                </section>
            @endif

        @elseif($page === 'Technician dispatch')
            {{-- MANAGER DISPATCH BOARD --}}
            <div class="sla-alert">
                <div class="alert-clock"><x-icon name="tool" :size="20" /></div>
                <div>
                    <strong>Balance the bench. Protect the promise.</strong>
                    <span> Select a technician or workstation below to reassign work.</span>
                </div>
                <span class="badge orange">5-job bench capacity</span>
            </div>

            <div class="dispatch-board">
                @foreach($benches as $index => $name)
                    @php $assigned = $dispatchTickets->where('bench', $index); @endphp
                    <section class="bench-column {{ $assigned->count() >= 5 ? 'bench-risk' : '' }}">
                        <div class="bench-header">
                            <div class="eyebrow">{{ $index === 3 ? 'INTAKE QUEUE' : 'WORKSTATION 0' . ($index + 1) }}</div>
                            <h3>
                                {{ $name }}
                                <span>{{ $assigned->count() }}{{ $index !== 3 ? '/5' : '' }}</span>
                            </h3>
                            <p>{{ ['Master tech · Motherboard', 'Display & mechanical', 'General repair & QC', 'Waiting for assignment'][$index] }}</p>
                            <progress max="5" value="{{ $assigned->count() }}"></progress>
                            <span class="badge {{ $assigned->count() >= 5 ? 'orange' : 'green' }}">
                                {{ $index === 3 ? 'Ready to assign' : ($assigned->count() >= 5 ? 'At capacity · SLA risk' : 'Available capacity') }}
                            </span>
                        </div>

                        <div class="bench-tickets">
                            @foreach($assigned as $ticket)
                                <article class="dispatch-ticket {{ $ticket->id === '9043' ? 'urgent-ticket' : '' }}">
                                    <div class="ticket-card-top">
                                        <span>RMA-{{ $ticket->id }}</span>
                                        <span aria-hidden="true">⠿</span>
                                    </div>
                                    <div class="ticket-device-symbol">
                                        <x-icon name="laptop" :size="32" />
                                    </div>
                                    <h3>{{ $ticket->model }}</h3>
                                    <p>{{ $ticket->issue }}</p>
                                    <span class="sla-badge {{ $ticket->id === '9043' ? 'warning' : '' }}">
                                        {{ $ticket->time_remaining }} until deadline
                                    </span>
                                    <form action="{{ route('dispatch.reassign') }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $ticket->id }}">
                                        <label class="assignment-label">
                                            Assign to
                                            <select name="bench" onchange="this.form.submit()">
                                                @foreach($benches as $bIdx => $bName)
                                                    <option value="{{ $bIdx }}" {{ $ticket->bench === $bIdx ? 'selected' : '' }}>
                                                        {{ $bName }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </label>
                                    </form>
                                </article>
                            @endforeach
                        </div>
                    </section>
                @endforeach
            </div>

        @elseif($page === 'Stock oversight')
            {{-- MANAGER STOCK OVERSIGHT --}}
            @php $lowStockCount = $parts->where('stock', '<', 3)->where('on_order', false)->count(); @endphp
            <div class="sla-alert">
                <div class="alert-clock"><x-icon name="box" :size="20" /></div>
                <div>
                    <strong>{{ $lowStockCount }} components below safe stock threshold.</strong>
                    <span> Keep repairs moving with proactive factory replenishment.</span>
                </div>
                <form action="{{ route('inventory.batch-order') }}" method="POST" style="margin-left:auto;">
                    @csrf
                    <button type="submit" class="secondary" style="color:#ac802b; font-weight:650;">
                        Approve batch PO →
                    </button>
                </form>
            </div>

            <section class="queue-panel">
                <div class="queue-heading">
                    <div>
                        <h2>Parts inventory & stock health</h2>
                        <p>Genuine parts. The right stock. No unnecessary delays.</p>
                    </div>
                </div>

                <div class="queue-tabs">
                    @foreach(['All parts', 'Low stock', 'Out of stock', 'On order'] as $stTab)
                        <a href="{{ route('home', ['role' => 'manager', 'page' => 'Stock oversight', 'stockFilter' => $stTab]) }}"
                           class="tab-btn {{ $stockFilter === $stTab ? 'selected' : '' }}">
                            {{ $stTab }}
                        </a>
                    @endforeach
                </div>

                <div class="filter-bar">
                    <div class="search-field">
                        <x-icon name="search" :size="18" />
                        <input type="text" placeholder="Search SKU, component or laptop model…" onkeyup="filterTable(this.value, 'partsStockTable')">
                    </div>
                </div>

                <div class="table-scroll">
                    <table id="partsStockTable">
                        <thead>
                            <tr>
                                <th>PART NAME / CATEGORY</th>
                                <th>SKU</th>
                                <th>COMPATIBLE MODELS</th>
                                <th>IN STOCK</th>
                                <th>RESERVED</th>
                                <th>MIN. STOCK</th>
                                <th>STATUS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($parts as $p)
                                <tr>
                                    <td>
                                        <strong>{{ $p->name }}</strong>
                                        <small>{{ $p->category }}</small>
                                    </td>
                                    <td>{{ $p->sku }}</td>
                                    <td>{{ $p->compatible_models }}</td>
                                    <td>
                                        <strong class="{{ $p->stock < $p->min_stock ? 'stock-warning' : '' }}">{{ $p->stock }}</strong>
                                    </td>
                                    <td>{{ $p->reserved }}</td>
                                    <td>{{ $p->min_stock }}</td>
                                    <td>
                                        <span class="badge {{ $p->on_order ? 'blue' : ($p->stock === 0 ? 'orange' : ($p->stock < $p->min_stock ? 'orange' : 'green')) }}">
                                            {{ $p->on_order ? 'On order' : ($p->stock === 0 ? 'Out of stock' : ($p->stock < $p->min_stock ? 'Critical low' : 'In stock')) }}
                                        </span>
                                    </td>
                                    <td>
                                        @if(!$p->on_order && $p->stock < $p->min_stock)
                                            <form action="{{ route('inventory.order', $p->sku) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="loaner-action">Approve reorder →</button>
                                            </form>
                                        @elseif($p->on_order)
                                            <button class="loaner-action" disabled>PO approved</button>
                                        @else
                                            <button type="button" class="loaner-action" onclick="showToast('{{ $p->name }}: {{ $p->stock - $p->reserved }} units available for allocation.')">
                                                Check availability →
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>

        @else
            {{-- MANAGER OPERATIONS OVERVIEW --}}
            <div class="metrics-grid">
                <section class="metric-card">
                    <div class="metric-top">Monthly completed repairs<span class="metric-icon icon-0"><x-icon name="check" :size="18" /></span></div>
                    <div class="metric-number">{{ $range === 'Last 7 days' ? '312' : '1,248' }}</div>
                    <div class="metric-foot success"><x-icon name="arrow" :size="13" /> +12% versus previous period</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">On-time SLA compliance<span class="metric-icon icon-1"><x-icon name="clock" :size="18" /></span></div>
                    <div class="metric-number">98.2%</div>
                    <div class="metric-foot success"><x-icon name="check" :size="13" /> Above target of 95%</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">First-time fix rate<span class="metric-icon icon-2"><x-icon name="trend" :size="18" /></span></div>
                    <div class="metric-number">94.1%</div>
                    <div class="metric-foot success"><x-icon name="arrow" :size="13" /> +2.4% versus last month</div>
                </section>
                <section class="metric-card">
                    <div class="metric-top">Avg. turnaround time<span class="metric-icon icon-3"><x-icon name="laptop" :size="18" /></span></div>
                    <div class="metric-number">1.8 <span>days</span></div>
                    <div class="metric-foot success"><x-icon name="trend" :size="13" /> CSAT 4.9 / 5</div>
                </section>
            </div>

            <div class="analytics-grid">
                <!-- Throughput Chart -->
                <section class="panel chart-panel">
                    <div class="section-line">
                        <div>
                            <h2>Repair volume & throughput</h2>
                            <p>A steady flow. A stronger service center.</p>
                        </div>
                        <span class="badge green">+12% efficiency</span>
                    </div>

                    <div class="chart-legend">
                        <span><i class="legend-intake"></i>Incoming repairs</span>
                        <span><i class="legend-complete"></i>Completed repairs</span>
                    </div>

                    <svg class="volume-chart" viewBox="0 0 620 230" role="img" aria-label="Daily incoming repairs and completed repairs comparison">
                        <g stroke="#edf0f4">
                            @foreach([30, 75, 120, 165, 210] as $y)
                                <path d="M35 {{ $y }}H610" />
                            @endforeach
                        </g>
                        <g fill="#a0a9b5" font-size="10">
                            @foreach([80, 60, 40, 20, 0] as $i => $v)
                                <text x="4" y="{{ 34 + $i * 45 }}">{{ $v }}</text>
                            @endforeach
                        </g>
                        @php
                            $bars = [58, 72, 48, 85, 64, 91, 76, 67, 84, 61, 79, 68];
                        @endphp
                        @foreach($bars as $i => $v)
                            <rect x="{{ 49 + $i * 47 }}" y="{{ 210 - $v * 1.8 }}" width="22" height="{{ $v * 1.8 }}" rx="4"
                                  fill="{{ $i === 5 ? '#ff6b00' : '#ffdcc0' }}" />
                        @endforeach
                        <polyline points="60,124 107,101 154,128 201,81 248,108 295,55 342,64 389,85 436,65 483,96 530,68 577,76"
                                  fill="none" stroke="#687f83" stroke-width="2.5" stroke-linejoin="round" />
                        @foreach(['01', '05', '10', '15', '20', '25', '30'] as $i => $day)
                            <text x="{{ 49 + $i * 88 }}" y="228" fill="#9ba5b3" font-size="10">{{ $day }} Oct</text>
                        @endforeach
                    </svg>

                    <div class="chart-summary">
                        <span><strong>1,324</strong> Incoming repairs</span>
                        <span><strong>1,248</strong> Completed repairs</span>
                        <span><strong>1.8 days</strong> Avg. turnaround</span>
                    </div>
                </section>

                <!-- Failure Donut Chart -->
                <section class="panel chart-panel">
                    <h2>Failure root causes</h2>
                    <p>Understand the issue. Improve the outcome.</p>

                    <div class="donut-wrap">
                        <div class="failure-donut">
                            <div>
                                <strong>1,248</strong>
                                <span>diagnosed repairs</span>
                            </div>
                        </div>
                    </div>

                    <div class="failure-legend">
                        @foreach([['Motherboard', '32%'], ['Screen / hinge', '28%'], ['Battery', '20%'], ['Liquid spill', '12%'], ['Fan / heatsink', '8%']] as $i => [$name, $val])
                            <div>
                                <i class="failure-color-{{ $i }}"></i>
                                <span>{{ $name }}</span>
                                <strong>{{ $val }}</strong>
                            </div>
                        @endforeach
                    </div>
                </section>
            </div>

            <div class="sla-alert">
                <div class="alert-clock"><x-icon name="tool" :size="20" /></div>
                <div>
                    <strong>Your next best move: balance the workload.</strong>
                    <span> One bench is at capacity, while Bench 03 has space to help.</span>
                </div>
                <a href="{{ route('home', ['role' => 'manager', 'page' => 'Technician dispatch']) }}" class="secondary" style="color:#ac802b; font-weight:650;">
                    Open dispatch board →
                </a>
            </div>

            <section class="queue-panel">
                <div class="queue-heading">
                    <div>
                        <h2>Recent SLA escalations <span>3</span></h2>
                        <p>A timely intervention makes all the difference.</p>
                    </div>
                    <a href="{{ route('home', ['role' => 'manager', 'page' => 'Technician dispatch']) }}" class="text-button">
                        View workload →
                    </a>
                </div>

                <div class="table-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>RMA TICKET</th>
                                <th>DEVICE</th>
                                <th>REPAIR TASK</th>
                                <th>ASSIGNED BENCH</th>
                                <th>TIME TO BREACH</th>
                                <th>QUICK REASSIGN</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($dispatchTickets->whereIn('id', ['9043', '9041', '9049']) as $t)
                                <tr>
                                    <td><strong class="ticket-number">#RMA-{{ $t->id }}</strong></td>
                                    <td>{{ $t->model }}</td>
                                    <td>{{ $t->issue }}</td>
                                    <td>{{ $benches[$t->bench] }}</td>
                                    <td><span class="sla-badge warning">{{ $t->time_remaining }} remaining</span></td>
                                    <td>
                                        <form action="{{ route('dispatch.reassign') }}" method="POST">
                                            @csrf
                                            <input type="hidden" name="id" value="{{ $t->id }}">
                                            <select class="reassign-select" name="bench" onchange="this.form.submit()">
                                                @foreach($benches as $bIdx => $bName)
                                                    <option value="{{ $bIdx }}" {{ $t->bench === $bIdx ? 'selected' : '' }}>
                                                        {{ $bName }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
        @endif

        <footer class="page-footer">
            <span>OmniFix Care · Better service starts with a clearer view.</span>
            <span><i></i>Laravel Live Session · SQLite Persisted</span>
        </footer>
    </div>

    <!-- Loaner Request Drawer Modal -->
    <div id="loanerDrawerOverlay" class="drawer-overlay" style="display:none;" onclick="closeLoanerDrawer()">
        <aside class="loaner-drawer" onclick="event.stopPropagation()">
            <form action="{{ route('loaners.request') }}" method="POST">
                @csrf
                <div class="drawer-heading">
                    <span class="eyebrow">BUSINESS CONTINUITY, BUILT IN</span>
                    <button type="button" onclick="closeLoanerDrawer()">×</button>
                </div>
                <h2>Deploy a standby loaner.</h2>
                <p id="drawerTicketLabel">RMA-9041 · Standby device allocation</p>

                <div class="entitlement-note">
                    <strong>Your Gold SLA has you covered.</strong>
                    <p>1 business day loaner included at zero cost. {{ 5 - $loaners->count() }} of 5 entitled units available.</p>
                </div>

                <label class="field-label">
                    Affected ticket
                    <select name="ticket_id" id="drawerTicketSelect">
                        @foreach($fleetAssets as $fa)
                            <option value="{{ $fa->id }}">RMA-{{ $fa->id }} · {{ $fa->employee }} ({{ $fa->model }})</option>
                        @endforeach
                    </select>
                </label>

                <label class="field-label">
                    Hardware & operating system profile
                    <select name="profile">
                        <option>Standard Office · 16GB / Windows 11</option>
                        <option>Developer · 32GB / Ubuntu</option>
                        <option>Executive · Ultraportable / Windows 11</option>
                    </select>
                </label>

                <label class="field-label">
                    Dispatch priority
                    <select name="urgency">
                        <option>Standard · 24h</option>
                        <option>Emergency · 4h onsite dispatch</option>
                    </select>
                </label>

                <label class="field-label">
                    Delivery destination
                    <select name="address">
                        <option>Headquarters reception</option>
                        <option>Employee registered home address</option>
                    </select>
                </label>

                <div class="quote-note">
                    Windows loaners include your standard corporate image and VPN. Ubuntu loaners include the approved developer image.
                </div>

                <label class="check-label">
                    <input type="checkbox" id="loanerAgreeCheckbox" required onchange="document.getElementById('confirmLoanerBtn').disabled = !this.checked">
                    I acknowledge the loaner terms and will return the device within 3 days of repair completion.
                </label>

                <div class="drawer-footer">
                    <button type="submit" id="confirmLoanerBtn" class="primary" disabled>
                        Confirm & dispatch loaner →
                    </button>
                    <button type="button" class="secondary" onclick="closeLoanerDrawer()">Cancel</button>
                </div>
            </form>
        </aside>
    </div>

    <!-- Bulk Claim Modal -->
    <div id="bulkModalOverlay" class="drawer-overlay" style="display:none;" onclick="closeBulkModal()">
        <section class="bulk-modal" onclick="event.stopPropagation()">
            <form onsubmit="event.preventDefault(); closeBulkModal(); showToast('Bulk service request recorded. Your fleet service coordinator will review the asset list.');">
                <h2>Bulk claim & service</h2>
                <p>Submit multiple asset IDs for a coordinated service intake.</p>
                <label class="field-label">
                    Asset IDs (one per line)
                    <textarea required placeholder="ACME-NB-042&#10;ACME-NB-108"></textarea>
                </label>
                <label class="field-label">
                    Shared issue or service notes
                    <textarea required placeholder="Describe the repairs or service needed…"></textarea>
                </label>
                <div class="quote-actions">
                    <button type="submit" class="primary">Submit service request</button>
                    <button type="button" class="secondary" onclick="closeBulkModal()">Cancel</button>
                </div>
            </form>
        </section>
    </div>

@else
    {{-- BENCH TECHNICIAN WORKSPACE (DEFAULT) --}}
    <div class="page-heading">
        <div>
            <div class="greeting">LET’S MAKE EVERY REPAIR COUNT</div>
            <h1>
                {{ $page === 'SLA monitor' ? 'SLA monitor' : ($page === 'RMA queue' ? 'RMA queue' : 'Good morning, Alex') }}<span class="greeting-dot">.</span>
            </h1>
            <p>{{ $page === 'SLA monitor' ? 'Stay one step ahead of your service commitments.' : 'Here’s what’s happening at your bench today.' }}</p>
        </div>
        <a href="{{ route('home', ['role' => 'customer', 'page' => 'Warranty & repair']) }}" class="primary">
            <x-icon name="plus" :size="18" /> Create repair ticket
        </a>
    </div>

    <!-- Metrics Grid -->
    <div class="metrics-grid">
        <section class="metric-card metric-0">
            <div class="metric-top"><span>Active jobs</span><span class="metric-icon icon-0"><x-icon name="laptop" :size="19" /></span></div>
            <div class="metric-number">14</div>
            <div class="metric-foot neutral"><x-icon name="arrow" :size="13" /> +2 from yesterday</div>
            <small>Across your service center</small>
        </section>

        <section class="metric-card metric-1">
            <div class="metric-top"><span>Approaching SLA</span><span class="metric-icon icon-1"><x-icon name="clock" :size="19" /></span></div>
            <div class="metric-number">3</div>
            <div class="metric-foot warning"><x-icon name="clock" :size="13" /> Needs your attention</div>
            <small>Due within the next 4 hours</small>
        </section>

        <section class="metric-card metric-2">
            <div class="metric-top"><span>Completed today</span><span class="metric-icon icon-2"><x-icon name="check" :size="19" /></span></div>
            <div class="metric-number">8</div>
            <div class="metric-foot success"><x-icon name="arrow" :size="13" /> +3 from yesterday</div>
            <small>Another 8 devices, back to life</small>
        </section>

        <section class="metric-card metric-3">
            <div class="metric-top"><span>Avg. turnaround</span><span class="metric-icon icon-3"><x-icon name="trend" :size="19" /></span></div>
            <div class="metric-number">2.1 <span>days</span></div>
            <div class="metric-foot success"><x-icon name="trend" :size="13" /> 12% faster this week</div>
            <small>Keeping downtime to a minimum</small>
        </section>
    </div>

    <!-- Priority SLA Alert Box -->
    <div class="sla-alert">
        <div class="alert-clock"><x-icon name="clock" :size="21" /></div>
        <div>
            <strong>A little priority goes a long way.</strong>
            <span> 3 tickets are approaching their SLA. Let’s get them moving.</span>
        </div>
        <a href="{{ route('home', ['role' => 'technician', 'sla' => 'Approaching SLA']) }}" class="secondary" style="color:#ac802b; font-weight:650; margin-left:auto;">
            View priority jobs <x-icon name="arrow" :size="17" />
        </a>
    </div>

    <!-- Repair Queue Panel -->
    <section class="queue-panel">
        <div class="queue-heading">
            <div>
                <h2>Your repair queue <span>{{ $filteredJobs->count() + 8 }}</span></h2>
                <p>Every ticket is a device someone is counting on.</p>
            </div>
            <a href="{{ route('home', ['role' => 'technician', 'page' => 'RMA queue']) }}" class="text-button">
                View all tickets <x-icon name="arrow" :size="16" />
            </a>
        </div>

        <!-- Queue Tabs -->
        <div class="queue-tabs">
            @php
                $tabCounts = [
                    'All jobs' => 14,
                    'My jobs' => 5,
                    'Awaiting parts' => 3,
                    'Quality check' => 2,
                ];
            @endphp
            @foreach(['All jobs', 'My jobs', 'Awaiting parts', 'Quality check'] as $t)
                <a href="{{ route('home', ['role' => 'technician', 'page' => $page, 'tab' => $t, 'brand' => $brand, 'sla' => $sla, 'bench' => $bench]) }}"
                   class="tab-btn {{ $tab === $t ? 'selected' : '' }}">
                    {{ $t }} <span>{{ $tabCounts[$t] }}</span>
                </a>
            @endforeach
        </div>

        <!-- Filter Bar -->
        <div class="filter-bar">
            <div class="search-field">
                <x-icon name="search" :size="18" />
                <input type="text" id="queueSearch" placeholder="Search ticket, serial or device…" value="{{ $search }}"
                       onkeyup="filterTable(this.value, 'queueTable')">
                <kbd>⌘ K</kbd>
            </div>

            <form action="{{ route('home') }}" method="GET" class="filter-selects">
                <input type="hidden" name="role" value="technician">
                <input type="hidden" name="page" value="{{ $page }}">
                <input type="hidden" name="tab" value="{{ $tab }}">

                <select name="brand" aria-label="Filter by brand" onchange="this.form.submit()">
                    @foreach(['All brands', 'Lenovo', 'Apple', 'Dell', 'ASUS', 'HP'] as $b)
                        <option value="{{ $b }}" {{ $brand === $b ? 'selected' : '' }}>{{ $b }}</option>
                    @endforeach
                </select>

                <select name="sla" aria-label="Filter by SLA" onchange="this.form.submit()">
                    @foreach(['All SLA statuses', 'Approaching SLA', 'On track'] as $s)
                        <option value="{{ $s }}" {{ $sla === $s ? 'selected' : '' }}>{{ $s }}</option>
                    @endforeach
                </select>

                <select name="bench" aria-label="Filter by technician" onchange="this.form.submit()">
                    @foreach(['All technicians', 'Alex Morgan', 'Sarah Chen', 'James Wilson'] as $t)
                        <option value="{{ $t }}" {{ $bench === $t ? 'selected' : '' }}>{{ $t }}</option>
                    @endforeach
                </select>

                <a href="{{ route('home', ['role' => 'technician', 'page' => $page]) }}" class="filter-button" title="Reset filters">
                    <x-icon name="filter" :size="18" />
                </a>
            </form>
        </div>

        <!-- Table -->
        <div class="table-scroll">
            <table id="queueTable">
                <thead>
                    <tr>
                        <th class="checkbox-cell">
                            <input type="checkbox" aria-label="Select all tickets" onchange="showToast(this.checked ? 'All visible tickets selected.' : 'Selection cleared.')">
                        </th>
                        <th>RMA TICKET</th>
                        <th>DEVICE / SERIAL NUMBER</th>
                        <th>REPORTED ISSUE</th>
                        <th>ASSIGNED TECH</th>
                        <th>SLA COUNTDOWN <x-icon name="down" :size="12" /></th>
                        <th>STATUS</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($filteredJobs as $job)
                        <tr onclick="window.location.href = '{{ route('home', ['role' => 'technician', 'selected' => $job->id]) }}'">
                            <td class="checkbox-cell" onclick="event.stopPropagation()">
                                <input type="checkbox" aria-label="Select ticket {{ $job->id }}">
                            </td>
                            <td>
                                <strong class="ticket-number">#{{ $job->id }}</strong>
                                <span class="priority {{ $job->priority === 'High' ? 'high' : '' }}">
                                    <i></i>{{ $job->priority === 'High' ? 'P1 High' : 'P2 Normal' }}
                                </span>
                            </td>
                            <td>
                                <div class="device-cell">
                                    <div class="device-logo brand-{{ strtolower($job->brand) }}">
                                        @if($job->brand === 'Apple')
                                            <x-icon name="laptop" :size="22" />
                                        @elseif($job->brand === 'Lenovo')
                                            L
                                        @elseif($job->brand === 'Dell')
                                            DELL
                                        @elseif($job->brand === 'ASUS')
                                            ASUS
                                        @else
                                            hp
                                        @endif
                                    </div>
                                    <div>
                                        <strong>{{ $job->model }}</strong>
                                        <small>{{ $job->serial }} <span>· {{ $job->gen }}</span></small>
                                    </div>
                                </div>
                            </td>
                            <td class="issue-cell">{{ $job->issue }}</td>
                            <td>
                                <div class="tech-cell">
                                    <span class="avatar avatar-{{ $job->tech_initials }}">{{ $job->tech_initials }}</span>
                                    <span>{{ $job->tech_name }}</span>
                                </div>
                            </td>
                            <td>
                                <span class="sla-badge {{ $job->priority === 'High' ? 'warning' : '' }}">
                                    <x-icon name="clock" :size="13" />
                                    {{ $job->time_remaining }}<span>left</span>
                                </span>
                            </td>
                            <td>
                                <span class="badge {{ $job->tone }}">
                                    <i></i>{{ $job->status }}
                                </span>
                            </td>
                            <td><x-icon name="chevron" :size="16" /></td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8">
                                <div class="empty-state">
                                    <x-icon name="search" :size="30" />
                                    <h3>No matching repairs</h3>
                                    <p>Try another search or reset your filters.</p>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="table-footer">
            <span>Showing <strong>1–{{ $filteredJobs->count() }}</strong> of <strong>{{ $filteredJobs->count() + 8 }}</strong> tickets</span>
            <div>
                <button disabled>Previous</button>
                <button class="current-page">1</button>
                <button type="button" onclick="showToast('You’re viewing all demo tickets.')">2</button>
                <button type="button" onclick="showToast('You’re viewing all demo tickets.')">3</button>
                <button type="button" onclick="showToast('You’re viewing all demo tickets.')">Next <x-icon name="chevron" :size="13" /></button>
            </div>
        </div>
    </section>

    <!-- Bottom Promos & Team Presence -->
    <div class="bottom-grid">
        <section class="daily-note">
            <div class="note-icon"><x-icon name="shield" :size="25" /></div>
            <div>
                <span class="eyebrow">THE OMNIFIX PROMISE</span>
                <h3>Expert hands. Genuine care.</h3>
                <p>Every repair is a chance to earn someone’s trust. Thanks for making it count.</p>
            </div>
            <div class="note-decoration"><x-icon name="tool" :size="69" /></div>
        </section>

        <section class="team-card">
            <div>
                <h3>Your team, on the bench</h3>
                <p>Good work happens together.</p>
            </div>
            <div class="team-avatars">
                <span class="avatar avatar-AM">AM</span>
                <span class="avatar avatar-SC">SC</span>
                <span class="avatar avatar-JW">JW</span>
                <span class="avatar extra-avatar">+2</span>
            </div>
            <span class="team-online"><i></i>5 online</span>
        </section>
    </div>

    <footer class="page-footer">
        <span>OmniFix Care · Built around better service.</span>
        <span><i></i>All systems operational <span class="footer-separator">|</span> Laravel Powered</span>
    </footer>
@endif
@endsection

@push('scripts')
<script>
    // Live table filtering
    function filterTable(query, tableId) {
        const table = document.getElementById(tableId);
        if (!table) return;
        const rows = table.querySelectorAll('tbody tr');
        const q = query.toLowerCase().trim();
        rows.forEach(r => {
            const text = r.innerText.toLowerCase();
            r.style.display = text.includes(q) ? '' : 'none';
        });
    }

    // Warranty serial verification via AJAX
    function verifySerial() {
        const serial = document.getElementById('serialInput').value.trim();
        if (serial.length < 8) {
            showToast('Please enter a serial number with at least 8 characters.');
            return;
        }

        fetch('{{ route('customer.check-warranty') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ serial: serial })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                document.getElementById('resModel').innerText = data.model;
                document.getElementById('resSerial').innerText = 'Serial: ' + data.serial;
                document.getElementById('resBadge').innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8 12 3 3 5-6"/></svg> ' + data.warranty;
                document.getElementById('warrantyResultCard').style.display = 'flex';
                document.getElementById('formSerial').value = data.serial;
                showToast('Warranty validated for ' + data.model);
            }
        })
        .catch(() => {
            showToast('Warranty check completed for demo device.');
        });
    }

    // Symptom selector toggle
    function toggleSymptom(btn, symptom) {
        btn.classList.toggle('chosen');
        const container = document.getElementById('symptomInputs');
        const existing = document.getElementById('sym_' + symptom.replace(/[^a-zA-Z0-9]/g, '_'));
        if (btn.classList.contains('chosen')) {
            if (!existing) {
                const inp = document.createElement('input');
                inp.type = 'hidden';
                inp.name = 'symptoms[]';
                inp.value = symptom;
                inp.id = 'sym_' + symptom.replace(/[^a-zA-Z0-9]/g, '_');
                container.appendChild(inp);
            }
        } else {
            if (existing) existing.remove();
        }
    }

    // Delivery selection
    function selectDelivery(btn, val) {
        document.querySelectorAll('.service-options button').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        document.getElementById('deliveryMethod').value = val;
    }

    // Loaner Drawer modal controls
    function openLoanerDrawer(ticketId) {
        const overlay = document.getElementById('loanerDrawerOverlay');
        const label = document.getElementById('drawerTicketLabel');
        const sel = document.getElementById('drawerTicketSelect');
        if (label) label.innerText = `RMA-${ticketId} · Standby device allocation`;
        if (sel) sel.value = ticketId;
        if (overlay) overlay.style.display = 'flex';
    }

    function closeLoanerDrawer() {
        const overlay = document.getElementById('loanerDrawerOverlay');
        if (overlay) overlay.style.display = 'none';
    }

    // Bulk modal controls
    function openBulkModal() {
        const m = document.getElementById('bulkModalOverlay');
        if (m) m.style.display = 'flex';
    }

    function closeBulkModal() {
        const m = document.getElementById('bulkModalOverlay');
        if (m) m.style.display = 'none';
    }

    // --- STAFF DIRECTORY CONTROLS ---
    let currentStaffRoleFilter = 'All';

    function filterStaffRole(btn, role) {
        document.querySelectorAll('.account-settings .queue-tabs button').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        currentStaffRoleFilter = role;
        filterStaffTable();
    }

    function filterStaffTable() {
        const query = (document.getElementById('staffSearchInput')?.value || '').toLowerCase().trim();
        const status = document.getElementById('staffStatusSelect')?.value || 'All';
        const rows = document.querySelectorAll('#staffTable tbody tr');

        rows.forEach(r => {
            const role = r.getAttribute('data-role');
            const rowStatus = r.getAttribute('data-status');
            const searchData = r.getAttribute('data-search') || '';

            const matchRole = currentStaffRoleFilter === 'All' || role === currentStaffRoleFilter;
            const matchStatus = status === 'All' || rowStatus === status;
            const matchQuery = !query || searchData.includes(query);

            r.style.display = (matchRole && matchStatus && matchQuery) ? '' : 'none';
        });
    }

    function openStaffModal(staff = null) {
        const overlay = document.getElementById('staffModalOverlay');
        const title = document.getElementById('staffModalTitle');
        const idInp = document.getElementById('staffEditId');
        const nameInp = document.getElementById('staffEditName');
        const emailInp = document.getElementById('staffEditEmail');
        const roleSel = document.getElementById('staffEditRole');
        const benchInp = document.getElementById('staffEditBench');

        if (staff) {
            title.innerText = 'Edit role & permissions';
            idInp.value = staff.id;
            nameInp.value = staff.name;
            emailInp.value = staff.email;
            roleSel.value = staff.role;
            benchInp.value = staff.bench;

            const perms = Array.isArray(staff.permissions) ? staff.permissions : [false, false, false, false, false];
            for (let i = 0; i < 5; i++) {
                setPermissionState(i, !!perms[i]);
            }
        } else {
            title.innerText = 'Invite your next expert.';
            idInp.value = '';
            nameInp.value = '';
            emailInp.value = '';
            roleSel.value = 'Service Desk';
            benchInp.value = 'Front intake counter';
            for (let i = 0; i < 5; i++) {
                setPermissionState(i, false);
            }
        }

        if (overlay) overlay.style.display = 'flex';
    }

    function closeStaffModal() {
        const overlay = document.getElementById('staffModalOverlay');
        if (overlay) overlay.style.display = 'none';
    }

    function setPermissionState(idx, enabled) {
        const inp = document.getElementById(`perm_inp_${idx}`);
        const btn = document.getElementById(`perm_btn_${idx}`);
        if (inp) inp.value = enabled ? '1' : '0';
        if (btn) {
            btn.setAttribute('aria-checked', enabled ? 'true' : 'false');
            if (enabled) {
                btn.classList.add('enabled');
            } else {
                btn.classList.remove('enabled');
            }
        }
    }

    function togglePermissionSwitch(idx) {
        const inp = document.getElementById(`perm_inp_${idx}`);
        const current = inp ? inp.value === '1' : false;
        setPermissionState(idx, !current);
    }

    function toggleStaffMenu(id) {
        const menu = document.getElementById(`staffMenu_${id}`);
        if (!menu) return;
        const isShown = menu.style.display === 'flex' || menu.style.display === 'block';
        document.querySelectorAll('.staff-menu').forEach(m => m.style.display = 'none');
        menu.style.display = isShown ? 'none' : 'block';
    }

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.staff-actions')) {
            document.querySelectorAll('.staff-menu').forEach(m => m.style.display = 'none');
        }
    });

    // --- PROFILE & SECURITY CONTROLS ---
    function switchProfileTab(tab) {
        ['profile', 'security', 'sessions'].forEach(t => {
            const sec = document.getElementById(`profSection_${t}`);
            const btn = document.getElementById(`profTabBtn_${t}`);
            if (sec) sec.style.display = (t === tab) ? 'block' : 'none';
            if (btn) {
                if (t === tab) btn.classList.add('active');
                else btn.classList.remove('active');
            }
        });
    }

    function previewAvatar(input) {
        if (input.files && input.files[0]) {
            const file = input.files[0];
            if (file.size > 5 * 1024 * 1024) {
                showToast('Please select an image smaller than 5 MB.');
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                const box = document.getElementById('avatarPreviewBox');
                if (box) {
                    box.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
                }
                showToast('Profile photo updated.');
            };
            reader.readAsDataURL(file);
        }
    }

    function checkSettingsPasswordRules(pwd) {
        const hasLen = pwd.length >= 8;
        const hasUpper = /[A-Z]/.test(pwd);
        const hasNum = /[0-9]/.test(pwd);
        const hasSpec = /[^A-Za-z0-9]/.test(pwd);

        const updateElem = (id, met, txt) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.className = met ? 'rule-met' : '';
            el.innerText = (met ? '✓ ' : '○ ') + txt;
        };

        updateElem('sec-rule-len', hasLen, 'At least 8 characters');
        updateElem('sec-rule-upper', hasUpper, 'One uppercase letter');
        updateElem('sec-rule-num', hasNum, 'One number');
        updateElem('sec-rule-spec', hasSpec, 'One special character');
    }

    let isTwoFaEnabled = true;

    function toggleTwoFaStatus() {
        const btn = document.getElementById('twoFaToggleBtn');
        const badge = document.getElementById('twoFaBadge');
        const text = document.getElementById('twoFaStatusText');

        if (isTwoFaEnabled) {
            isTwoFaEnabled = false;
            btn.classList.remove('enabled');
            badge.className = 'badge orange';
            badge.innerText = 'Disabled';
            text.innerText = 'Set up an authenticator to protect your account.';
            showToast('2FA disabled in demo state.');
        } else {
            openTotpModal();
        }
    }

    function openTotpModal() {
        const overlay = document.getElementById('totpModalOverlay');
        const codeInp = document.getElementById('totpCodeInput');
        if (codeInp) codeInp.value = '';
        if (overlay) overlay.style.display = 'flex';
    }

    function closeTotpModal() {
        const overlay = document.getElementById('totpModalOverlay');
        if (overlay) overlay.style.display = 'none';
    }

    function handleTotpVerify() {
        const code = document.getElementById('totpCodeInput')?.value.trim();
        if (code !== '123456') {
            showToast('Use demo verification code 123456.');
            return;
        }
        isTwoFaEnabled = true;
        const btn = document.getElementById('twoFaToggleBtn');
        const badge = document.getElementById('twoFaBadge');
        const text = document.getElementById('twoFaStatusText');
        if (btn) btn.classList.add('enabled');
        if (badge) {
            badge.className = 'badge green';
            badge.innerText = '✓ Enabled';
        }
        if (text) text.innerText = 'Demo account protected by Google Authenticator.';
        closeTotpModal();
        showToast('Authenticator enabled in demo state.');
    }

    function revokeSingleSession(id) {
        const row = document.getElementById(id);
        if (row) row.remove();
        showToast('Demo session revoked.');
    }

    function revokeOtherSessions() {
        const s2 = document.getElementById('session_2');
        const s3 = document.getElementById('session_3');
        if (s2) s2.remove();
        if (s3) s3.remove();
        showToast('Other demo sessions revoked.');
    }
</script>
@endpush
