<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'OmniFix Care' }} — Authorized Service Center</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;450;500;550;600;650;700;750;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/advanced.css') }}">
    <link rel="stylesheet" href="{{ asset('css/index.css') }}">
    <style>
        /* Smooth transitions & additional ergonomics */
        .toast-enter { transform: translate(-50%, 20px); opacity: 0; }
        .toast-visible { transform: translate(-50%, 0); opacity: 1; transition: all 0.25s ease-out; }
        .tab-btn { background: none; border: none; cursor: pointer; }

        /* Navigation Workspace arrangement matching screenshot */
        .sidebar {
            width: 242px;
            background: #ffffff;
            border-right: 1px solid #e9ecf1;
            box-sizing: border-box;
        }

        .nav-label {
            font-size: 11px !important;
            letter-spacing: 1.3px !important;
            color: #929ba8 !important;
            padding: 0 14px !important;
            margin: 32px 0 16px !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            display: block !important;
            line-height: 1 !important;
        }

        .sidebar nav {
            display: flex !important;
            flex-direction: column !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        a.nav-item, button.nav-item, .nav-item {
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            width: 100% !important;
            padding: 12px 14px !important;
            gap: 13px !important;
            color: #697484 !important;
            font-size: 13.5px !important;
            font-weight: 500 !important;
            border-radius: 9px !important;
            margin-bottom: 6px !important;
            min-height: 44px !important;
            text-decoration: none !important;
            box-sizing: border-box !important;
            background: transparent !important;
            border: none !important;
            cursor: pointer !important;
            transition: background 0.18s ease, color 0.18s ease !important;
            font-family: inherit !important;
            outline: none !important;
        }

        a.nav-item svg, button.nav-item svg, .nav-item svg {
            flex-shrink: 0 !important;
            width: 20px !important;
            height: 20px !important;
            color: #7b8595 !important;
            transition: color 0.18s ease !important;
            display: block !important;
        }

        a.nav-item span, button.nav-item span, .nav-item span {
            color: inherit !important;
            font-size: 13.5px !important;
            font-weight: inherit !important;
            text-decoration: none !important;
            line-height: 1.2 !important;
            white-space: nowrap !important;
        }

        /* Active State */
        a.nav-item.active, button.nav-item.active, .nav-item.active {
            color: #f26500 !important;
            background: #fff1e7 !important;
            font-weight: 650 !important;
        }

        a.nav-item.active svg, button.nav-item.active svg, .nav-item.active svg {
            color: #f26500 !important;
        }

        a.nav-item.active span, button.nav-item.active span, .nav-item.active span {
            color: #f26500 !important;
            font-weight: 650 !important;
        }

        /* Hover State */
        a.nav-item:hover, button.nav-item:hover, .nav-item:hover {
            background: #fff5ed !important;
            color: #f26500 !important;
        }

        a.nav-item:hover svg, button.nav-item:hover svg, .nav-item:hover svg {
            color: #f26500 !important;
        }

        a.nav-item:hover span, button.nav-item:hover span, .nav-item:hover span {
            color: #f26500 !important;
        }

        /* Spacing above Settings */
        .nav-spacer {
            height: 28px !important;
            width: 100% !important;
            display: block !important;
        }

        .nav-divider {
            display: none !important;
        }

        .signout-nav {
            color: #8f98a6 !important;
        }
        .signout-nav:hover {
            color: #d9534f !important;
            background: #fff0f0 !important;
        }
        .signout-nav:hover svg {
            color: #d9534f !important;
        }
    </style>
</head>
<body>
    <div class="app-shell">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-mark"><x-icon name="tool" :size="23" /></div>
                <span>OmniFix<span class="logo-care"> Care</span><small>AUTHORIZED SERVICE CENTER</small></span>
            </div>

            <div class="nav-label">{{ $role === 'customer' ? 'CUSTOMER PORTAL' : 'WORKSPACE' }}</div>
            <nav>
                @php
                    $navItems = match($role) {
                        'manager' => [
                            ['Operations overview', 'grid'],
                            ['Technician dispatch', 'tool'],
                            ['Stock oversight', 'box'],
                        ],
                        'corporate' => [
                            ['Fleet overview', 'grid'],
                            ['Active repairs', 'tool'],
                            ['Loaner units', 'laptop'],
                            ['SLA reports', 'clock'],
                        ],
                        'customer' => [
                            ['Warranty & repair', 'shield'],
                            ['Track my repair', 'clock'],
                        ],
                        default => [
                            ['My workbench', 'grid'],
                            ['RMA queue', 'laptop'],
                            ['Parts inventory', 'box'],
                            ['SLA monitor', 'clock'],
                        ],
                    };
                @endphp

                @foreach($navItems as [$navName, $navIcon])
                    <a href="{{ route('home', ['role' => $role, 'page' => $navName]) }}"
                       class="nav-item {{ $page === $navName && empty($selectedJob) ? 'active' : '' }}">
                        <x-icon :name="$navIcon" :size="20" />
                        <span>{{ $navName }}</span>
                        @if($navName === 'RMA queue')
                            <em>24</em>
                        @elseif($navName === 'SLA monitor')
                            <i title="Requires attention"></i>
                        @endif
                    </a>
                @endforeach
            </nav>

            <div class="nav-spacer"></div>

            @if($role === 'manager')
                <a href="{{ route('home', ['role' => $role, 'page' => 'Staff & permissions']) }}"
                   class="nav-item {{ $page === 'Staff & permissions' ? 'active' : '' }}">
                    <x-icon name="shield" :size="20" />
                    <span>Staff & permissions</span>
                </a>
            @endif

            <a href="{{ route('home', ['role' => $role, 'page' => 'Settings']) }}"
               class="nav-item {{ $page === 'Settings' ? 'active' : '' }}">
                <x-icon name="settings" :size="20" />
                <span>Profile & security</span>
            </a>

            <a href="{{ route('logout') }}" class="nav-item signout-nav" title="Sign out to switch role">
                <x-icon name="logout" :size="18" />
                <span>Sign out</span>
            </a>

            <div class="sidebar-bottom">
                <div class="support-card">
                    <span class="support-icon"><x-icon name="help" /></span>
                    <strong>A little help goes a long way.</strong>
                    <p>Our support team has your back.</p>
                    <button type="button" onclick="showToast('Contact our service team at care@omnifix.com or +1 (800) 555-0142.')">
                        Visit help center <x-icon name="arrow" :size="16" />
                    </button>
                </div>

                <a href="{{ route('login', ['force' => 1]) }}" class="portal-switch">
                    <x-icon name="logout" :size="18" />
                    Switch demo role
                    <x-icon name="arrow" :size="16" />
                </a>

                <div class="sidebar-profile">
                    <span class="avatar profile-avatar">{{ $currentUser['avatar'] ?? 'AM' }}</span>
                    <div>
                        <strong>{{ $currentUser['name'] ?? 'Alex Morgan' }}</strong>
                        <small>{{ $currentUser['title'] ?? 'Senior technician' }}</small>
                    </div>
                    <a href="{{ route('home', ['role' => $role, 'page' => 'Settings']) }}" aria-label="Profile settings">
                        <x-icon name="down" :size="16" />
                    </a>
                </div>
            </div>
        </aside>

        <!-- Main Shell -->
        <div class="main-shell">
            <header class="topbar">
                <div class="breadcrumbs">
                    {{ $role === 'customer' ? 'Customer portal' : 'Workspace' }}
                    <x-icon name="chevron" :size="14" />
                    <strong>{{ !empty($selectedJob) ? 'Bench inspection' : $page }}</strong>
                </div>

                <div class="header-actions">
                    <span class="today">{{ now()->format('l, F j, Y') }}</span>
                    <span class="header-divider"></span>
                    <button type="button" id="benchStatusToggle" class="bench-toggle" onclick="toggleBenchStatus()">
                        <i></i>
                        <span id="benchStatusText">On bench</span>
                        <x-icon name="down" :size="13" />
                    </button>
                    <button type="button" class="notification" aria-label="Notifications" onclick="showToast('3 tickets are approaching SLA. Review the priority queue to keep repairs on track.')">
                        <x-icon name="bell" />
                        <i></i>
                    </button>
                    <span class="avatar small-avatar">{{ $currentUser['avatar'] ?? 'AM' }}</span>
                </div>
            </header>

            <main>
                @yield('content')
            </main>
        </div>

        <!-- Global Toast Notification -->
        <div id="toastContainer" class="toast" role="status" style="display: none;">
            <x-icon name="check" :size="19" />
            <span id="toastMessage"></span>
            <button type="button" aria-label="Dismiss notification" onclick="hideToast()">×</button>
        </div>
    </div>

    <script>
        function showToast(message) {
            const container = document.getElementById('toastContainer');
            const msgSpan = document.getElementById('toastMessage');
            if (!container || !msgSpan) return;
            msgSpan.innerText = message;
            container.style.display = 'flex';
            container.classList.add('toast-visible');

            if (window.toastTimer) clearTimeout(window.toastTimer);
            window.toastTimer = setTimeout(() => {
                hideToast();
            }, 4500);
        }

        function hideToast() {
            const container = document.getElementById('toastContainer');
            if (container) {
                container.style.display = 'none';
                container.classList.remove('toast-visible');
            }
        }

        function switchRole(role) {
            const defaultPages = {
                'manager': 'Operations overview',
                'corporate': 'Fleet overview',
                'customer': 'Warranty & repair',
                'technician': 'My workbench'
            };
            const page = defaultPages[role] || 'My workbench';
            window.location.href = `{{ route('home') }}?role=${role}&page=${encodeURIComponent(page)}`;
        }

        function toggleBenchStatus() {
            const btn = document.getElementById('benchStatusToggle');
            const txt = document.getElementById('benchStatusText');
            if (btn.classList.contains('off')) {
                btn.classList.remove('off');
                txt.innerText = 'On bench';
                showToast('Status updated: Technician is On Bench');
            } else {
                btn.classList.add('off');
                txt.innerText = 'Away';
                showToast('Status updated: Technician is Away');
            }
        }

        @if(session('success'))
            document.addEventListener('DOMContentLoaded', () => {
                showToast(@json(session('success')));
            });
        @endif

        @if(session('error'))
            document.addEventListener('DOMContentLoaded', () => {
                showToast(@json(session('error')));
            });
        @endif
    </script>
    @stack('scripts')
</body>
</html>
