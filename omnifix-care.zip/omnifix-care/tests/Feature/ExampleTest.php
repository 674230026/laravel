<?php

namespace Tests\Feature;

use App\Models\RmaJob;
use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DatabaseSeeder::class);
    }

    public function test_manager_operations_overview(): void
    {
        $response = $this->get('/?role=manager&page=Operations%20overview');
        $response->assertStatus(200);
        $response->assertSee('OmniFix');
        $response->assertSee('Service excellence, at a glance');
        $response->assertSee('Repair volume');
    }

    public function test_technician_workbench(): void
    {
        $response = $this->get('/?role=technician&page=My%20workbench');
        $response->assertStatus(200);
        $response->assertSee('Good morning, Alex');
        $response->assertSee('Your repair queue');
    }

    public function test_bench_inspection_view(): void
    {
        $response = $this->get('/?role=technician&selected=84920');
        $response->assertStatus(200);
        $response->assertSee('RMA-84920');
        $response->assertSee('ThinkPad X1 Carbon');
        $response->assertSee('Intake condition checklist');
    }

    public function test_corporate_fleet_overview(): void
    {
        $response = $this->get('/?role=corporate&page=Fleet%20overview');
        $response->assertStatus(200);
        $response->assertSee('Total active units');
        $response->assertSee('Gold SLA protected');
    }

    public function test_customer_portal_warranty(): void
    {
        $response = $this->get('/?role=customer&page=Warranty%20&%20repair');
        $response->assertStatus(200);
        $response->assertSee('Start with your serial number');
    }

    public function test_customer_portal_tracking(): void
    {
        $response = $this->get('/?role=customer&page=Track%20my%20repair');
        $response->assertStatus(200);
        $response->assertSee('YOUR REPAIR TICKET');
        $response->assertSee('Total estimate');
    }

    public function test_csv_report_export(): void
    {
        $response = $this->get('/reports/export?role=manager');
        $response->assertStatus(200);
        $response->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }

    public function test_login_page_renders(): void
    {
        $response = $this->get('/login');
        $response->assertStatus(200);
        $response->assertSee('One portal.');
        $response->assertSee('Complete care.');
        $response->assertSee('Welcome to OmniFix Care');
        $response->assertSee('Sign in');
        $response->assertSee('Create account (Register)');
        $response->assertDontSee('Demo Quick Access — Select Role to Enter');
    }

    public function test_credentials_login(): void
    {
        $response = $this->post('/login', [
            'email' => 'sarah.m@omnifix.com',
            'password' => 'password123',
        ]);
        $response->assertRedirect('/?role=manager');
        $response->assertSessionHas('signed_in', true);
        $response->assertSessionHas('role', 'manager');
    }

    public function test_staff_and_permissions_page(): void
    {
        $response = $this->get('/?role=manager&page=Staff%20%26%20permissions');
        $response->assertStatus(200);
        $response->assertSee('Great service starts with your people.');
        $response->assertSee('Team directory');
        $response->assertSee('Somchai Prasert');
        $response->assertSee('Alex Chen');
        $response->assertSee('Permission matrix');
    }

    public function test_profile_and_security_page(): void
    {
        $response = $this->get('/?role=manager&page=Settings');
        $response->assertStatus(200);
        $response->assertSee('Your profile. Your peace of mind.');
        $response->assertSee('Profile information');
        $response->assertSee('Two-factor authentication');
        $response->assertSee('Active sessions');
    }

    public function test_save_settings_profile_info(): void
    {
        $response = $this->withSession(['signed_in' => true, 'role' => 'manager'])
            ->post('/settings/save', [
                'first_name' => 'Sarah',
                'last_name' => 'Jenkins',
                'department' => 'Global Service Operations',
                'title' => 'Chief Service Officer',
            ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_save_settings_password_update(): void
    {
        $response = $this->withSession(['signed_in' => true, 'role' => 'manager'])
            ->post('/settings/save', [
                'current_password' => 'secret123',
                'new_password' => 'StrongPassword123!',
                'confirm_password' => 'StrongPassword123!',
            ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
        $response->assertSessionHas('active_profile_tab', 'security');
    }

    public function test_corporate_sla_reports_page(): void
    {
        $response = $this->get('/?role=corporate&page=SLA%20reports');
        $response->assertStatus(200);
        $response->assertSee('Corporate service performance');
        $response->assertSee('Department SLA performance');
        $response->assertSee('Recent SLA claims');
    }

    public function test_submit_customer_ticket_triggers_notifications(): void
    {
        $response = $this->post('/customer/submit-ticket', [
            'serial' => 'PF4X9K2L',
            'customer_name' => 'Theerapat Test',
            'customer_email' => 'watweera82@gmail.com',
            'customer_phone' => '+66 81 234 5678',
            'symptoms' => ['Thermal / Overheating'],
            'description' => 'Fan makes high noise.',
            'method' => 'Drop-off at service center',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_order_and_receive_part_triggers_notifications(): void
    {
        $orderResponse = $this->post('/inventory/DISP-LP-401/order');
        $orderResponse->assertRedirect();
        $orderResponse->assertSessionHas('success');

        $receiveResponse = $this->post('/inventory/DISP-LP-401/receive');
        $receiveResponse->assertRedirect();
        $receiveResponse->assertSessionHas('success');
    }

    public function test_mark_repaired_triggers_notification(): void
    {
        $response = $this->post('/jobs/84920/qc', [
            'notes' => 'OLED Display replaced and thermal paste reapplied.',
            'checklist' => ['thermal' => true, 'display' => true],
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_settings_send_test_email(): void
    {
        $response = $this->post('/settings/test-email', [
            'test_email' => 'watweera82@gmail.com',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_logout_redirects_to_login(): void
    {
        $response = $this->get('/logout');
        $response->assertRedirect('/login');
    }

    public function test_real_credential_login_success(): void
    {
        $response = $this->post('/login', [
            'email' => 'sarah.m@omnifix.com',
            'password' => 'password123',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('signed_in', true);
        $this->assertAuthenticated();
    }

    public function test_real_credential_login_failure(): void
    {
        $response = $this->post('/login', [
            'email' => 'sarah.m@omnifix.com',
            'password' => 'wrongpassword',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('error');
        $this->assertGuest();
    }

    public function test_user_registration(): void
    {
        $response = $this->post('/register', [
            'name' => 'Wichai Raksuk',
            'email' => 'wichai.r@example.com',
            'role' => 'customer',
            'password' => 'password123',
        ]);

        $response->assertRedirect('/?role=customer');
        $response->assertSessionHas('signed_in', true);
        $this->assertDatabaseHas('users', [
            'email' => 'wichai.r@example.com',
            'name' => 'Wichai Raksuk',
            'role' => 'customer',
        ]);
        $this->assertAuthenticated();
    }

    public function test_submit_customer_ticket_with_photos(): void
    {
        Storage::fake('public');

        $photo = UploadedFile::fake()->create('broken_screen.jpg', 120, 'image/jpeg');

        $response = $this->post('/customer/submit-ticket', [
            'serial' => 'PF4X9K2L',
            'customer_name' => 'Upload Tester',
            'customer_email' => 'watweera82@gmail.com',
            'customer_phone' => '+66 81 234 5678',
            'symptoms' => ['Display'],
            'description' => 'Flickering display lines.',
            'method' => 'Drop-off at service center',
            'photos' => [$photo],
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $job = RmaJob::where('customer_name', 'Upload Tester')->first();
        $this->assertNotNull($job);
        $this->assertNotNull($job->evidence_photos);
        $this->assertCount(1, $job->evidence_photos);
        $this->assertEquals('broken_screen.jpg', $job->evidence_photos[0]['name']);
    }

    public function test_mark_repaired_with_evidence_files(): void
    {
        Storage::fake('public');

        $photo = UploadedFile::fake()->create('repaired_screen.jpg', 120, 'image/jpeg');

        $response = $this->post('/jobs/84920/qc', [
            'notes' => 'Panel replaced cleanly.',
            'checklist' => ['Screen completed'],
            'evidence_files' => [
                'post_display' => $photo,
            ],
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $job = RmaJob::find('84920');
        $this->assertNotNull($job->evidence_photos);
        $this->assertEquals('repaired_screen.jpg', $job->evidence_photos[0]['name']);
    }

    public function test_save_settings_avatar_upload(): void
    {
        Storage::fake('public');

        $user = User::first();
        $this->actingAs($user);

        $avatar = UploadedFile::fake()->create('profile_pic.png', 80, 'image/png');

        $response = $this->post('/settings/save', [
            'first_name' => 'Sarah',
            'last_name' => 'Morgan',
            'avatar_file' => $avatar,
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_customer_can_view_profile_settings(): void
    {
        $response = $this->get('/?role=customer&page=Settings');
        $response->assertStatus(200);
        $response->assertSee('Your profile. Your peace of mind.');
        $response->assertSee('Profile information');
    }

    public function test_non_customer_registration_requires_admin_approval(): void
    {
        $response = $this->post('/register', [
            'name' => 'Kittisak Tech',
            'email' => 'kittisak.t@example.com',
            'role' => 'technician',
            'password' => 'password123',
        ]);

        $response->assertRedirect('/login');
        $response->assertSessionHas('pending_registration');
        $this->assertDatabaseHas('users', [
            'email' => 'kittisak.t@example.com',
            'role' => 'technician',
            'is_approved' => false,
        ]);
        $this->assertGuest();
    }

    public function test_admin_can_approve_pending_user(): void
    {
        $user = User::create([
            'name' => 'Somchai Tech',
            'email' => 'somchai.tech@example.com',
            'role' => 'technician',
            'password' => bcrypt('password123'),
            'is_approved' => false,
            'approval_token' => 'test-approval-token-12345',
        ]);

        $response = $this->get('/users/approve/test-approval-token-12345');
        $response->assertRedirect('/login');
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('users', [
            'id' => $user->id,
            'is_approved' => true,
            'approval_token' => null,
        ]);
    }
}
