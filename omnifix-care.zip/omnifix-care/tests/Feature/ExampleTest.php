<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Database\Seeders\DatabaseSeeder;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DatabaseSeeder::class);
    }

    public function test_manager_operations_overview(): void
    {
        $response = $this->get('/?role=manager&page=Operations%20overview');
        $response->assertStatus(200);
        $response->assertSee('OmniFix');
        $response->assertSee('Service excellence, at a glance');
        $response->assertSee('Repair volume');
    }

    public function test_technician_workbench(): void
    {
        $response = $this->get('/?role=technician&page=My%20workbench');
        $response->assertStatus(200);
        $response->assertSee('Good morning, Alex');
        $response->assertSee('Your repair queue');
    }

    public function test_bench_inspection_view(): void
    {
        $response = $this->get('/?role=technician&selected=84920');
        $response->assertStatus(200);
        $response->assertSee('RMA-84920');
        $response->assertSee('ThinkPad X1 Carbon');
        $response->assertSee('Intake condition checklist');
    }

    public function test_corporate_fleet_overview(): void
    {
        $response = $this->get('/?role=corporate&page=Fleet%20overview');
        $response->assertStatus(200);
        $response->assertSee('Total active units');
        $response->assertSee('Gold SLA protected');
    }

    public function test_customer_portal_warranty(): void
    {
        $response = $this->get('/?role=customer&page=Warranty%20&%20repair');
        $response->assertStatus(200);
        $response->assertSee('Start with your serial number');
    }

    public function test_customer_portal_tracking(): void
    {
        $response = $this->get('/?role=customer&page=Track%20my%20repair');
        $response->assertStatus(200);
        $response->assertSee('YOUR REPAIR TICKET');
        $response->assertSee('Total estimate');
    }

    public function test_csv_report_export(): void
    {
        $response = $this->get('/reports/export?role=manager');
        $response->assertStatus(200);
        $response->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }

    public function test_login_page_renders(): void
    {
        $response = $this->get('/login');
        $response->assertStatus(200);
        $response->assertSee('One portal.');
        $response->assertSee('Complete care.');
        $response->assertSee('Demo Quick Access');
        $response->assertSee('Center Manager');
        $response->assertSee('Corporate IT Manager');
        $response->assertSee('Bench Technician');
        $response->assertSee('General Customer');
    }

    public function test_demo_role_login(): void
    {
        $response = $this->post('/login', [
            'demo_role' => 'manager',
        ]);
        $response->assertRedirect('/?role=manager');
        $response->assertSessionHas('signed_in', true);
        $response->assertSessionHas('role', 'manager');
    }

    public function test_staff_and_permissions_page(): void
    {
        $response = $this->get('/?role=manager&page=Staff%20%26%20permissions');
        $response->assertStatus(200);
        $response->assertSee('Great service starts with your people.');
        $response->assertSee('Team directory');
        $response->assertSee('Somchai Prasert');
        $response->assertSee('Alex Chen');
        $response->assertSee('Permission matrix');
    }

    public function test_profile_and_security_page(): void
    {
        $response = $this->get('/?role=manager&page=Settings');
        $response->assertStatus(200);
        $response->assertSee('Your profile. Your peace of mind.');
        $response->assertSee('Profile information');
        $response->assertSee('Two-factor authentication');
        $response->assertSee('Active sessions');
    }

    public function test_logout_redirects_to_login(): void
    {
        $response = $this->get('/logout');
        $response->assertRedirect('/login');
    }
}
