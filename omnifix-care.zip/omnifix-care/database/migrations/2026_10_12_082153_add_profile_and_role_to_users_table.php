<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role')->default('customer')->after('email');
            $table->string('title')->nullable()->after('role');
            $table->string('department')->nullable()->after('title');
            $table->string('avatar')->nullable()->after('department');
            $table->string('phone')->nullable()->after('avatar');
            $table->string('staff_id')->nullable()->after('phone');
            $table->string('bench')->nullable()->after('staff_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['role', 'title', 'department', 'avatar', 'phone', 'staff_id', 'bench']);
        });
    }
};
