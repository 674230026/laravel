<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rma_jobs', function (Blueprint $table) {
            $table->json('evidence_photos')->nullable()->after('technician_notes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rma_jobs', function (Blueprint $table) {
            $table->dropColumn('evidence_photos');
        });
    }
};
