<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rma_jobs', function (Blueprint $table) {
            $table->string('customer_email')->nullable()->default('theerapat1682@gmail.com')->after('customer_name');
            $table->string('customer_phone')->nullable()->after('customer_email');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rma_jobs', function (Blueprint $table) {
            $table->dropColumn(['customer_email', 'customer_phone']);
        });
    }
};
