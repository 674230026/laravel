<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rma_jobs', function (Blueprint $table) {
            $table->string('id')->primary(); // e.g. '84920'
            $table->string('brand');
            $table->string('model');
            $table->string('gen')->nullable();
            $table->string('serial')->unique();
            $table->string('customer_name')->default('Jamie Anderson');
            $table->string('warranty_status')->default('Premier Onsite · Active');
            $table->text('issue');
            $table->string('tech_name')->default('Alex Morgan');
            $table->string('tech_initials')->default('AM');
            $table->string('time_remaining')->default('02h 15m');
            $table->string('status')->default('Diagnosing'); // Awaiting parts, In repair, Diagnosing, Quality check
            $table->string('priority')->default('Normal'); // High, Normal
            $table->string('tone')->default('blue'); // orange, purple, blue, green
            $table->string('processor')->nullable()->default('Intel Core i7-1365U');
            $table->string('memory')->nullable()->default('16 GB LPDDR5');
            $table->json('checklist')->nullable();
            $table->text('technician_notes')->nullable();
            $table->decimal('quote_amount', 8, 2)->default(60.00);
            $table->boolean('quote_approved')->default(false);
            $table->timestamps();
        });

        Schema::create('inventory_parts', function (Blueprint $table) {
            $table->string('sku')->primary();
            $table->string('name');
            $table->string('category');
            $table->string('compatible_models');
            $table->integer('stock')->default(0);
            $table->integer('reserved')->default(0);
            $table->integer('min_stock')->default(3);
            $table->boolean('on_order')->default(false);
            $table->decimal('unit_cost', 8, 2)->default(45.00);
            $table->timestamps();
        });

        Schema::create('fleet_assets', function (Blueprint $table) {
            $table->string('id')->primary(); // e.g. '9041'
            $table->string('asset_tag'); // e.g. 'ACME-NB-042'
            $table->string('employee');
            $table->string('department');
            $table->string('model');
            $table->string('serial');
            $table->text('issue');
            $table->string('status');
            $table->string('time_remaining');
            $table->timestamps();
        });

        Schema::create('dispatch_tickets', function (Blueprint $table) {
            $table->string('id')->primary(); // e.g. '9041'
            $table->string('model');
            $table->text('issue');
            $table->integer('bench')->default(3); // 0: David K., 1: Nisa P., 2: Somchai T., 3: Unassigned
            $table->string('time_remaining');
            $table->timestamps();
        });

        Schema::create('loaner_deployments', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_id');
            $table->string('employee');
            $table->string('profile');
            $table->string('urgency')->default('Standard · 24h');
            $table->string('address')->default('Headquarters reception');
            $table->string('status')->default('Deployed');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('loaner_deployments');
        Schema::dropIfExists('dispatch_tickets');
        Schema::dropIfExists('fleet_assets');
        Schema::dropIfExists('inventory_parts');
        Schema::dropIfExists('rma_jobs');
    }
};
