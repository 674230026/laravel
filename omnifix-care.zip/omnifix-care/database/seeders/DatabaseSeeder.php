<?php

namespace Database\Seeders;

use App\Models\DispatchTicket;
use App\Models\FleetAsset;
use App\Models\InventoryPart;
use App\Models\LoanerDeployment;
use App\Models\RmaJob;
use App\Models\StaffMember;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seed initial users for all key roles with password123
        $usersToSeed = [
            [
                'email' => 'sarah.m@omnifix.com',
                'name' => 'Sarah Morgan',
                'role' => 'manager',
                'title' => 'Service Manager',
                'avatar' => 'SM',
                'department' => 'Service Operations',
                'phone' => '+66 2-108-8401',
                'staff_id' => 'MGR-1042',
                'bench' => 'Bangkok Central',
                'password' => bcrypt('password123'),
            ],
            [
                'email' => 'alex@omnifix.com',
                'name' => 'Alex Morgan',
                'role' => 'technician',
                'title' => 'Senior Technician',
                'avatar' => 'AM',
                'department' => 'Hardware Diagnostics',
                'phone' => '+66 2-108-8402',
                'staff_id' => 'TECH-8402',
                'bench' => 'Bench 01 · SMD / Logic board',
                'password' => bcrypt('password123'),
            ],
            [
                'email' => 'nisa.p@omnifix.com',
                'name' => 'Nisa Patel',
                'role' => 'corporate',
                'title' => 'Corporate IT Coordinator',
                'avatar' => 'NP',
                'department' => 'Fleet Management',
                'phone' => '+66 2-108-8403',
                'staff_id' => 'CORP-2210',
                'bench' => 'Corporate Service Desk',
                'password' => bcrypt('password123'),
            ],
            [
                'email' => 'jamie.a@example.com',
                'name' => 'Jamie Anderson',
                'role' => 'customer',
                'title' => 'Device Owner',
                'avatar' => 'JA',
                'department' => 'Personal Devices',
                'phone' => '+66 81-555-0199',
                'staff_id' => 'CUST-9901',
                'bench' => 'Consumer Care',
                'password' => bcrypt('password123'),
            ],
        ];

        foreach ($usersToSeed as $userData) {
            User::updateOrCreate(
                ['email' => $userData['email']],
                $userData
            );
        }

        // RMA Jobs
        $jobs = [
            [
                'id' => '84920',
                'brand' => 'Lenovo',
                'model' => 'ThinkPad X1 Carbon',
                'gen' => 'Gen 11',
                'serial' => 'PF4X9K2L',
                'issue' => 'Overheating · Fan noise',
                'tech_name' => 'Alex Morgan',
                'tech_initials' => 'AM',
                'time_remaining' => '02h 15m',
                'status' => 'Awaiting parts',
                'priority' => 'High',
                'tone' => 'orange',
                'customer_name' => 'Jamie Anderson',
                'warranty_status' => 'Premier Onsite · Active',
                'processor' => 'Intel Core i7-1365U',
                'memory' => '16 GB LPDDR5',
                'checklist' => ['Power-on test completed', 'Chassis condition documented'],
                'technician_notes' => 'The cooling fan needs replacing to restore normal temperatures. All other components passed our inspection.',
                'quote_amount' => 60.00,
                'quote_approved' => false,
            ],
            [
                'id' => '84919',
                'brand' => 'Apple',
                'model' => 'MacBook Pro 14″',
                'gen' => 'M3 Pro · 2023',
                'serial' => 'C02GK8H9',
                'issue' => 'Display flickering',
                'tech_name' => 'Sarah Chen',
                'tech_initials' => 'SC',
                'time_remaining' => '03h 42m',
                'status' => 'In repair',
                'priority' => 'High',
                'tone' => 'purple',
                'customer_name' => 'Michael Chang',
                'warranty_status' => 'AppleCare+ · Active',
                'processor' => 'Apple M3 Pro',
                'memory' => '18 GB Unified Memory',
                'checklist' => ['Power-on test completed'],
                'technician_notes' => 'Display flex cable replacement in progress.',
                'quote_amount' => 0.00,
                'quote_approved' => true,
            ],
            [
                'id' => '84918',
                'brand' => 'Dell',
                'model' => 'XPS 15 9530',
                'gen' => 'Intel Core i7',
                'serial' => 'DX7R2M4P',
                'issue' => 'Not powering on',
                'tech_name' => 'James Wilson',
                'tech_initials' => 'JW',
                'time_remaining' => '06h 30m',
                'status' => 'Diagnosing',
                'priority' => 'Normal',
                'tone' => 'blue',
                'customer_name' => 'Eleanor Vance',
                'warranty_status' => 'ProSupport Plus',
                'processor' => 'Intel Core i7-13700H',
                'memory' => '32 GB DDR5',
                'checklist' => [],
                'technician_notes' => 'Checking charging rails and DC-in jack.',
                'quote_amount' => 85.00,
                'quote_approved' => false,
            ],
            [
                'id' => '84917',
                'brand' => 'ASUS',
                'model' => 'ROG Zephyrus G14',
                'gen' => 'AMD Ryzen 9',
                'serial' => 'R9N0CV28',
                'issue' => 'Keyboard unresponsive',
                'tech_name' => 'Alex Morgan',
                'tech_initials' => 'AM',
                'time_remaining' => '08h 10m',
                'status' => 'In repair',
                'priority' => 'Normal',
                'tone' => 'purple',
                'customer_name' => 'Lucas Scott',
                'warranty_status' => 'Standard Warranty · Active',
                'processor' => 'AMD Ryzen 9 7940HS',
                'memory' => '16 GB DDR5',
                'checklist' => ['Power-on test completed', 'Screen and dead pixel check'],
                'technician_notes' => 'Replacing top case keyboard module.',
                'quote_amount' => 0.00,
                'quote_approved' => true,
            ],
            [
                'id' => '84916',
                'brand' => 'HP',
                'model' => 'EliteBook 840 G10',
                'gen' => 'Intel Core i5',
                'serial' => '5CD3428X',
                'issue' => 'Battery not charging',
                'tech_name' => 'Sarah Chen',
                'tech_initials' => 'SC',
                'time_remaining' => '12h 45m',
                'status' => 'Quality check',
                'priority' => 'Normal',
                'tone' => 'green',
                'customer_name' => 'Diana Prince',
                'warranty_status' => 'HP Care Pack · Active',
                'processor' => 'Intel Core i5-1335U',
                'memory' => '16 GB DDR5',
                'checklist' => ['Power-on test completed', 'Screen and dead pixel check', 'Chassis condition documented'],
                'technician_notes' => 'New battery installed and calibrated. All tests passed.',
                'quote_amount' => 0.00,
                'quote_approved' => true,
            ],
            [
                'id' => '84915',
                'brand' => 'Lenovo',
                'model' => 'ThinkPad T14s',
                'gen' => 'Gen 4',
                'serial' => 'PF4M7D3K',
                'issue' => 'Blue screen on startup',
                'tech_name' => 'James Wilson',
                'tech_initials' => 'JW',
                'time_remaining' => '18h 20m',
                'status' => 'Diagnosing',
                'priority' => 'Normal',
                'tone' => 'blue',
                'customer_name' => 'Arthur Curry',
                'warranty_status' => 'Premier Onsite · Active',
                'processor' => 'AMD Ryzen 7 PRO',
                'memory' => '32 GB LPDDR5x',
                'checklist' => ['Power-on test completed'],
                'technician_notes' => 'Running Lenovo UEFI hardware diagnostic suite.',
                'quote_amount' => 0.00,
                'quote_approved' => false,
            ],
        ];

        foreach ($jobs as $job) {
            RmaJob::updateOrCreate(['id' => $job['id']], $job);
        }

        // Parts Inventory
        $parts = [
            ['sku' => 'DISP-LP-401', 'name' => 'ThinkPad 4K OLED panel · 14-inch', 'category' => 'Display panel', 'compatible_models' => 'ThinkPad X1 / T14s', 'stock' => 1, 'reserved' => 1, 'min_stock' => 3, 'unit_cost' => 180.00, 'on_order' => false],
            ['sku' => 'COOL-DL-208', 'name' => 'Dual-fan cooling assembly', 'category' => 'Cooling module', 'compatible_models' => 'Dell XPS 15 9530', 'stock' => 0, 'reserved' => 0, 'min_stock' => 4, 'unit_cost' => 55.00, 'on_order' => false],
            ['sku' => 'BOARD-LP-112', 'name' => 'Intel i7 mainboard assembly', 'category' => 'Motherboard', 'compatible_models' => 'ThinkPad X1 Carbon', 'stock' => 2, 'reserved' => 2, 'min_stock' => 3, 'unit_cost' => 320.00, 'on_order' => false],
            ['sku' => 'BATT-HP-306', 'name' => 'Long-life battery · 56Wh', 'category' => 'Battery', 'compatible_models' => 'HP EliteBook 840', 'stock' => 8, 'reserved' => 2, 'min_stock' => 5, 'unit_cost' => 70.00, 'on_order' => false],
            ['sku' => 'ADPT-AP-035', 'name' => '35W dual USB-C adapter', 'category' => 'Power adapter', 'compatible_models' => 'MacBook Air M2', 'stock' => 15, 'reserved' => 3, 'min_stock' => 5, 'unit_cost' => 45.00, 'on_order' => false],
            ['sku' => 'FRU-5F10', 'name' => 'Cooling fan assembly', 'category' => 'Cooling module', 'compatible_models' => 'ThinkPad X1 Carbon Gen 11', 'stock' => 12, 'reserved' => 1, 'min_stock' => 4, 'unit_cost' => 45.00, 'on_order' => false],
            ['sku' => 'FRU-5C50', 'name' => 'USB-C daughterboard', 'category' => 'I/O Board', 'compatible_models' => 'ThinkPad T14 / T14s', 'stock' => 8, 'reserved' => 0, 'min_stock' => 3, 'unit_cost' => 35.00, 'on_order' => false],
            ['sku' => 'FRU-5N20', 'name' => 'ThinkPad keyboard (Backlit)', 'category' => 'Keyboard', 'compatible_models' => 'ThinkPad X1 / T14s', 'stock' => 6, 'reserved' => 0, 'min_stock' => 3, 'unit_cost' => 65.00, 'on_order' => false],
            ['sku' => 'FRU-5B10', 'name' => 'Replacement battery 57Wh', 'category' => 'Battery', 'compatible_models' => 'ThinkPad X1 Carbon Gen 10/11', 'stock' => 18, 'reserved' => 2, 'min_stock' => 5, 'unit_cost' => 85.00, 'on_order' => false],
        ];

        foreach ($parts as $part) {
            InventoryPart::updateOrCreate(['sku' => $part['sku']], $part);
        }

        // Fleet Assets
        $assets = [
            ['id' => '9041', 'asset_tag' => 'ACME-NB-042', 'employee' => 'Sarah Jenkins', 'department' => 'Marketing', 'model' => 'ThinkPad T14s Gen 4', 'serial' => 'PF4X9K2L', 'issue' => 'Display flickering', 'status' => 'Awaiting parts', 'time_remaining' => '02h 15m'],
            ['id' => '9042', 'asset_tag' => 'ACME-NB-108', 'employee' => 'Daniel Park', 'department' => 'Engineering', 'model' => 'Dell Precision 5680', 'serial' => 'DX7R2M4P', 'issue' => 'GPU thermal issue', 'status' => 'Bench inspection', 'time_remaining' => '03h 42m'],
            ['id' => '9043', 'asset_tag' => 'ACME-NB-063', 'employee' => 'Emma Wilson', 'department' => 'Finance', 'model' => 'MacBook Pro 14″', 'serial' => 'C02GK8H9', 'issue' => 'Battery not charging', 'status' => 'In repair', 'time_remaining' => '08h 30m'],
            ['id' => '9044', 'asset_tag' => 'ACME-NB-219', 'employee' => 'Oliver Chen', 'department' => 'Operations', 'model' => 'HP EliteBook 840', 'serial' => '5CD3428X', 'issue' => 'Keyboard unresponsive', 'status' => 'Quality check', 'time_remaining' => '12h 10m'],
        ];

        foreach ($assets as $asset) {
            FleetAsset::updateOrCreate(['id' => $asset['id']], $asset);
        }

        // Dispatch Tickets
        $dispatchTickets = [
            ['id' => '9041', 'model' => 'ThinkPad X1 Carbon', 'issue' => 'Power IC reballing', 'bench' => 0, 'time_remaining' => '02h 15m'],
            ['id' => '9042', 'model' => 'Dell Precision 5680', 'issue' => 'GPU thermal issue', 'bench' => 0, 'time_remaining' => '06h 30m'],
            ['id' => '9043', 'model' => 'MacBook Pro 14″', 'issue' => 'Hinge replacement', 'bench' => 1, 'time_remaining' => '00h 45m'],
            ['id' => '9044', 'model' => 'ThinkPad T14s', 'issue' => 'Display replacement', 'bench' => 1, 'time_remaining' => '03h 20m'],
            ['id' => '9045', 'model' => 'Dell XPS 15', 'issue' => 'Chassis inspection', 'bench' => 1, 'time_remaining' => '07h 40m'],
            ['id' => '9046', 'model' => 'HP EliteBook 840', 'issue' => 'Keyboard replacement', 'bench' => 1, 'time_remaining' => '09h 10m'],
            ['id' => '9047', 'model' => 'ASUS Zephyrus G14', 'issue' => 'Screen flickering', 'bench' => 1, 'time_remaining' => '11h 25m'],
            ['id' => '9048', 'model' => 'MacBook Air M2', 'issue' => 'Battery diagnostics', 'bench' => 2, 'time_remaining' => '12h 45m'],
            ['id' => '9049', 'model' => 'ThinkPad T14', 'issue' => 'Not powering on', 'bench' => 3, 'time_remaining' => '01h 45m'],
            ['id' => '9050', 'model' => 'Dell Latitude 7440', 'issue' => 'USB-C port damage', 'bench' => 3, 'time_remaining' => '05h 20m'],
        ];

        foreach ($dispatchTickets as $dt) {
            DispatchTicket::updateOrCreate(['id' => $dt['id']], $dt);
        }

        // Loaners
        $loaners = [
            ['ticket_id' => '9031', 'employee' => 'Liam Smith', 'profile' => 'Standard Office · Windows 11', 'urgency' => 'Standard · 24h', 'address' => 'Headquarters reception', 'status' => 'Deployed'],
            ['ticket_id' => '9034', 'employee' => 'Ava Patel', 'profile' => 'Developer · Ubuntu', 'urgency' => 'Standard · 24h', 'address' => 'Headquarters reception', 'status' => 'Deployed'],
            ['ticket_id' => '9038', 'employee' => 'Noah Davis', 'profile' => 'Executive · Windows 11', 'urgency' => 'Emergency · 4h onsite dispatch', 'address' => 'Executive Suite 401', 'status' => 'Deployed'],
        ];

        foreach ($loaners as $loaner) {
            LoanerDeployment::updateOrCreate(['ticket_id' => $loaner['ticket_id']], $loaner);
        }

        // Staff members
        $staffMembers = [
            ['id' => 1, 'name' => 'Somchai Prasert', 'email' => 'somchai.p@omnifix.com', 'role' => 'Super Admin', 'bench' => 'HQ Operations', 'two_fa' => true, 'active' => true, 'permissions' => [true, true, true, true, true]],
            ['id' => 2, 'name' => 'Alex Chen', 'email' => 'alex.c@omnifix.com', 'role' => 'Bench Tech', 'bench' => 'Bench 01 · SMD / Logic board', 'two_fa' => true, 'active' => true, 'permissions' => [false, false, true, true, false]],
            ['id' => 3, 'name' => 'Mayuree K.', 'email' => 'mayuree.k@omnifix.com', 'role' => 'Service Desk', 'bench' => 'Front intake counter', 'two_fa' => false, 'active' => true, 'permissions' => [true, true, false, true, false]],
            ['id' => 4, 'name' => 'Sarah Morgan', 'email' => 'sarah.m@omnifix.com', 'role' => 'Service Manager', 'bench' => 'Bangkok Central', 'two_fa' => true, 'active' => true, 'permissions' => [true, true, true, true, false]],
            ['id' => 5, 'name' => 'Nisa Patel', 'email' => 'nisa.p@omnifix.com', 'role' => 'B2B Coordinator', 'bench' => 'Corporate service desk', 'two_fa' => true, 'active' => true, 'permissions' => [true, true, false, true, false]],
            ['id' => 6, 'name' => 'David Kim', 'email' => 'david.k@omnifix.com', 'role' => 'Bench Tech', 'bench' => 'Bench 02 · Display & mechanical', 'two_fa' => true, 'active' => false, 'permissions' => [false, false, true, false, false]],
        ];

        foreach ($staffMembers as $sm) {
            StaffMember::updateOrCreate(['id' => $sm['id']], $sm);
        }
    }
}
