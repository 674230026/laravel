<?php

use App\Http\Controllers\OmniFixController;
use Illuminate\Support\Facades\Route;

Route::get('/login', [OmniFixController::class, 'login'])->name('login');
Route::post('/login', [OmniFixController::class, 'handleLogin'])->name('login.post');
Route::get('/logout', [OmniFixController::class, 'logout'])->name('logout');

Route::get('/', [OmniFixController::class, 'index'])->name('home');
Route::post('/dispatch/reassign', [OmniFixController::class, 'reassignDispatch'])->name('dispatch.reassign');
Route::post('/jobs/{id}/qc', [OmniFixController::class, 'markRepaired'])->name('jobs.qc');
Route::post('/loaners/request', [OmniFixController::class, 'requestLoaner'])->name('loaners.request');
Route::post('/loaners/{ticket_id}/return', [OmniFixController::class, 'returnLoaner'])->name('loaners.return');
Route::post('/inventory/{sku}/order', [OmniFixController::class, 'orderPart'])->name('inventory.order');
Route::post('/inventory/{sku}/reserve', [OmniFixController::class, 'reservePart'])->name('inventory.reserve');
Route::post('/inventory/batch-order', [OmniFixController::class, 'batchOrderParts'])->name('inventory.batch-order');
Route::post('/customer/check-warranty', [OmniFixController::class, 'checkWarranty'])->name('customer.check-warranty');
Route::post('/customer/submit-ticket', [OmniFixController::class, 'submitCustomerTicket'])->name('customer.submit-ticket');
Route::post('/customer/quotes/{id}/approve', [OmniFixController::class, 'approveQuote'])->name('quotes.approve');
Route::get('/reports/export', [OmniFixController::class, 'exportReport'])->name('reports.export');
Route::post('/settings/save', [OmniFixController::class, 'saveSettings'])->name('settings.save');
Route::post('/staff/save', [OmniFixController::class, 'saveStaff'])->name('staff.save');
Route::post('/staff/{id}/toggle', [OmniFixController::class, 'toggleStaff'])->name('staff.toggle');
Route::post('/staff/{id}/reset-password', [OmniFixController::class, 'resetStaffPassword'])->name('staff.reset');
