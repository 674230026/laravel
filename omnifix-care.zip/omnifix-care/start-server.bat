@echo off
title OmniFix Care - Laravel Server
color 0A

echo.
echo  =============================================
echo   OmniFix Care - Starting Laravel Server
echo  =============================================
echo.

cd /d "%~dp0"
if exist "%USERPROFILE%\.config\herd-lite\bin\php.exe" (
    set "PATH=%USERPROFILE%\.config\herd-lite\bin;%PATH%"
)

echo [1/3] Checking PHP...
php -v >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: PHP is not installed or not in PATH.
    echo  Please install PHP and try again.
    pause
    exit /b 1
)

echo [2/3] Checking environment...
if not exist ".env" (
    echo  .env not found. Copying from .env.example...
    copy .env.example .env >nul
    php artisan key:generate
)

if not exist "database\database.sqlite" (
    echo  Database not found. Running migrations and seeding...
    php artisan migrate:fresh --seed --force
)

echo [3/3] Starting background mail queue worker and server at http://127.0.0.1:8000
echo.
echo  Press Ctrl+C to stop the server.
echo.

start "" "http://127.0.0.1:8000"
start "OmniFix Mail Queue Worker" /min cmd /c "php artisan queue:work --sleep=1 --tries=3"
php artisan serve

pause
